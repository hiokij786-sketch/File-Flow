// Generates the legacy launcher PNGs and the in-app icon from the FILEFLOW mark.
// Run with: dart --packages=.dart_tool/package_config.json tool/generate_icons.dart
import 'dart:io';

import 'package:image/image.dart' as img;

img.Image _render(int size, {required bool round}) {
  final image = img.Image(width: size, height: size, numChannels: 4);
  final k = size / 108.0;
  final ink = img.ColorRgba8(17, 17, 17, 255);
  final gold = img.ColorRgba8(201, 162, 39, 255);
  final lightGold = img.ColorRgba8(230, 203, 110, 255);
  if (round) {
    img.fillCircle(
      image,
      x: size ~/ 2,
      y: size ~/ 2,
      radius: size ~/ 2,
      color: ink,
    );
  } else {
    img.fillRect(
      image,
      x1: 0,
      y1: 0,
      x2: size - 1,
      y2: size - 1,
      radius: size * 0.2,
      color: ink,
    );
  }
  void rect(double x1, double y1, double x2, double y2, img.Color c) {
    img.fillRect(
      image,
      x1: (x1 * k).round(),
      y1: (y1 * k).round(),
      x2: (x2 * k).round(),
      y2: (y2 * k).round(),
      color: c,
    );
  }

  rect(40, 30, 72, 40, gold);
  rect(40, 30, 50, 78, gold);
  rect(50, 49, 64, 58, lightGold);
  return image;
}

void main() {
  const sizes = {
    'mdpi': 48,
    'hdpi': 72,
    'xhdpi': 96,
    'xxhdpi': 144,
    'xxxhdpi': 192,
  };
  sizes.forEach((density, size) {
    final dir = 'android/app/src/main/res/mipmap-$density';
    Directory(dir).createSync(recursive: true);
    File('$dir/ic_launcher.png').writeAsBytesSync(
      img.encodePng(_render(size, round: false)),
    );
    File('$dir/ic_launcher_round.png').writeAsBytesSync(
      img.encodePng(_render(size, round: true)),
    );
  });
  Directory('assets/icons').createSync(recursive: true);
  File('assets/icons/app_icon.png').writeAsBytesSync(
    img.encodePng(_render(512, round: false)),
  );
  stdout.writeln('FILEFLOW icons generated.');
}
