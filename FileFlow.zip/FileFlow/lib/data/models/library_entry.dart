import '../../core/utilities/file_types.dart';

/// A file known to the FILEFLOW library.
class LibraryEntry {
  const LibraryEntry({
    required this.path,
    required this.name,
    required this.size,
    required this.modified,
    required this.isProcessed,
    required this.isFavorite,
    this.lastOpenedIndex,
    this.missing = false,
  });

  final String path;
  final String name;
  final int size;
  final DateTime modified;
  final bool isProcessed;
  final bool isFavorite;

  /// Position in the recent list (0 = most recent) or `null` if never opened.
  final int? lastOpenedIndex;

  /// The file was moved or deleted outside FILEFLOW.
  final bool missing;

  bool get isRecent => lastOpenedIndex != null;

  FileCategory get category => categoryOfPath(path);
}
