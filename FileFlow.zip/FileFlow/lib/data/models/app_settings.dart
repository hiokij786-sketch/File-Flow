import 'package:material_ui/material_ui.dart';

import '../../core/services/file_ops_service.dart';
import '../../core/services/image_service.dart';
import '../../core/services/pdf_service.dart';

/// User preferences persisted with SharedPreferences.
class AppSettings {
  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.defaultImageFormat = OutputImageFormat.jpg,
    this.defaultPdfQuality = CompressionLevel.medium,
    this.sortField = SortField.name,
    this.sortAscending = true,
    this.gridView = false,
    this.askWhereToSave = false,
  });

  final ThemeMode themeMode;
  final OutputImageFormat defaultImageFormat;
  final CompressionLevel defaultPdfQuality;
  final SortField sortField;
  final bool sortAscending;
  final bool gridView;

  /// When true, the system "save as" dialog opens after every processed file.
  final bool askWhereToSave;

  AppSettings copyWith({
    ThemeMode? themeMode,
    OutputImageFormat? defaultImageFormat,
    CompressionLevel? defaultPdfQuality,
    SortField? sortField,
    bool? sortAscending,
    bool? gridView,
    bool? askWhereToSave,
  }) =>
      AppSettings(
        themeMode: themeMode ?? this.themeMode,
        defaultImageFormat: defaultImageFormat ?? this.defaultImageFormat,
        defaultPdfQuality: defaultPdfQuality ?? this.defaultPdfQuality,
        sortField: sortField ?? this.sortField,
        sortAscending: sortAscending ?? this.sortAscending,
        gridView: gridView ?? this.gridView,
        askWhereToSave: askWhereToSave ?? this.askWhereToSave,
      );
}
