import 'dart:io';

import 'package:path/path.dart' as p;

import '../../core/services/storage_service.dart';
import '../local/preferences_store.dart';
import '../models/library_entry.dart';

/// Keeps references (favorites, recents) and builds the file library from the
/// FILEFLOW workspace. References to files that disappeared are reported as
/// `missing` instead of crashing.
class LibraryRepository {
  LibraryRepository(this._prefs, this._storage);

  final PreferencesStore _prefs;
  final StorageService _storage;

  static const int maxRecents = 40;

  Future<List<LibraryEntry>> loadAll() async {
    final workspace = await _storage.workspace();
    final processed = await _storage.processedDir();
    final favorites = _prefs.favorites.toSet();
    final recents = _prefs.recents;
    final entries = <String, LibraryEntry>{};

    LibraryEntry build(String path, {required bool missing, int size = 0, DateTime? modified}) {
      final recentIndex = recents.indexOf(path);
      return LibraryEntry(
        path: path,
        name: p.basename(path),
        size: size,
        modified: modified ?? DateTime.fromMillisecondsSinceEpoch(0),
        isProcessed: p.isWithin(processed.path, path),
        isFavorite: favorites.contains(path),
        lastOpenedIndex: recentIndex >= 0 ? recentIndex : null,
        missing: missing,
      );
    }

    if (workspace.existsSync()) {
      await for (final entity in workspace.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        if (p.basename(entity.path).startsWith('.')) continue;
        try {
          final stat = await entity.stat();
          entries[entity.path] = build(
            entity.path,
            missing: false,
            size: stat.size,
            modified: stat.modified,
          );
        } on FileSystemException {
          continue;
        }
      }
    }
    // References outside the workspace (or files that vanished).
    for (final path in {...favorites, ...recents}) {
      if (entries.containsKey(path)) continue;
      final file = File(path);
      if (file.existsSync()) {
        final stat = file.statSync();
        entries[path] = build(path, missing: false, size: stat.size, modified: stat.modified);
      } else {
        entries[path] = build(path, missing: true);
      }
    }
    return entries.values.toList();
  }

  Future<void> markOpened(String path) async {
    final list = [..._prefs.recents]..remove(path);
    list.insert(0, path);
    await _prefs.setRecents(list.take(maxRecents).toList());
  }

  Future<bool> toggleFavorite(String path) async {
    final list = [..._prefs.favorites];
    final nowFavorite = !list.remove(path);
    if (nowFavorite) list.add(path);
    await _prefs.setFavorites(list);
    return nowFavorite;
  }

  /// Drops every reference to [path] (used after delete or for missing files).
  Future<void> forget(String path) async {
    await _prefs.setFavorites([..._prefs.favorites]..remove(path));
    await _prefs.setRecents([..._prefs.recents]..remove(path));
  }

  /// Keeps favorites/recents attached to a renamed or moved file.
  Future<void> moved(String from, String to) async {
    List<String> swap(List<String> list) => [for (final e in list) e == from ? to : e];
    await _prefs.setFavorites(swap(_prefs.favorites));
    await _prefs.setRecents(swap(_prefs.recents));
  }
}
