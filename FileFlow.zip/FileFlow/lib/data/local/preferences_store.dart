import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/services/file_ops_service.dart';
import '../../core/services/image_service.dart';
import '../../core/services/pdf_service.dart';
import '../models/app_settings.dart';

/// Thin typed wrapper around [SharedPreferences].
class PreferencesStore {
  PreferencesStore(this._prefs);

  final SharedPreferences _prefs;

  static const _kTheme = 'theme_mode';
  static const _kImageFormat = 'default_image_format';
  static const _kPdfQuality = 'default_pdf_quality';
  static const _kSortField = 'sort_field';
  static const _kSortAsc = 'sort_ascending';
  static const _kGrid = 'grid_view';
  static const _kAsk = 'ask_where_to_save';
  static const _kOnboarding = 'onboarding_done';
  static const _kFavorites = 'favorite_paths';
  static const _kRecents = 'recent_paths';

  AppSettings loadSettings() => AppSettings(
        themeMode: ThemeMode.values.firstWhere(
          (m) => m.name == _prefs.getString(_kTheme),
          orElse: () => ThemeMode.system,
        ),
        defaultImageFormat: OutputImageFormat.fromName(_prefs.getString(_kImageFormat)),
        defaultPdfQuality: CompressionLevel.values.firstWhere(
          (m) => m.name == _prefs.getString(_kPdfQuality),
          orElse: () => CompressionLevel.medium,
        ),
        sortField: SortField.values.firstWhere(
          (m) => m.name == _prefs.getString(_kSortField),
          orElse: () => SortField.name,
        ),
        sortAscending: _prefs.getBool(_kSortAsc) ?? true,
        gridView: _prefs.getBool(_kGrid) ?? false,
        askWhereToSave: _prefs.getBool(_kAsk) ?? false,
      );

  Future<void> saveSettings(AppSettings s) async {
    await _prefs.setString(_kTheme, s.themeMode.name);
    await _prefs.setString(_kImageFormat, s.defaultImageFormat.name);
    await _prefs.setString(_kPdfQuality, s.defaultPdfQuality.name);
    await _prefs.setString(_kSortField, s.sortField.name);
    await _prefs.setBool(_kSortAsc, s.sortAscending);
    await _prefs.setBool(_kGrid, s.gridView);
    await _prefs.setBool(_kAsk, s.askWhereToSave);
  }

  bool get onboardingDone => _prefs.getBool(_kOnboarding) ?? false;

  Future<void> setOnboardingDone() => _prefs.setBool(_kOnboarding, true);

  List<String> get favorites => _prefs.getStringList(_kFavorites) ?? const [];

  Future<void> setFavorites(List<String> value) => _prefs.setStringList(_kFavorites, value);

  List<String> get recents => _prefs.getStringList(_kRecents) ?? const [];

  Future<void> setRecents(List<String> value) => _prefs.setStringList(_kRecents, value);
}
