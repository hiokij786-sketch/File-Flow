/// A user-presentable failure. [message] is always safe to show in the UI.
class AppException implements Exception {
  const AppException(this.message, {this.details});

  final String message;
  final String? details;

  @override
  String toString() => message;
}

/// Thrown when the device does not have enough free space for an operation.
class InsufficientStorageException extends AppException {
  const InsufficientStorageException(super.message);
}

/// Thrown when a password protected document needs a password.
class PasswordRequiredException extends AppException {
  const PasswordRequiredException([
    super.message = 'This document is password protected.',
  ]);
}

/// Thrown when a supplied password does not open the document.
class WrongPasswordException extends AppException {
  const WrongPasswordException([
    super.message = 'The password is incorrect.',
  ]);
}

/// Thrown when an operation is cancelled by the user.
class CancelledException implements Exception {
  const CancelledException();

  @override
  String toString() => 'Cancelled';
}
