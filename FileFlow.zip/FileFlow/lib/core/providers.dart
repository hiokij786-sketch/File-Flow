import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/local/preferences_store.dart';
import '../data/models/app_settings.dart';
import '../data/models/library_entry.dart';
import '../data/repositories/library_repository.dart';
import 'services/archive_service.dart';
import 'services/file_ops_service.dart';
import 'services/image_service.dart';
import 'services/native_service.dart';
import 'services/output_service.dart';
import 'services/pdf_service.dart';
import 'services/scanner_service.dart';
import 'services/storage_service.dart';

/// Overridden in `main()` with the initialized instance.
final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPreferencesProvider must be overridden'),
);

final preferencesStoreProvider = Provider<PreferencesStore>(
  (ref) => PreferencesStore(ref.watch(sharedPreferencesProvider)),
);

final nativeServiceProvider = Provider<NativeService>((ref) => const NativeService());

final storageServiceProvider = Provider<StorageService>(
  (ref) => StorageService(native: ref.watch(nativeServiceProvider)),
);

final outputServiceProvider = Provider<OutputService>(
  (ref) => OutputService(
    ref.watch(storageServiceProvider),
    ref.watch(nativeServiceProvider),
  ),
);

final pdfServiceProvider = Provider<PdfService>((ref) => const PdfService());

final imageServiceProvider = Provider<ImageService>(
  (ref) => ImageService(native: ref.watch(nativeServiceProvider)),
);

final archiveServiceProvider = Provider<ArchiveService>((ref) => const ArchiveService());

final scannerServiceProvider = Provider<ScannerService>((ref) => const ScannerService());

final fileOpsProvider = Provider<FileOpsService>((ref) => const FileOpsService());

final libraryRepositoryProvider = Provider<LibraryRepository>(
  (ref) => LibraryRepository(
    ref.watch(preferencesStoreProvider),
    ref.watch(storageServiceProvider),
  ),
);

/// App-wide settings, persisted on every change.
class SettingsNotifier extends Notifier<AppSettings> {
  @override
  AppSettings build() => ref.watch(preferencesStoreProvider).loadSettings();

  Future<void> update(AppSettings Function(AppSettings current) change) async {
    state = change(state);
    await ref.read(preferencesStoreProvider).saveSettings(state);
  }
}

final settingsProvider = NotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

/// The file library (workspace files + favorites + recents).
class LibraryNotifier extends AsyncNotifier<List<LibraryEntry>> {
  @override
  Future<List<LibraryEntry>> build() => ref.watch(libraryRepositoryProvider).loadAll();

  Future<void> refresh() async {
    state = await AsyncValue.guard(() => ref.read(libraryRepositoryProvider).loadAll());
  }

  Future<void> markOpened(String path) async {
    await ref.read(libraryRepositoryProvider).markOpened(path);
    await refresh();
  }

  Future<void> toggleFavorite(String path) async {
    await ref.read(libraryRepositoryProvider).toggleFavorite(path);
    await refresh();
  }

  Future<void> forget(String path) async {
    await ref.read(libraryRepositoryProvider).forget(path);
    await refresh();
  }

  Future<void> moved(String from, String to) async {
    await ref.read(libraryRepositoryProvider).moved(from, to);
    await refresh();
  }
}

final libraryProvider =
    AsyncNotifierProvider<LibraryNotifier, List<LibraryEntry>>(LibraryNotifier.new);
