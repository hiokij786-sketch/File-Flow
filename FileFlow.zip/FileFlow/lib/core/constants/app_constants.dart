/// Global constants for FILEFLOW.
class AppConstants {
  const AppConstants._();

  static const String appName = 'FILEFLOW';
  static const String tagline = 'Everything Your Files Need.';
  static const String packageName = 'com.fileflow.app';
  static const String version = '1.0.0';
  static const String buildNumber = '1';

  /// Platform channel implemented in `MainActivity.kt`.
  static const String nativeChannel = 'com.fileflow.app/native';

  /// Folder names inside the app workspace.
  static const String workspaceFolder = 'FILEFLOW';
  static const String processedFolder = 'Processed';
  static const String importedFolder = 'Imported';
  static const String tempFolder = 'fileflow_tmp';

  /// Extensions that FILEFLOW can treat as images.
  static const List<String> imageExtensions = [
    'jpg',
    'jpeg',
    'png',
    'webp',
    'bmp',
    'gif',
  ];

  /// Upper bound for PDF raster export resolution (protects budget devices).
  static const int maxRenderDpi = 300;
}
