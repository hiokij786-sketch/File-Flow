import '../errors/app_exception.dart';

/// Reports real progress of a running job. [fraction] is in the range 0..1.
typedef ProgressCallback = void Function(double fraction, String message);

/// Cooperative cancellation for long running jobs.
class CancelToken {
  bool _cancelled = false;

  bool get isCancelled => _cancelled;

  void cancel() => _cancelled = true;

  /// Throws [CancelledException] when the user cancelled the job.
  void throwIfCancelled() {
    if (_cancelled) throw const CancelledException();
  }
}
