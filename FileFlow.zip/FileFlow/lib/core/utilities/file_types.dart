import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

/// File categories used by the file manager, library and storage overview.
enum FileCategory { pdf, image, video, audio, document, archive, other }

extension FileCategoryX on FileCategory {
  String get label => switch (this) {
        FileCategory.pdf => 'PDFs',
        FileCategory.image => 'Images',
        FileCategory.video => 'Videos',
        FileCategory.audio => 'Audio',
        FileCategory.document => 'Documents',
        FileCategory.archive => 'Archives',
        FileCategory.other => 'Other',
      };

  IconData get icon => switch (this) {
        FileCategory.pdf => Icons.picture_as_pdf_rounded,
        FileCategory.image => Icons.image_rounded,
        FileCategory.video => Icons.movie_rounded,
        FileCategory.audio => Icons.audiotrack_rounded,
        FileCategory.document => Icons.description_rounded,
        FileCategory.archive => Icons.folder_zip_rounded,
        FileCategory.other => Icons.insert_drive_file_rounded,
      };
}

const _imageExt = {'jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'heic', 'heif'};
const _videoExt = {'mp4', 'mkv', 'avi', 'mov', 'webm', '3gp', 'm4v'};
const _audioExt = {'mp3', 'wav', 'aac', 'm4a', 'ogg', 'flac', 'opus'};
const _docExt = {
  'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'rtf', //
  'csv', 'md', 'html', 'htm', 'json', 'xml',
};
const _archiveExt = {'zip', 'rar', '7z', 'tar', 'gz', 'bz2'};

/// Lower-case extension without the dot.
String extensionOf(String path) => p.extension(path).replaceFirst('.', '').toLowerCase();

FileCategory categoryOfPath(String path) {
  final ext = extensionOf(path);
  if (ext == 'pdf') return FileCategory.pdf;
  if (_imageExt.contains(ext)) return FileCategory.image;
  if (_videoExt.contains(ext)) return FileCategory.video;
  if (_audioExt.contains(ext)) return FileCategory.audio;
  if (_docExt.contains(ext)) return FileCategory.document;
  if (_archiveExt.contains(ext)) return FileCategory.archive;
  return FileCategory.other;
}

bool isPdfPath(String path) => extensionOf(path) == 'pdf';

bool isImagePath(String path) => categoryOfPath(path) == FileCategory.image;
