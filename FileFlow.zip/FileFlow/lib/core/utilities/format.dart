import 'package:intl/intl.dart';

/// Formats a byte count as a short human readable string.
String formatBytes(int bytes, {int decimals = 1}) {
  if (bytes < 0) return '0 B';
  if (bytes < 1024) return '$bytes B';
  const units = ['KB', 'MB', 'GB', 'TB'];
  double value = bytes / 1024;
  int unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  final text = value >= 100 ? value.toStringAsFixed(0) : value.toStringAsFixed(decimals);
  return '$text ${units[unit]}';
}

/// Formats a date for list items.
String formatDate(DateTime date) => DateFormat('d MMM yyyy, HH:mm').format(date);

/// Short date without time.
String formatShortDate(DateTime date) => DateFormat('d MMM yyyy').format(date);

/// Percentage reduction between [original] and [result] (can be negative).
double reductionPercent(int original, int result) {
  if (original <= 0) return 0;
  return (original - result) / original * 100;
}

/// Greeting based on the local time of day.
String greetingFor(DateTime now) {
  final hour = now.hour;
  if (hour < 5) return 'Good night';
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}
