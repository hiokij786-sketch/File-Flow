import 'dart:io';

import 'package:path/path.dart' as p;

/// Removes characters that are unsafe in file names and trims length.
String sanitizeFileName(String input, {String fallback = 'file'}) {
  var name = input.replaceAll(RegExp(r'[\\/:*?"<>|\u0000-\u001F]'), '_').trim();
  name = name.replaceAll(RegExp(r'\.{2,}'), '.');
  while (name.startsWith('.')) {
    name = name.substring(1);
  }
  if (name.isEmpty) name = fallback;
  if (name.length > 120) {
    final ext = p.extension(name);
    final base = p.basenameWithoutExtension(name);
    final keep = 120 - ext.length;
    name = base.substring(0, keep > 0 ? keep.clamp(0, base.length) : 0) + ext;
  }
  return name;
}

/// Returns true when an archive entry name cannot escape the extraction folder.
///
/// Rejects absolute paths, drive letters, `..` segments and NUL characters.
bool isSafeArchiveEntryName(String name) {
  if (name.isEmpty || name.contains('\u0000')) return false;
  final normalized = name.replaceAll('\\', '/');
  if (normalized.startsWith('/')) return false;
  if (RegExp(r'^[A-Za-z]:').hasMatch(normalized)) return false;
  final segments = normalized.split('/');
  if (segments.any((s) => s == '..')) return false;
  return true;
}

/// Returns a path in [dir] for [fileName] that does not exist yet
/// (`name.ext`, `name (1).ext`, ...). Existing files are never overwritten.
String uniquePath(String dir, String fileName) {
  final base = p.basenameWithoutExtension(fileName);
  final ext = p.extension(fileName);
  var candidate = p.join(dir, fileName);
  var counter = 1;
  while (File(candidate).existsSync() || Directory(candidate).existsSync()) {
    candidate = p.join(dir, '$base ($counter)$ext');
    counter++;
  }
  return candidate;
}

/// Ensures [fileName] ends with [extension] (given without a dot).
String withExtension(String fileName, String extension) {
  final clean = sanitizeFileName(fileName);
  if (clean.toLowerCase().endsWith('.${extension.toLowerCase()}')) return clean;
  return '${p.basenameWithoutExtension(clean)}.$extension';
}
