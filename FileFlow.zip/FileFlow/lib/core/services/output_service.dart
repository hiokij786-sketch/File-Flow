import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';

import '../errors/app_exception.dart';
import 'native_service.dart';
import 'storage_service.dart';

/// A file produced by a tool.
class ProcessedFile {
  const ProcessedFile({required this.path, required this.name, required this.size});

  final String path;
  final String name;
  final int size;
}

/// A file the user picked through the system picker (a private copy in cache).
class PickedFile {
  const PickedFile({required this.path, required this.name, required this.size});

  final String path;
  final String name;
  final int size;
}

/// Saving, exporting, sharing and picking files.
class OutputService {
  const OutputService(this._storage, this._native);

  final StorageService _storage;
  final NativeService _native;

  /// Saves tool output into the Processed folder (optionally in [subfolder]).
  Future<ProcessedFile> save(
    Uint8List bytes,
    String fileName, {
    String? subfolder,
  }) async {
    var dir = await _storage.processedDir();
    if (subfolder != null) dir = Directory(p.join(dir.path, subfolder));
    final file = await _storage.writeUnique(dir, fileName, bytes);
    return ProcessedFile(path: file.path, name: p.basename(file.path), size: bytes.length);
  }

  /// Registers an already written file as a result.
  Future<ProcessedFile> describe(File file) async => ProcessedFile(
        path: file.path,
        name: p.basename(file.path),
        size: await file.length(),
      );

  /// Opens the system "save as" dialog (Storage Access Framework) so the user
  /// can choose any destination. Returns false when cancelled.
  Future<bool> exportCopy(String path) async {
    final file = File(path);
    if (!file.existsSync()) throw const AppException('The file no longer exists.');
    final bytes = await file.readAsBytes();
    final result = await FilePicker.platform.saveFile(
      dialogTitle: 'Save a copy',
      fileName: p.basename(path),
      bytes: bytes,
    );
    return result != null;
  }

  Future<void> share(List<String> paths, {String? subject}) async {
    final existing = paths.where((e) => File(e).existsSync()).toList();
    if (existing.isEmpty) throw const AppException('The file no longer exists.');
    await SharePlus.instance.share(
      ShareParams(files: [for (final e in existing) XFile(e)], subject: subject),
    );
  }

  Future<void> openExternally(String path) => _native.openFile(path);

  /// System document picker. Selected files are copied to the cache by the
  /// plugin, so the originals are never touched.
  Future<List<PickedFile>> pick({
    List<String>? extensions,
    bool multiple = true,
  }) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: multiple,
      type: extensions == null ? FileType.any : FileType.custom,
      allowedExtensions: extensions,
      withData: false,
    );
    if (result == null) return const [];
    final picked = <PickedFile>[];
    for (final f in result.files) {
      final path = f.path;
      if (path == null) continue;
      final file = File(path);
      if (!file.existsSync()) continue;
      picked.add(PickedFile(path: path, name: f.name, size: await file.length()));
    }
    return picked;
  }
}
