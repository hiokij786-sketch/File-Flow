import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import '../errors/app_exception.dart';

enum ScanFilter {
  original('Original'),
  enhanced('Enhanced'),
  grayscale('Grayscale'),
  blackWhite('Black & white');

  const ScanFilter(this.label);

  final String label;
}

/// Normalized (0..1) point inside an image.
class NormPoint {
  const NormPoint(this.x, this.y);

  final double x;
  final double y;

  NormPoint copyWith({double? x, double? y}) => NormPoint(x ?? this.x, y ?? this.y);
}

/// Four document corners: top-left, top-right, bottom-right, bottom-left.
class ScanCorners {
  const ScanCorners(this.tl, this.tr, this.br, this.bl);

  final NormPoint tl;
  final NormPoint tr;
  final NormPoint br;
  final NormPoint bl;

  static const full = ScanCorners(
    NormPoint(0, 0),
    NormPoint(1, 0),
    NormPoint(1, 1),
    NormPoint(0, 1),
  );

  List<NormPoint> get points => [tl, tr, br, bl];

  bool get isFull =>
      tl.x < 0.001 &&
      tl.y < 0.001 &&
      tr.x > 0.999 &&
      tr.y < 0.001 &&
      br.x > 0.999 &&
      br.y > 0.999 &&
      bl.x < 0.001 &&
      bl.y > 0.999;
}

/// Everything applied to one scanned page.
class ScanEdit {
  const ScanEdit({
    this.corners = ScanCorners.full,
    this.quarterTurns = 0,
    this.filter = ScanFilter.enhanced,
    this.brightness = 1.0,
    this.contrast = 1.0,
  });

  final ScanCorners corners;
  final int quarterTurns;
  final ScanFilter filter;

  /// Multiplier, 1.0 = unchanged.
  final double brightness;
  final double contrast;

  ScanEdit copyWith({
    ScanCorners? corners,
    int? quarterTurns,
    ScanFilter? filter,
    double? brightness,
    double? contrast,
  }) =>
      ScanEdit(
        corners: corners ?? this.corners,
        quarterTurns: quarterTurns ?? this.quarterTurns,
        filter: filter ?? this.filter,
        brightness: brightness ?? this.brightness,
        contrast: contrast ?? this.contrast,
      );
}

img.Image _decode(Uint8List bytes, {int? maxSide}) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) {
    throw const AppException('This image could not be read.');
  }
  var image = img.bakeOrientation(decoded);
  if (maxSide != null) {
    final long = math.max(image.width, image.height);
    if (long > maxSide) {
      image = image.width >= image.height
          ? img.copyResize(image, width: maxSide, interpolation: img.Interpolation.average)
          : img.copyResize(image, height: maxSide, interpolation: img.Interpolation.average);
    }
  }
  return image;
}

/// Finds the document quadrilateral in [bytes] using a brightness segmentation
/// (Otsu threshold) followed by extreme-point search. Falls back to a slightly
/// inset frame when no clear document is found.
ScanCorners detectCornersSync(Uint8List bytes) {
  final image = _decode(bytes, maxSide: 360);
  final w = image.width;
  final h = image.height;
  final gray = Uint8List(w * h);
  final hist = List<int>.filled(256, 0);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final px = image.getPixel(x, y);
      final l = (0.299 * px.r + 0.587 * px.g + 0.114 * px.b).round().clamp(0, 255);
      gray[y * w + x] = l;
      hist[l]++;
    }
  }
  // Otsu threshold.
  final total = w * h;
  var sum = 0.0;
  for (var i = 0; i < 256; i++) {
    sum += i * hist[i];
  }
  var sumB = 0.0;
  var wB = 0;
  var best = 0.0;
  var threshold = 128;
  for (var t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB == 0) continue;
    final wF = total - wB;
    if (wF == 0) break;
    sumB += t * hist[t];
    final mB = sumB / wB;
    final mF = (sum - sumB) / wF;
    final between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) {
      best = between;
      threshold = t;
    }
  }
  // Binary mask (bright = document), then a 3x3 erosion to drop noise.
  final mask = Uint8List(w * h);
  for (var i = 0; i < mask.length; i++) {
    mask[i] = gray[i] > threshold ? 1 : 0;
  }
  final eroded = Uint8List(w * h);
  var count = 0;
  for (var y = 1; y < h - 1; y++) {
    for (var x = 1; x < w - 1; x++) {
      var all = 1;
      for (var dy = -1; dy <= 1 && all == 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          if (mask[(y + dy) * w + (x + dx)] == 0) {
            all = 0;
            break;
          }
        }
      }
      eroded[y * w + x] = all;
      count += all;
    }
  }
  final fraction = count / total;
  const inset = ScanCorners(
    NormPoint(0.04, 0.04),
    NormPoint(0.96, 0.04),
    NormPoint(0.96, 0.96),
    NormPoint(0.04, 0.96),
  );
  if (fraction < 0.12 || fraction > 0.92) return inset;

  var tlScore = double.infinity;
  var brScore = -double.infinity;
  var trScore = -double.infinity;
  var blScore = double.infinity;
  var tl = const math.Point(0, 0);
  var br = math.Point(w - 1, h - 1);
  var tr = math.Point(w - 1, 0);
  var bl = math.Point(0, h - 1);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      if (eroded[y * w + x] == 0) continue;
      final s = (x + y).toDouble();
      final d = (x - y).toDouble();
      if (s < tlScore) {
        tlScore = s;
        tl = math.Point(x, y);
      }
      if (s > brScore) {
        brScore = s;
        br = math.Point(x, y);
      }
      if (d > trScore) {
        trScore = d;
        tr = math.Point(x, y);
      }
      if (d < blScore) {
        blScore = d;
        bl = math.Point(x, y);
      }
    }
  }
  NormPoint norm(math.Point<int> pt) => NormPoint(pt.x / (w - 1), pt.y / (h - 1));
  final result = ScanCorners(norm(tl), norm(tr), norm(br), norm(bl));
  // Reject degenerate quads.
  final area = _quadArea(result);
  if (area < 0.12) return inset;
  return result;
}

double _quadArea(ScanCorners c) {
  final p = c.points;
  var a = 0.0;
  for (var i = 0; i < 4; i++) {
    final j = (i + 1) % 4;
    a += p[i].x * p[j].y - p[j].x * p[i].y;
  }
  return a.abs() / 2;
}

img.Image _blackAndWhite(img.Image src) {
  final w = src.width;
  final h = src.height;
  final lum = Float64List(w * h);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final px = src.getPixel(x, y);
      lum[y * w + x] = 0.299 * px.r + 0.587 * px.g + 0.114 * px.b;
    }
  }
  final integral = Float64List((w + 1) * (h + 1));
  for (var y = 1; y <= h; y++) {
    var rowSum = 0.0;
    for (var x = 1; x <= w; x++) {
      rowSum += lum[(y - 1) * w + (x - 1)];
      integral[y * (w + 1) + x] = integral[(y - 1) * (w + 1) + x] + rowSum;
    }
  }
  final radius = math.max(8, math.max(w, h) ~/ 32);
  final out = img.Image(width: w, height: h, numChannels: 3);
  for (var y = 0; y < h; y++) {
    final y1 = math.max(0, y - radius);
    final y2 = math.min(h, y + radius + 1);
    for (var x = 0; x < w; x++) {
      final x1 = math.max(0, x - radius);
      final x2 = math.min(w, x + radius + 1);
      final area = (x2 - x1) * (y2 - y1);
      final s = integral[y2 * (w + 1) + x2] -
          integral[y1 * (w + 1) + x2] -
          integral[y2 * (w + 1) + x1] +
          integral[y1 * (w + 1) + x1];
      final mean = s / area;
      final v = lum[y * w + x] < mean * 0.9 ? 0 : 255;
      out.setPixelRgb(x, y, v, v, v);
    }
  }
  return out;
}

/// Applies rotation, perspective correction and filters. Runs in an isolate.
Uint8List renderScanSync(Uint8List bytes, ScanEdit edit, {int? maxSide, int quality = 90}) {
  var image = _decode(bytes, maxSide: maxSide);
  final turns = edit.quarterTurns % 4;
  if (turns != 0) image = img.copyRotate(image, angle: 90.0 * turns);

  if (!edit.corners.isFull) {
    final c = edit.corners;
    final w = image.width.toDouble();
    final h = image.height.toDouble();
    double dist(NormPoint a, NormPoint b) =>
        math.sqrt(math.pow((a.x - b.x) * w, 2) + math.pow((a.y - b.y) * h, 2));
    var outW = math.max(dist(c.tl, c.tr), dist(c.bl, c.br));
    var outH = math.max(dist(c.tl, c.bl), dist(c.tr, c.br));
    final long = math.max(outW, outH);
    if (long > 2600) {
      outW = outW * 2600 / long;
      outH = outH * 2600 / long;
    }
    final target = img.Image(
      width: math.max(16, outW.round()),
      height: math.max(16, outH.round()),
      numChannels: 3,
    );
    img.Point pt(NormPoint n) => img.Point(n.x * (w - 1), n.y * (h - 1));
    image = img.copyRectify(
      image,
      topLeft: pt(c.tl),
      topRight: pt(c.tr),
      bottomLeft: pt(c.bl),
      bottomRight: pt(c.br),
      toImage: target,
      interpolation: img.Interpolation.linear,
    );
  }

  switch (edit.filter) {
    case ScanFilter.original:
      break;
    case ScanFilter.enhanced:
      image = img.normalize(image, min: 0, max: 255);
      image = img.adjustColor(image, contrast: 1.2, saturation: 1.05);
    case ScanFilter.grayscale:
      image = img.grayscale(image);
      image = img.normalize(image, min: 0, max: 255);
    case ScanFilter.blackWhite:
      image = _blackAndWhite(image);
  }
  if (edit.brightness != 1.0 || edit.contrast != 1.0) {
    image = img.adjustColor(image, brightness: edit.brightness, contrast: edit.contrast);
  }
  return img.encodeJpg(image, quality: quality);
}

/// Scanner image operations that run in background isolates.
class ScannerService {
  const ScannerService();

  Future<ScanCorners> detectCorners(Uint8List bytes) =>
      Isolate.run(() => detectCornersSync(bytes));

  /// Rotated, downscaled copy used as the canvas for corner editing.
  Future<Uint8List> basePreview(Uint8List bytes, int quarterTurns, {int maxSide = 1200}) {
    return Isolate.run(() {
      var image = _decode(bytes, maxSide: maxSide);
      final turns = quarterTurns % 4;
      if (turns != 0) image = img.copyRotate(image, angle: 90.0 * turns);
      return img.encodeJpg(image, quality: 85);
    });
  }

  Future<Uint8List> render(
    Uint8List bytes,
    ScanEdit edit, {
    int? maxSide,
    int quality = 90,
  }) =>
      Isolate.run(() => renderScanSync(bytes, edit, maxSide: maxSide, quality: quality));
}
