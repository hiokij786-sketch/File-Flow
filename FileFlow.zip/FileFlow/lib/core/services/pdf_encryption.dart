import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' show md5;
// ignore_for_file: implementation_imports
import 'package:pdf/pdf.dart' as pdfl;
import 'package:pdf/src/pdf/format/num.dart' as pdfl;
import 'package:pdf/src/pdf/format/object_base.dart' as pdfl;
import 'package:pdf/src/pdf/format/string.dart' as pdfl;

/// Plain RC4 stream cipher (needed by the PDF standard security handler).
Uint8List rc4(Uint8List key, Uint8List data) {
  final s = Uint8List(256);
  for (var i = 0; i < 256; i++) {
    s[i] = i;
  }
  var j = 0;
  for (var i = 0; i < 256; i++) {
    j = (j + s[i] + key[i % key.length]) & 0xff;
    final t = s[i];
    s[i] = s[j];
    s[j] = t;
  }
  final out = Uint8List(data.length);
  var a = 0;
  var b = 0;
  for (var k = 0; k < data.length; k++) {
    a = (a + 1) & 0xff;
    b = (b + s[a]) & 0xff;
    final t = s[a];
    s[a] = s[b];
    s[b] = t;
    out[k] = data[k] ^ s[(s[a] + s[b]) & 0xff];
  }
  return out;
}

const List<int> _passwordPadding = [
  0x28, 0xBF, 0x4E, 0x5E, 0x4E, 0x75, 0x8A, 0x41, //
  0x64, 0x00, 0x4E, 0x56, 0xFF, 0xFA, 0x01, 0x08,
  0x2E, 0x2E, 0x00, 0xB6, 0xD0, 0x68, 0x3E, 0x80,
  0x2F, 0x0C, 0xA9, 0xFE, 0x64, 0x53, 0x69, 0x7A,
];

Uint8List _pad(String password) {
  final bytes = latin1.encode(
    String.fromCharCodes(password.codeUnits.map((c) => c > 255 ? 63 : c)),
  );
  final out = Uint8List(32);
  final n = bytes.length > 32 ? 32 : bytes.length;
  for (var i = 0; i < 32; i++) {
    out[i] = i < n ? bytes[i] : _passwordPadding[i - n];
  }
  return out;
}

Uint8List _md5(List<int> data) => Uint8List.fromList(md5.convert(data).bytes);

Uint8List _xorKey(Uint8List key, int value) =>
    Uint8List.fromList(key.map((b) => b ^ value).toList());

/// PDF standard security handler, revision 3 (RC4, 128 bit key).
///
/// This is the widely supported "Standard" encryption (PDF 1.4). It protects the
/// document with a user password that is required to open it.
class StandardRc4Encryption extends pdfl.PdfEncryption {
  StandardRc4Encryption(
    super.pdfDocument, {
    required String userPassword,
    String? ownerPassword,
  }) {
    final id = pdfDocument.documentID;
    _o = computeOwnerEntry(userPassword, ownerPassword ?? '');
    _key = computeFileKey(userPassword, _o, _permissions, id);
    _u = computeUserEntry(_key, id);
  }

  static const int _permissions = -4; // all permissions granted after opening

  late final Uint8List _o;
  late final Uint8List _u;
  late final Uint8List _key;

  /// Algorithm 3 of ISO 32000-1: computes the /O entry.
  static Uint8List computeOwnerEntry(String user, String owner) {
    var hash = _md5(_pad(owner.isEmpty ? user : owner));
    for (var i = 0; i < 50; i++) {
      hash = _md5(hash);
    }
    final key = Uint8List.sublistView(hash, 0, 16);
    var data = rc4(Uint8List.fromList(key), _pad(user));
    for (var i = 1; i <= 19; i++) {
      data = rc4(_xorKey(Uint8List.fromList(key), i), data);
    }
    return data;
  }

  /// Algorithm 2 of ISO 32000-1: computes the file encryption key.
  static Uint8List computeFileKey(
    String user,
    Uint8List o,
    int permissions,
    Uint8List id,
  ) {
    final p = ByteData(4)..setInt32(0, permissions, Endian.little);
    var hash = _md5([
      ..._pad(user),
      ...o,
      ...p.buffer.asUint8List(),
      ...id,
    ]);
    for (var i = 0; i < 50; i++) {
      hash = _md5(Uint8List.sublistView(hash, 0, 16));
    }
    return Uint8List.fromList(Uint8List.sublistView(hash, 0, 16));
  }

  /// Algorithm 5 of ISO 32000-1: computes the /U entry.
  static Uint8List computeUserEntry(Uint8List key, Uint8List id) {
    final hash = _md5([..._passwordPadding, ...id]);
    var data = rc4(key, hash);
    for (var i = 1; i <= 19; i++) {
      data = rc4(_xorKey(key, i), data);
    }
    return Uint8List.fromList([...data, ...List<int>.filled(16, 0)]);
  }

  @override
  void prepare() {
    super.prepare();
    params['/Filter'] = const pdfl.PdfName('/Standard');
    params['/V'] = const pdfl.PdfNum(2);
    params['/R'] = const pdfl.PdfNum(3);
    params['/Length'] = const pdfl.PdfNum(128);
    params['/P'] = const pdfl.PdfNum(_permissions);
    params['/O'] = pdfl.PdfString(
      _o,
      format: pdfl.PdfStringFormat.binary,
      encrypted: false,
    );
    params['/U'] = pdfl.PdfString(
      _u,
      format: pdfl.PdfStringFormat.binary,
      encrypted: false,
    );
  }

  @override
  Uint8List encrypt(Uint8List input, pdfl.PdfObjectBase object) {
    final n = object.objser;
    final g = object.objgen;
    final objectKey = _md5([
      ..._key,
      n & 0xff,
      (n >> 8) & 0xff,
      (n >> 16) & 0xff,
      g & 0xff,
      (g >> 8) & 0xff,
    ]);
    return rc4(Uint8List.sublistView(objectKey, 0, 16), input);
  }
}
