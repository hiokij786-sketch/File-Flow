import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:pdf/pdf.dart' as pdfl;
import 'package:pdf/widgets.dart' as pw;
import 'package:pdfrx/pdfrx.dart';

import '../errors/app_exception.dart';
import '../utilities/cancel_token.dart';
import 'pdf_encryption.dart';

/// A PDF chosen by the user, with the password that unlocked it (if any).
class PdfSource {
  const PdfSource({
    required this.path,
    required this.name,
    required this.sizeBytes,
    this.pageCount = 0,
    this.password,
  });

  final String path;
  final String name;
  final int sizeBytes;
  final int pageCount;
  final String? password;
}

/// One page of an output document: which source page and how it is rotated.
class PageSelection {
  const PageSelection(this.index, {this.quarterTurns = 0});

  /// Zero based index in the source document.
  final int index;
  final int quarterTurns;
}

/// Information shown on the PDF information screen.
class PdfInfo {
  const PdfInfo({
    required this.name,
    required this.sizeBytes,
    required this.pageCount,
    required this.isEncrypted,
    required this.metadata,
    this.version,
    this.created,
    this.modified,
    this.allowsCopying,
    this.allowsPrinting,
  });

  final String name;
  final int sizeBytes;
  final int pageCount;
  final bool isEncrypted;
  final String? version;
  final DateTime? created;
  final DateTime? modified;
  final bool? allowsCopying;
  final bool? allowsPrinting;
  final Map<String, String> metadata;
}

enum CompressionLevel {
  low('Low', 'Lossless re-save. Text stays selectable.', 0, 0),
  medium('Medium', 'Pages may be re-encoded at 130 dpi.', 130, 70),
  high('High', 'Pages may be re-encoded at 96 dpi.', 96, 50);

  const CompressionLevel(this.label, this.description, this.dpi, this.quality);

  final String label;
  final String description;
  final int dpi;
  final int quality;
}

class PdfCompressResult {
  const PdfCompressResult({
    required this.originalSize,
    required this.method,
    this.bytes,
    this.note,
  });

  final int originalSize;
  final Uint8List? bytes;
  final String method;
  final String? note;

  bool get reduced => bytes != null && bytes!.length < originalSize;
  int get resultSize => bytes?.length ?? originalSize;
}

enum PdfPageSizeChoice { a4, letter, custom }

enum PdfOrientation { portrait, landscape, auto }

class ImagesToPdfOptions {
  const ImagesToPdfOptions({
    this.size = PdfPageSizeChoice.a4,
    this.orientation = PdfOrientation.auto,
    this.customWidthMm = 210,
    this.customHeightMm = 297,
    this.marginMm = 10,
    this.fill = false,
    this.quality = 85,
  });

  final PdfPageSizeChoice size;
  final PdfOrientation orientation;
  final double customWidthMm;
  final double customHeightMm;
  final double marginMm;

  /// `false` = fit the whole image inside the page, `true` = fill the page.
  final bool fill;
  final int quality;
}

class _PreparedImage {
  const _PreparedImage(this.jpeg, this.width, this.height);
  final Uint8List jpeg;
  final int width;
  final int height;
}

class _JpegPage {
  const _JpegPage(this.jpeg, this.widthPt, this.heightPt);
  final Uint8List jpeg;
  final double widthPt;
  final double heightPt;
}

/// Parses a page range expression such as `1-3, 5, 8-` into zero based groups.
///
/// Every comma separated part becomes one group. Throws [AppException] for
/// invalid input.
List<List<int>> parsePageRanges(String input, int pageCount) {
  final text = input.trim();
  if (text.isEmpty) {
    throw const AppException('Enter at least one page or range, e.g. 1-3, 5.');
  }
  final groups = <List<int>>[];
  for (final raw in text.split(',')) {
    final part = raw.trim();
    if (part.isEmpty) continue;
    final match = RegExp(r'^(\d*)\s*-\s*(\d*)$').firstMatch(part);
    int start;
    int end;
    if (match != null) {
      final a = match.group(1)!;
      final b = match.group(2)!;
      if (a.isEmpty && b.isEmpty) {
        throw AppException('"$part" is not a valid range.');
      }
      start = a.isEmpty ? 1 : int.parse(a);
      end = b.isEmpty ? pageCount : int.parse(b);
    } else if (RegExp(r'^\d+$').hasMatch(part)) {
      start = int.parse(part);
      end = start;
    } else {
      throw AppException('"$part" is not a valid page or range.');
    }
    if (start < 1 || end < 1 || start > pageCount || end > pageCount) {
      throw AppException('"$part" is outside 1-$pageCount.');
    }
    if (start > end) {
      throw AppException('"$part" starts after it ends.');
    }
    groups.add([for (var i = start; i <= end; i++) i - 1]);
  }
  if (groups.isEmpty) {
    throw const AppException('Enter at least one page or range, e.g. 1-3, 5.');
  }
  return groups;
}

/// All PDF operations. Everything runs locally; heavy encoding work is moved to
/// background isolates and PDF parsing happens in the pdfrx worker isolate.
class PdfService {
  const PdfService();

  static Future<void>? _initialization;

  /// How the PDFium engine is initialized. Tests running on a desktop host
  /// replace this with the pure Dart initializer.
  static Future<void> Function() initializer = pdfrxFlutterInitialize;

  /// Initializes the PDFium engine once.
  static Future<void> ensureInitialized() => _initialization ??= initializer();

  /// Opens a PDF. Throws [PasswordRequiredException] or [WrongPasswordException]
  /// for protected documents and [AppException] for damaged files.
  Future<PdfDocument> open(String path, {String? password}) async {
    await ensureInitialized();
    var offered = false;
    try {
      return await PdfDocument.openFile(
        path,
        passwordProvider: () {
          if (offered || password == null || password.isEmpty) return null;
          offered = true;
          return password;
        },
      );
    } on PdfPasswordException {
      if (password == null || password.isEmpty) {
        throw const PasswordRequiredException();
      }
      throw const WrongPasswordException();
    } on PdfException {
      throw const AppException(
        'This PDF could not be opened. The file may be damaged or is not a PDF.',
      );
    }
  }

  /// Opens [path] to validate it and read the page count.
  Future<PdfSource> inspect(
    String path, {
    String? password,
  }) async {
    final doc = await open(path, password: password);
    try {
      final size = await File(path).length();
      return PdfSource(
        path: path,
        name: p.basename(path),
        sizeBytes: size,
        pageCount: doc.pages.length,
        password: password,
      );
    } finally {
      await doc.dispose();
    }
  }

  // ---------------------------------------------------------------- info

  Future<PdfInfo> info(String path, {String? password}) async {
    final doc = await open(path, password: password);
    try {
      final file = File(path);
      final stat = await file.stat();
      final raw = await _readMetadata(file);
      final permissions = doc.permissions;
      return PdfInfo(
        name: p.basename(path),
        sizeBytes: stat.size,
        pageCount: doc.pages.length,
        isEncrypted: doc.isEncrypted,
        version: raw.version,
        created: raw.fields.containsKey('CreationDate')
            ? parsePdfDate(raw.fields['CreationDate']!)
            : null,
        modified: raw.fields.containsKey('ModDate')
            ? parsePdfDate(raw.fields['ModDate']!)
            : stat.modified,
        allowsCopying: permissions?.allowsCopying,
        allowsPrinting: permissions?.allowsPrinting,
        metadata: {
          for (final e in raw.fields.entries)
            if (e.key != 'CreationDate' && e.key != 'ModDate') e.key: e.value,
        },
      );
    } finally {
      await doc.dispose();
    }
  }

  Future<({String? version, Map<String, String> fields})> _readMetadata(
    File file,
  ) async {
    final length = await file.length();
    if (length > 200 * 1024 * 1024) return (version: null, fields: const <String, String>{});
    final bytes = await file.readAsBytes();
    return parseRawMetadata(bytes);
  }

  /// Extracts the PDF version and simple Info dictionary fields from raw bytes.
  static ({String? version, Map<String, String> fields}) parseRawMetadata(
    Uint8List bytes,
  ) {
    final text = String.fromCharCodes(bytes);
    final versionMatch = RegExp(r'^%PDF-(\d\.\d)').firstMatch(
      text.substring(0, text.length < 20 ? text.length : 20),
    );
    final fields = <String, String>{};
    for (final key in const [
      'Title',
      'Author',
      'Subject',
      'Keywords',
      'Creator',
      'Producer',
      'CreationDate',
      'ModDate',
    ]) {
      final matches = RegExp('/$key\\s*\\(((?:\\\\.|[^\\\\)])*)\\)').allMatches(text);
      if (matches.isNotEmpty) {
        final value = matches.last.group(1)!.replaceAllMapped(
              RegExp(r'\\(.)'),
              (m) => m.group(1)!,
            );
        final clean = value.replaceAll(RegExp(r'[^\x20-\x7E]'), '').trim();
        if (clean.isNotEmpty) fields[key] = clean;
      }
    }
    return (version: versionMatch?.group(1), fields: fields);
  }

  /// Parses `D:YYYYMMDDHHmmSS` PDF dates.
  static DateTime? parsePdfDate(String value) {
    final m = RegExp(r'D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?')
        .firstMatch(value);
    if (m == null) return null;
    int g(int i, int fallback) =>
        m.group(i) == null ? fallback : int.parse(m.group(i)!);
    try {
      return DateTime(g(1, 1970), g(2, 1), g(3, 1), g(4, 0), g(5, 0), g(6, 0));
    } on Object {
      return null;
    }
  }

  // ------------------------------------------------- page based editing

  /// Builds a new document made from [selection] pages of [sourcePath].
  Future<Uint8List> buildFromPages(
    String sourcePath,
    List<PageSelection> selection, {
    String? password,
  }) async {
    if (selection.isEmpty) {
      throw const AppException('Select at least one page.');
    }
    final src = await open(sourcePath, password: password);
    try {
      return await _buildFrom(src, selection);
    } finally {
      await src.dispose();
    }
  }

  Future<Uint8List> _buildFrom(
    PdfDocument src,
    List<PageSelection> selection,
  ) async {
    final out = await PdfDocument.createNew(sourceName: 'output.pdf');
    try {
      final pages = <PdfPage>[];
      for (final s in selection) {
        if (s.index < 0 || s.index >= src.pages.length) {
          throw AppException('Page ${s.index + 1} does not exist.');
        }
        var page = src.pages[s.index];
        final turns = s.quarterTurns % 4;
        if (turns != 0) {
          page = page.rotatedBy(PdfPageRotation.values[turns]);
        }
        pages.add(page);
      }
      out.pages = pages;
      return await out.encodePdf();
    } finally {
      await out.dispose();
    }
  }

  /// Merges [sources] (in order) into a single PDF.
  Future<Uint8List> merge(
    List<PdfSource> sources, {
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    if (sources.length < 2) {
      throw const AppException('Select at least two PDF files to merge.');
    }
    final docs = <PdfDocument>[];
    PdfDocument? out;
    try {
      for (var i = 0; i < sources.length; i++) {
        cancel?.throwIfCancelled();
        onProgress?.call(
          i / (sources.length + 1),
          'Reading ${sources[i].name}',
        );
        docs.add(await open(sources[i].path, password: sources[i].password));
      }
      cancel?.throwIfCancelled();
      onProgress?.call(sources.length / (sources.length + 1), 'Merging pages');
      out = await PdfDocument.createNew(sourceName: 'merged.pdf');
      out.pages = [for (final d in docs) ...d.pages];
      final bytes = await out.encodePdf();
      onProgress?.call(1, 'Done');
      return bytes;
    } finally {
      for (final d in docs) {
        await d.dispose();
      }
      await out?.dispose();
    }
  }

  /// Splits [path] into one PDF per page group. [onFile] receives each result
  /// as soon as it is built so that it can be saved immediately.
  Future<void> splitGroups(
    String path,
    List<List<int>> groups, {
    String? password,
    required Future<void> Function(int groupIndex, Uint8List bytes) onFile,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    final src = await open(path, password: password);
    try {
      for (var i = 0; i < groups.length; i++) {
        cancel?.throwIfCancelled();
        onProgress?.call(i / groups.length, 'Creating file ${i + 1} of ${groups.length}');
        final bytes = await _buildFrom(src, [for (final g in groups[i]) PageSelection(g)]);
        await onFile(i, bytes);
      }
      onProgress?.call(1, 'Done');
    } finally {
      await src.dispose();
    }
  }

  // ------------------------------------------------------------ rendering

  /// Renders [page] to BGRA pixels at [scale] (1.0 = 72 dpi).
  Future<PdfImage?> renderPage(PdfPage page, {required double scale}) {
    const maxSide = 7000.0;
    var w = page.width * scale;
    var h = page.height * scale;
    final big = w > h ? w : h;
    if (big > maxSide) {
      w = w * maxSide / big;
      h = h * maxSide / big;
    }
    final wi = w.round().clamp(1, 7000);
    final hi = h.round().clamp(1, 7000);
    return page.render(
      width: wi,
      height: hi,
      fullWidth: wi.toDouble(),
      fullHeight: hi.toDouble(),
      backgroundColor: 0xFFFFFFFF,
    );
  }

  /// Renders [page] into a Flutter image, e.g. for thumbnails.
  Future<ui.Image?> renderUiImage(PdfPage page, {required double targetWidth}) async {
    final scale = targetWidth / page.width;
    final image = await renderPage(page, scale: scale);
    if (image == null) return null;
    try {
      final pixels = Uint8List.fromList(image.pixels);
      final completer = Completer<ui.Image>();
      ui.decodeImageFromPixels(
        pixels,
        image.width,
        image.height,
        ui.PixelFormat.bgra8888,
        completer.complete,
      );
      return await completer.future;
    } finally {
      image.dispose();
    }
  }

  static Future<Uint8List> _encodeBgra(
    Uint8List bgra,
    int width,
    int height, {
    required bool png,
    required int quality,
  }) {
    return Isolate.run(() {
      final image = img.Image.fromBytes(
        width: width,
        height: height,
        bytes: bgra.buffer,
        order: img.ChannelOrder.bgra,
        numChannels: 4,
      );
      return png ? img.encodePng(image) : img.encodeJpg(image, quality: quality);
    });
  }

  /// Exports pages of a PDF as PNG/JPEG images.
  Future<void> pdfToImages(
    String path, {
    List<int>? pages,
    required bool png,
    required int dpi,
    int quality = 90,
    String? password,
    required Future<void> Function(int pageNumber, Uint8List bytes) onPage,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    final doc = await open(path, password: password);
    try {
      final indexes = pages ?? List<int>.generate(doc.pages.length, (i) => i);
      for (var n = 0; n < indexes.length; n++) {
        cancel?.throwIfCancelled();
        final index = indexes[n];
        onProgress?.call(n / indexes.length, 'Rendering page ${index + 1}');
        final rendered = await renderPage(
          doc.pages[index],
          scale: dpi.clamp(36, 300) / 72.0,
        );
        if (rendered == null) {
          throw AppException('Page ${index + 1} could not be rendered.');
        }
        final pixels = Uint8List.fromList(rendered.pixels);
        final w = rendered.width;
        final h = rendered.height;
        rendered.dispose();
        final bytes = await _encodeBgra(pixels, w, h, png: png, quality: quality);
        await onPage(index + 1, bytes);
      }
      onProgress?.call(1, 'Done');
    } finally {
      await doc.dispose();
    }
  }

  // ------------------------------------------------------------ compress

  Future<List<_JpegPage>> _rasterPages(
    PdfDocument doc, {
    required int dpi,
    required int quality,
    ProgressCallback? onProgress,
    CancelToken? cancel,
    double progressStart = 0,
    double progressSpan = 1,
    String label = 'Optimizing page',
  }) async {
    final result = <_JpegPage>[];
    for (var i = 0; i < doc.pages.length; i++) {
      cancel?.throwIfCancelled();
      onProgress?.call(
        progressStart + progressSpan * i / doc.pages.length,
        '$label ${i + 1} of ${doc.pages.length}',
      );
      final page = doc.pages[i];
      final rendered = await renderPage(page, scale: dpi / 72.0);
      if (rendered == null) {
        throw AppException('Page ${i + 1} could not be rendered.');
      }
      final pixels = Uint8List.fromList(rendered.pixels);
      final w = rendered.width;
      final h = rendered.height;
      rendered.dispose();
      final jpeg = await _encodeBgra(pixels, w, h, png: false, quality: quality);
      result.add(_JpegPage(jpeg, page.width, page.height));
    }
    return result;
  }

  Future<Uint8List> _pdfFromJpegPages(
    List<_JpegPage> pages, {
    String? userPassword,
    String? ownerPassword,
  }) async {
    final document = pw.Document(compress: true);
    for (final page in pages) {
      final image = pw.MemoryImage(page.jpeg);
      document.addPage(
        pw.Page(
          pageFormat: pdfl.PdfPageFormat(page.widthPt, page.heightPt),
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
        ),
      );
    }
    if (userPassword != null && userPassword.isNotEmpty) {
      document.document.encryption = StandardRc4Encryption(
        document.document,
        userPassword: userPassword,
        ownerPassword: ownerPassword,
      );
    }
    return document.save();
  }

  /// Compresses a PDF. The smallest valid candidate wins, and a result is only
  /// reported when it is really smaller than the original.
  Future<PdfCompressResult> compress(
    String path,
    CompressionLevel level, {
    String? password,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    final original = await File(path).length();
    final doc = await open(path, password: password);
    try {
      onProgress?.call(0.02, 'Optimizing document structure');
      Uint8List? best;
      var method = 'Lossless re-save';
      final structural = await doc.encodePdf();
      if (structural.length < original) best = structural;
      cancel?.throwIfCancelled();

      String? note;
      if (level != CompressionLevel.low) {
        final pages = await _rasterPages(
          doc,
          dpi: level.dpi,
          quality: level.quality,
          onProgress: onProgress,
          cancel: cancel,
          progressStart: 0.05,
          progressSpan: 0.85,
        );
        onProgress?.call(0.92, 'Building compressed PDF');
        final raster = await _pdfFromJpegPages(pages);
        if (raster.length < (best?.length ?? original)) {
          best = raster;
          method = 'Pages re-encoded at ${level.dpi} dpi';
          note = 'Pages were converted to images, so text is no longer selectable.';
        }
      }
      onProgress?.call(1, 'Done');
      if (best == null) {
        return PdfCompressResult(
          originalSize: original,
          method: method,
          note: 'This PDF is already well optimized. A smaller file could not be '
              'produced without losing quality, so no output was created.',
        );
      }
      return PdfCompressResult(
        originalSize: original,
        bytes: best,
        method: method,
        note: note,
      );
    } finally {
      await doc.dispose();
    }
  }

  // ------------------------------------------------------ images to PDF

  static Future<_PreparedImage> _prepareImage(
    String path,
    int maxSide,
    int quality,
  ) {
    return Isolate.run(() {
      final bytes = File(path).readAsBytesSync();
      var image = img.decodeImage(bytes);
      if (image == null) {
        throw const AppException('An image could not be read. It may be damaged.');
      }
      image = img.bakeOrientation(image);
      if (image.hasAlpha) {
        final background = img.Image(width: image.width, height: image.height, numChannels: 3);
        img.fill(background, color: img.ColorRgb8(255, 255, 255));
        img.compositeImage(background, image);
        image = background;
      }
      final longSide = image.width > image.height ? image.width : image.height;
      if (longSide > maxSide) {
        image = image.width >= image.height
            ? img.copyResize(image, width: maxSide, interpolation: img.Interpolation.average)
            : img.copyResize(image, height: maxSide, interpolation: img.Interpolation.average);
      }
      return _PreparedImage(
        img.encodeJpg(image, quality: quality),
        image.width,
        image.height,
      );
    });
  }

  /// Builds a PDF with one image per page.
  Future<Uint8List> imagesToPdf(
    List<String> paths,
    ImagesToPdfOptions options, {
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    if (paths.isEmpty) throw const AppException('Select at least one image.');
    final document = pw.Document(compress: true);
    final maxSide = 1000 + options.quality * 20;
    for (var i = 0; i < paths.length; i++) {
      cancel?.throwIfCancelled();
      onProgress?.call(i / paths.length, 'Adding image ${i + 1} of ${paths.length}');
      final prepared = await _prepareImage(paths[i], maxSide, options.quality);
      final image = pw.MemoryImage(prepared.jpeg);
      final format = _pageFormatFor(options, prepared.width, prepared.height);
      final margin = options.marginMm * pdfl.PdfPageFormat.mm;
      document.addPage(
        pw.Page(
          pageFormat: format,
          margin: pw.EdgeInsets.all(margin),
          build: (_) => pw.ClipRect(
            child: pw.SizedBox.expand(
              child: pw.Image(
                image,
                fit: options.fill ? pw.BoxFit.cover : pw.BoxFit.contain,
              ),
            ),
          ),
        ),
      );
    }
    onProgress?.call(0.97, 'Writing PDF');
    final bytes = await document.save();
    onProgress?.call(1, 'Done');
    return bytes;
  }

  pdfl.PdfPageFormat _pageFormatFor(ImagesToPdfOptions o, int w, int h) {
    var base = switch (o.size) {
      PdfPageSizeChoice.a4 => pdfl.PdfPageFormat.a4,
      PdfPageSizeChoice.letter => pdfl.PdfPageFormat.letter,
      PdfPageSizeChoice.custom => pdfl.PdfPageFormat(
          o.customWidthMm.clamp(30, 2000) * pdfl.PdfPageFormat.mm,
          o.customHeightMm.clamp(30, 2000) * pdfl.PdfPageFormat.mm,
        ),
    };
    final portrait = base.width <= base.height;
    final wantLandscape = switch (o.orientation) {
      PdfOrientation.portrait => false,
      PdfOrientation.landscape => true,
      PdfOrientation.auto => w > h,
    };
    if (wantLandscape == portrait) {
      base = pdfl.PdfPageFormat(base.height, base.width);
    }
    return base;
  }

  // --------------------------------------------------------- protection

  /// Creates a password protected copy.
  ///
  /// Because PDF pages cannot be re-encrypted in place on-device, the copy is
  /// built from page images (150 dpi); text in the copy is not selectable.
  Future<Uint8List> protect(
    String path, {
    required String userPassword,
    String? ownerPassword,
    String? sourcePassword,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    if (userPassword.isEmpty) {
      throw const AppException('Enter a password.');
    }
    final doc = await open(path, password: sourcePassword);
    try {
      final pages = await _rasterPages(
        doc,
        dpi: 150,
        quality: 85,
        onProgress: onProgress,
        cancel: cancel,
        progressSpan: 0.9,
        label: 'Protecting page',
      );
      onProgress?.call(0.95, 'Encrypting');
      final bytes = await _pdfFromJpegPages(
        pages,
        userPassword: userPassword,
        ownerPassword: ownerPassword,
      );
      onProgress?.call(1, 'Done');
      return bytes;
    } finally {
      await doc.dispose();
    }
  }

  /// Removes password protection. The correct password is mandatory; documents
  /// are never unlocked without it.
  Future<Uint8List> removePassword(String path, String password) async {
    if (password.isEmpty) throw const PasswordRequiredException();
    final doc = await open(path, password: password);
    try {
      if (!doc.isEncrypted) {
        throw const AppException('This PDF is not password protected.');
      }
      return await doc.encodePdf(removeSecurity: true);
    } finally {
      await doc.dispose();
    }
  }

  /// Quick check whether a PDF needs a password to open.
  Future<bool> needsPassword(String path) async {
    try {
      final doc = await open(path);
      await doc.dispose();
      return false;
    } on PasswordRequiredException {
      return true;
    }
  }

  // ------------------------------------------------------------ text PDF

  /// Converts plain text to a PDF (Latin characters only; the built-in PDF
  /// fonts do not contain other scripts).
  Future<Uint8List> textToPdf(String text, {double fontSize = 12}) async {
    final cleaned = text
        .replaceAll('\r\n', '\n')
        .runes
        .map((r) => r == 10 || r == 9 || (r >= 32 && r <= 255) ? String.fromCharCode(r) : '?')
        .join()
        .replaceAll('\t', '    ');
    final document = pw.Document(compress: true);
    final lines = cleaned.split('\n');
    document.addPage(
      pw.MultiPage(
        pageFormat: pdfl.PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(48),
        build: (_) => [
          for (final line in lines)
            pw.Text(
              line.isEmpty ? ' ' : line,
              style: pw.TextStyle(fontSize: fontSize, lineSpacing: 2),
            ),
        ],
      ),
    );
    return document.save();
  }
}
