import 'package:flutter/services.dart';

import '../constants/app_constants.dart';
import '../errors/app_exception.dart';

/// Total and free bytes of a storage location.
class StorageInfo {
  const StorageInfo({required this.total, required this.free});

  final int total;
  final int free;

  int get used => total - free;
  double get usedFraction => total == 0 ? 0 : used / total;
}

/// Bridge to the Kotlin side (`MainActivity.kt`).
class NativeService {
  const NativeService();

  static const MethodChannel _channel = MethodChannel(AppConstants.nativeChannel);

  /// Opens [path] with an external app chosen by the user.
  Future<void> openFile(String path) async {
    try {
      await _channel.invokeMethod<bool>('openFile', {'path': path});
    } on PlatformException catch (e) {
      if (e.code == 'no_app') {
        throw const AppException('No installed app can open this type of file.');
      }
      if (e.code == 'missing') {
        throw const AppException('The file no longer exists.');
      }
      throw AppException('The file could not be opened.', details: e.message);
    } on MissingPluginException {
      throw const AppException('Opening files with other apps is not available on this platform.');
    }
  }

  /// Encodes image bytes (any format Android can decode) as WEBP.
  Future<Uint8List> encodeWebp(
    Uint8List bytes, {
    int quality = 80,
    bool lossless = false,
  }) async {
    try {
      final result = await _channel.invokeMethod<Uint8List>('encodeWebp', {
        'bytes': bytes,
        'quality': quality,
        'lossless': lossless,
      });
      if (result == null) throw const AppException('WEBP encoding failed.');
      return result;
    } on PlatformException catch (e) {
      throw AppException('WEBP encoding failed.', details: e.message);
    } on MissingPluginException {
      throw const AppException('WEBP encoding is only available on Android.');
    }
  }

  /// Free and total space for the volume containing [path]; `null` if unknown.
  Future<StorageInfo?> storageInfo(String path) async {
    try {
      final result = await _channel.invokeMapMethod<String, Object?>('storageInfo', {'path': path});
      if (result == null) return null;
      return StorageInfo(
        total: (result['total'] as num).toInt(),
        free: (result['free'] as num).toInt(),
      );
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }
}
