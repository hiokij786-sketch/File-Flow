import 'dart:io';

import 'package:path/path.dart' as p;

import '../errors/app_exception.dart';
import '../utilities/file_types.dart';
import '../utilities/safe_path.dart';

enum SortField { name, size, date, type }

/// A file or folder shown in the file manager.
class FileItem {
  const FileItem({
    required this.path,
    required this.name,
    required this.isDirectory,
    required this.size,
    required this.modified,
    this.childCount = 0,
  });

  final String path;
  final String name;
  final bool isDirectory;
  final int size;
  final DateTime modified;
  final int childCount;

  FileCategory get category =>
      isDirectory ? FileCategory.other : categoryOfPath(path);
}

/// File manager operations on the FILEFLOW workspace.
class FileOpsService {
  const FileOpsService();

  Future<List<FileItem>> list(
    Directory dir, {
    SortField sort = SortField.name,
    bool ascending = true,
    FileCategory? category,
  }) async {
    if (!dir.existsSync()) {
      throw const AppException('This folder is no longer available.');
    }
    final items = <FileItem>[];
    await for (final entity in dir.list(followLinks: false)) {
      final item = await _toItem(entity);
      if (item == null) continue;
      if (category != null && !item.isDirectory && item.category != category) continue;
      items.add(item);
    }
    return sortItems(items, sort, ascending);
  }

  Future<FileItem?> _toItem(FileSystemEntity entity) async {
    try {
      final stat = await entity.stat();
      final name = p.basename(entity.path);
      if (name.startsWith('.')) return null;
      if (entity is Directory) {
        var count = 0;
        await for (final _ in entity.list(followLinks: false)) {
          count++;
        }
        return FileItem(
          path: entity.path,
          name: name,
          isDirectory: true,
          size: 0,
          modified: stat.modified,
          childCount: count,
        );
      }
      if (entity is File) {
        return FileItem(
          path: entity.path,
          name: name,
          isDirectory: false,
          size: stat.size,
          modified: stat.modified,
        );
      }
    } on FileSystemException {
      return null;
    }
    return null;
  }

  /// Folders always come first; then [sort] is applied.
  static List<FileItem> sortItems(List<FileItem> items, SortField sort, bool ascending) {
    final sorted = [...items];
    sorted.sort((a, b) {
      if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
      var result = switch (sort) {
        SortField.name => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
        SortField.size => a.size.compareTo(b.size),
        SortField.date => a.modified.compareTo(b.modified),
        SortField.type => extensionOf(a.path).compareTo(extensionOf(b.path)),
      };
      if (result == 0) {
        result = a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
      return ascending ? result : -result;
    });
    return sorted;
  }

  /// Recursive, case-insensitive name search below [root].
  Future<List<FileItem>> search(Directory root, String query, {int limit = 200}) async {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return const [];
    final found = <FileItem>[];
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (p.basename(entity.path).toLowerCase().contains(q)) {
        final item = await _toItem(entity);
        if (item != null) found.add(item);
        if (found.length >= limit) break;
      }
    }
    return found;
  }

  Future<Directory> createFolder(Directory parent, String name) async {
    final clean = sanitizeFileName(name, fallback: 'New folder');
    final path = p.join(parent.path, clean);
    if (Directory(path).existsSync() || File(path).existsSync()) {
      throw AppException('"$clean" already exists.');
    }
    return Directory(path).create();
  }

  /// Renames a file or folder in place. Refuses to overwrite.
  Future<String> rename(String path, String newName) async {
    final clean = sanitizeFileName(newName);
    final target = p.join(p.dirname(path), clean);
    if (target == path) return path;
    if (File(target).existsSync() || Directory(target).existsSync()) {
      throw AppException('"$clean" already exists in this folder.');
    }
    final type = FileSystemEntity.typeSync(path);
    if (type == FileSystemEntityType.directory) {
      await Directory(path).rename(target);
    } else if (type == FileSystemEntityType.file) {
      await File(path).rename(target);
    } else {
      throw const AppException('The file no longer exists.');
    }
    return target;
  }

  Future<String> copy(String source, Directory destination) async {
    final type = FileSystemEntity.typeSync(source);
    if (type == FileSystemEntityType.notFound) {
      throw const AppException('The file no longer exists.');
    }
    if (type == FileSystemEntityType.directory) {
      if (p.isWithin(source, destination.path) || p.equals(source, destination.path)) {
        throw const AppException('A folder cannot be copied into itself.');
      }
      final target = uniquePath(destination.path, p.basename(source));
      await _copyDirectory(Directory(source), Directory(target));
      return target;
    }
    final target = uniquePath(destination.path, p.basename(source));
    await File(source).copy(target);
    return target;
  }

  Future<void> _copyDirectory(Directory from, Directory to) async {
    await to.create(recursive: true);
    await for (final entity in from.list(followLinks: false)) {
      final name = p.basename(entity.path);
      if (entity is Directory) {
        await _copyDirectory(entity, Directory(p.join(to.path, name)));
      } else if (entity is File) {
        await entity.copy(p.join(to.path, name));
      }
    }
  }

  /// Moves an entity. Returns the new path.
  Future<String> move(String source, Directory destination) async {
    if (p.equals(p.dirname(source), destination.path)) return source;
    if (FileSystemEntity.isDirectorySync(source) &&
        (p.isWithin(source, destination.path) || p.equals(source, destination.path))) {
      throw const AppException('A folder cannot be moved into itself.');
    }
    final target = uniquePath(destination.path, p.basename(source));
    try {
      if (FileSystemEntity.isDirectorySync(source)) {
        await Directory(source).rename(target);
      } else {
        await File(source).rename(target);
      }
    } on FileSystemException {
      await copy(source, destination);
      await delete(source);
      return uniquePath(destination.path, p.basename(source));
    }
    return target;
  }

  /// Deletes a file or folder. Callers must confirm with the user first.
  Future<void> delete(String path) async {
    final type = FileSystemEntity.typeSync(path);
    if (type == FileSystemEntityType.directory) {
      await Directory(path).delete(recursive: true);
    } else if (type == FileSystemEntityType.file) {
      await File(path).delete();
    }
  }
}
