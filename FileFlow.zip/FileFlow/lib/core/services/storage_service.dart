import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../constants/app_constants.dart';
import '../errors/app_exception.dart';
import '../utilities/file_types.dart';
import '../utilities/safe_path.dart';
import 'native_service.dart';

/// Manages FILEFLOW's workspace (processed/imported files) and temporary files.
///
/// The workspace lives in app-specific storage, so FILEFLOW needs no storage
/// permission. Users move files in and out through the system document picker.
class StorageService {
  StorageService({
    this.native = const NativeService(),
    Future<Directory> Function()? rootProvider,
    Future<Directory> Function()? tempProvider,
  })  : _rootProvider = rootProvider ?? _defaultRoot,
        _tempProvider = tempProvider ?? getTemporaryDirectory;

  final NativeService native;
  final Future<Directory> Function() _rootProvider;
  final Future<Directory> Function() _tempProvider;

  static Future<Directory> _defaultRoot() async {
    Directory? base;
    try {
      base = await getExternalStorageDirectory();
    } on Object {
      base = null;
    }
    return base ?? await getApplicationDocumentsDirectory();
  }

  Future<Directory> _ensure(String path) async {
    final dir = Directory(path);
    if (!dir.existsSync()) await dir.create(recursive: true);
    return dir;
  }

  /// Root of the FILEFLOW workspace.
  Future<Directory> workspace() async {
    final root = await _rootProvider();
    return _ensure(p.join(root.path, AppConstants.workspaceFolder));
  }

  Future<Directory> processedDir() async {
    final ws = await workspace();
    return _ensure(p.join(ws.path, AppConstants.processedFolder));
  }

  Future<Directory> importedDir() async {
    final ws = await workspace();
    return _ensure(p.join(ws.path, AppConstants.importedFolder));
  }

  /// FILEFLOW's own scratch folder inside the cache directory.
  Future<Directory> tempDir() async {
    final base = await _tempProvider();
    return _ensure(p.join(base.path, AppConstants.tempFolder));
  }

  /// Writes [bytes] to a new unique file in [dir] (never overwrites).
  Future<File> writeUnique(Directory dir, String fileName, Uint8List bytes) async {
    if (!dir.existsSync()) await dir.create(recursive: true);
    await ensureSpace(bytes.length);
    final target = uniquePath(dir.path, sanitizeFileName(fileName));
    final file = File(target);
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  /// Copies [source] into [dir] with a unique name.
  Future<File> copyUnique(File source, Directory dir, {String? fileName}) async {
    if (!dir.existsSync()) await dir.create(recursive: true);
    await ensureSpace(await source.length());
    final target = uniquePath(dir.path, sanitizeFileName(fileName ?? p.basename(source.path)));
    return source.copy(target);
  }

  /// Throws [InsufficientStorageException] when fewer than [bytes] (plus a
  /// safety margin) are free on the workspace volume.
  Future<void> ensureSpace(int bytes) async {
    final ws = await _rootProvider();
    final info = await native.storageInfo(ws.path);
    if (info == null) return;
    const margin = 16 * 1024 * 1024;
    if (info.free < bytes + margin) {
      throw const InsufficientStorageException(
        'Not enough free storage on this device for this operation.',
      );
    }
  }

  Future<StorageInfo?> deviceStorage() async {
    final root = await _rootProvider();
    return native.storageInfo(root.path);
  }

  /// Total size in bytes of all files below [dir].
  Future<int> directorySize(Directory dir) async {
    if (!dir.existsSync()) return 0;
    var total = 0;
    try {
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          try {
            total += await entity.length();
          } on FileSystemException {
            continue;
          }
        }
      }
    } on FileSystemException {
      return total;
    }
    return total;
  }

  /// Size per [FileCategory] for everything in the workspace.
  Future<Map<FileCategory, int>> categoryBreakdown() async {
    final ws = await workspace();
    final result = {for (final c in FileCategory.values) c: 0};
    await for (final entity in ws.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          final c = categoryOfPath(entity.path);
          result[c] = result[c]! + await entity.length();
        } on FileSystemException {
          continue;
        }
      }
    }
    return result;
  }

  Future<int> temporarySize() async {
    final base = await _tempProvider();
    return directorySize(base);
  }

  /// Deletes temporary files (cache and scratch folders). Never touches user
  /// documents in the workspace. Returns the number of bytes freed.
  Future<int> clearTemporary() async {
    final base = await _tempProvider();
    final before = await directorySize(base);
    if (base.existsSync()) {
      await for (final entity in base.list(followLinks: false)) {
        try {
          await entity.delete(recursive: true);
        } on FileSystemException {
          continue;
        }
      }
    }
    final after = await directorySize(base);
    return before - after;
  }

  /// Largest files in the workspace, biggest first.
  Future<List<File>> largestFiles({int limit = 20}) async {
    final ws = await workspace();
    final files = <File>[];
    final sizes = <String, int>{};
    await for (final entity in ws.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          sizes[entity.path] = await entity.length();
          files.add(entity);
        } on FileSystemException {
          continue;
        }
      }
    }
    files.sort((a, b) => sizes[b.path]!.compareTo(sizes[a.path]!));
    return files.take(limit).toList();
  }
}
