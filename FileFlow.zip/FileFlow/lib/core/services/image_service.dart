import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import '../errors/app_exception.dart';
import '../utilities/cancel_token.dart';
import 'native_service.dart';

enum OutputImageFormat {
  jpg('JPG', 'jpg'),
  png('PNG', 'png'),
  webp('WEBP', 'webp');

  const OutputImageFormat(this.label, this.extension);

  final String label;
  final String extension;

  static OutputImageFormat fromName(String? name) => OutputImageFormat.values.firstWhere(
        (f) => f.name == name,
        orElse: () => OutputImageFormat.jpg,
      );
}

/// Normalized crop rectangle (all values 0..1 relative to the image).
class CropRect {
  const CropRect(this.left, this.top, this.right, this.bottom);

  final double left;
  final double top;
  final double right;
  final double bottom;

  static const full = CropRect(0, 0, 1, 1);
}

/// All edits that can be applied to an image in one pass.
class ImageEdit {
  const ImageEdit({
    this.format = OutputImageFormat.jpg,
    this.quality = 80,
    this.width,
    this.height,
    this.maxLongSide,
    this.scale,
    this.quarterTurns = 0,
    this.flipHorizontal = false,
    this.crop,
  });

  final OutputImageFormat format;

  /// 1..100. For PNG this does not apply (PNG is lossless).
  final int quality;
  final int? width;
  final int? height;
  final int? maxLongSide;

  /// Uniform scale factor (0..1] applied after cropping, e.g. 0.5 for half size.
  final double? scale;
  final int quarterTurns;
  final bool flipHorizontal;
  final CropRect? crop;
}

/// Decodes [bytes] and returns the dimensions after EXIF orientation is applied.
({int width, int height}) _readSize(Uint8List bytes) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) {
    throw const AppException('This image could not be read. It may be damaged.');
  }
  final baked = img.bakeOrientation(decoded);
  return (width: baked.width, height: baked.height);
}

/// Applies [edit] to [bytes] and encodes the result. Runs inside an isolate.
/// For WEBP targets a lossless PNG is returned (the native codec finishes it).
Uint8List applyImageEdit(Uint8List bytes, ImageEdit edit) {
  var image = img.decodeImage(bytes);
  if (image == null) {
    throw const AppException('This image could not be read. It may be damaged.');
  }
  image = img.bakeOrientation(image);
  final turns = edit.quarterTurns % 4;
  if (turns != 0) image = img.copyRotate(image, angle: 90.0 * turns);
  if (edit.flipHorizontal) image = img.flip(image, direction: img.FlipDirection.horizontal);

  final crop = edit.crop;
  if (crop != null) {
    final x = (crop.left * image.width).round().clamp(0, image.width - 1);
    final y = (crop.top * image.height).round().clamp(0, image.height - 1);
    final w = ((crop.right - crop.left) * image.width).round().clamp(1, image.width - x);
    final h = ((crop.bottom - crop.top) * image.height).round().clamp(1, image.height - y);
    image = img.copyCrop(image, x: x, y: y, width: w, height: h);
  }

  if (edit.scale != null && edit.scale! > 0 && edit.scale! < 1) {
    final w = (image.width * edit.scale!).round().clamp(1, image.width);
    image = img.copyResize(image, width: w, interpolation: img.Interpolation.cubic);
  } else if (edit.width != null || edit.height != null) {
    final w = edit.width;
    final h = edit.height;
    if (w != null && h != null) {
      image = img.copyResize(image, width: w, height: h, interpolation: img.Interpolation.cubic);
    } else if (w != null) {
      image = img.copyResize(image, width: w, interpolation: img.Interpolation.cubic);
    } else if (h != null) {
      image = img.copyResize(image, height: h, interpolation: img.Interpolation.cubic);
    }
  } else if (edit.maxLongSide != null) {
    final limit = edit.maxLongSide!;
    final long = image.width > image.height ? image.width : image.height;
    if (long > limit) {
      image = image.width >= image.height
          ? img.copyResize(image, width: limit, interpolation: img.Interpolation.cubic)
          : img.copyResize(image, height: limit, interpolation: img.Interpolation.cubic);
    }
  }

  switch (edit.format) {
    case OutputImageFormat.jpg:
      if (image.hasAlpha) {
        final background = img.Image(width: image.width, height: image.height, numChannels: 3);
        img.fill(background, color: img.ColorRgb8(255, 255, 255));
        img.compositeImage(background, image);
        image = background;
      }
      return img.encodeJpg(image, quality: edit.quality.clamp(1, 100));
    case OutputImageFormat.png:
    case OutputImageFormat.webp:
      return img.encodePng(image, level: edit.format == OutputImageFormat.png ? 9 : 1);
  }
}

/// Result of processing one image.
class ImageResult {
  const ImageResult({required this.bytes, required this.originalSize});

  final Uint8List bytes;
  final int originalSize;

  int get size => bytes.length;
}

/// Image compression, resizing, cropping, rotation and format conversion.
class ImageService {
  const ImageService({this.native = const NativeService()});

  final NativeService native;

  /// Applies [edit] to [bytes]. Heavy work runs in a background isolate.
  Future<Uint8List> process(Uint8List bytes, ImageEdit edit) async {
    final encoded = await Isolate.run(() => applyImageEdit(bytes, edit));
    if (edit.format == OutputImageFormat.webp) {
      return native.encodeWebp(
        encoded,
        quality: edit.quality,
        lossless: edit.quality >= 100,
      );
    }
    return encoded;
  }

  Future<ImageResult> processFile(String path, ImageEdit edit) async {
    final file = File(path);
    if (!file.existsSync()) {
      throw const AppException('An image no longer exists.');
    }
    final bytes = await file.readAsBytes();
    final out = await process(bytes, edit);
    return ImageResult(bytes: out, originalSize: bytes.length);
  }

  /// Processes many files sequentially with real progress. [onResult] receives
  /// every finished image so that it can be saved immediately.
  Future<void> processBatch(
    List<String> paths,
    ImageEdit edit, {
    required Future<void> Function(String sourcePath, ImageResult result) onResult,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    for (var i = 0; i < paths.length; i++) {
      cancel?.throwIfCancelled();
      onProgress?.call(i / paths.length, 'Processing image ${i + 1} of ${paths.length}');
      final result = await processFile(paths[i], edit);
      await onResult(paths[i], result);
    }
    onProgress?.call(1, 'Done');
  }

  /// Pixel size of an image (EXIF orientation applied).
  Future<({int width, int height})> sizeOf(String path) async {
    final bytes = await File(path).readAsBytes();
    return Isolate.run(() => _readSize(bytes));
  }
}
