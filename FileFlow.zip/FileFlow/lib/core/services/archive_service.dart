import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive_io.dart';
import 'package:path/path.dart' as p;

import '../errors/app_exception.dart';
import '../utilities/cancel_token.dart';
import '../utilities/safe_path.dart';

/// One entry of an archive.
class ArchiveEntryInfo {
  const ArchiveEntryInfo({
    required this.name,
    required this.size,
    required this.isFile,
    required this.isSafe,
  });

  final String name;
  final int size;
  final bool isFile;

  /// `false` for entries with absolute paths, `..` segments, or symlinks.
  /// Unsafe entries are never extracted.
  final bool isSafe;
}

class ExtractionResult {
  const ExtractionResult({required this.written, required this.skipped});

  final List<String> written;

  /// Names of entries skipped because they were unsafe.
  final List<String> skipped;
}

/// A file to be added to a new ZIP archive.
class ArchiveInput {
  const ArchiveInput(this.path, {this.entryName});

  final String path;
  final String? entryName;
}

/// ZIP browsing, safe extraction and creation. Only ZIP is supported.
class ArchiveService {
  const ArchiveService();

  /// Returns a human readable name for formats FILEFLOW cannot open, or `null`.
  static String? unsupportedFormat(Uint8List header) {
    bool starts(List<int> magic) {
      if (header.length < magic.length) return false;
      for (var i = 0; i < magic.length; i++) {
        if (header[i] != magic[i]) return false;
      }
      return true;
    }

    if (starts([0x52, 0x61, 0x72, 0x21])) return 'RAR';
    if (starts([0x37, 0x7A, 0xBC, 0xAF])) return '7-Zip';
    if (starts([0x1F, 0x8B])) return 'GZIP';
    if (starts([0x42, 0x5A, 0x68])) return 'BZIP2';
    if (starts([0xFD, 0x37, 0x7A, 0x58])) return 'XZ';
    return null;
  }

  static bool _hasZipSignature(Uint8List header) =>
      header.length >= 4 &&
      header[0] == 0x50 &&
      header[1] == 0x4B &&
      (header[2] == 3 || header[2] == 5) &&
      (header[3] == 4 || header[3] == 6);

  Future<Uint8List> _header(File file) async {
    final raf = await file.open();
    try {
      return await raf.read(8);
    } finally {
      await raf.close();
    }
  }

  Future<Archive> _open(String path) async {
    final file = File(path);
    if (!file.existsSync()) {
      throw const AppException('The archive no longer exists.');
    }
    final header = await _header(file);
    final unsupported = unsupportedFormat(header);
    if (unsupported != null) {
      throw AppException(
        '$unsupported archives are not supported. FILEFLOW can open ZIP files only.',
      );
    }
    if (!_hasZipSignature(header)) {
      throw const AppException('This is not a valid ZIP archive.');
    }
    try {
      return ZipDecoder().decodeStream(InputFileStream(path));
    } on Object {
      throw const AppException('This ZIP archive is damaged or uses unsupported features.');
    }
  }

  /// Lists the entries of the ZIP archive at [path].
  Future<List<ArchiveEntryInfo>> list(String path) async {
    final archive = await _open(path);
    try {
      return [
        for (final f in archive.files)
          ArchiveEntryInfo(
            name: f.name,
            size: f.size,
            isFile: f.isFile,
            isSafe: isSafeArchiveEntryName(f.name) && !f.isSymbolicLink,
          ),
      ];
    } finally {
      await archive.clear();
    }
  }

  /// Extracts entries of [zipPath] into [destination].
  ///
  /// [only] limits extraction to the named entries, [renames] maps an entry
  /// name to a new file name (same folder). Existing files are never
  /// overwritten and unsafe entries are skipped.
  Future<ExtractionResult> extract(
    String zipPath,
    Directory destination, {
    Set<String>? only,
    Map<String, String> renames = const {},
    Future<void> Function(int requiredBytes)? checkSpace,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    final archive = await _open(zipPath);
    final written = <String>[];
    final skipped = <String>[];
    try {
      final entries = archive.files
          .where((f) => only == null || only.contains(f.name))
          .toList();
      final total = entries.fold<int>(0, (sum, f) => sum + (f.isFile ? f.size : 0));
      if (checkSpace != null) await checkSpace(total);
      if (!destination.existsSync()) await destination.create(recursive: true);

      final root = p.normalize(destination.absolute.path);
      for (var i = 0; i < entries.length; i++) {
        cancel?.throwIfCancelled();
        final entry = entries[i];
        onProgress?.call(i / entries.length, 'Extracting ${p.basename(entry.name)}');
        if (!isSafeArchiveEntryName(entry.name) || entry.isSymbolicLink) {
          skipped.add(entry.name);
          continue;
        }
        var relative = entry.name.replaceAll('\\', '/');
        final rename = renames[entry.name];
        if (rename != null && entry.isFile) {
          relative = p.posix.join(p.posix.dirname(relative), sanitizeFileName(rename));
          if (p.posix.dirname(entry.name.replaceAll('\\', '/')) == '.') {
            relative = sanitizeFileName(rename);
          }
        }
        final target = p.normalize(p.join(root, relative));
        if (!p.isWithin(root, target)) {
          skipped.add(entry.name);
          continue;
        }
        if (entry.isFile) {
          final parent = Directory(p.dirname(target));
          if (!parent.existsSync()) await parent.create(recursive: true);
          final unique = uniquePath(parent.path, p.basename(target));
          final out = OutputFileStream(unique);
          try {
            entry.writeContent(out);
          } finally {
            await out.close();
          }
          written.add(unique);
        } else {
          await Directory(target).create(recursive: true);
        }
      }
      onProgress?.call(1, 'Done');
      return ExtractionResult(written: written, skipped: skipped);
    } finally {
      await archive.clear();
    }
  }

  /// Creates a ZIP at [outputPath] from [inputs]. [level] is 0 (store) to 9.
  Future<File> create(
    List<ArchiveInput> inputs,
    String outputPath, {
    int level = 6,
    ProgressCallback? onProgress,
    CancelToken? cancel,
  }) async {
    if (inputs.isEmpty) throw const AppException('Select at least one file.');
    final encoder = ZipFileEncoder();
    final used = <String>{};
    try {
      encoder.create(outputPath, level: level);
      for (var i = 0; i < inputs.length; i++) {
        cancel?.throwIfCancelled();
        final input = inputs[i];
        final file = File(input.path);
        if (!file.existsSync()) {
          throw AppException('"${p.basename(input.path)}" no longer exists.');
        }
        onProgress?.call(i / inputs.length, 'Adding ${p.basename(input.path)}');
        var name = sanitizeFileName(input.entryName ?? p.basename(input.path));
        var counter = 1;
        final base = p.basenameWithoutExtension(name);
        final ext = p.extension(name);
        while (!used.add(name)) {
          name = '$base ($counter)$ext';
          counter++;
        }
        await encoder.addFile(file, name);
      }
      await encoder.close();
      onProgress?.call(1, 'Done');
      return File(outputPath);
    } on Object {
      try {
        await encoder.close();
      } on Object {
        // Closing a half written archive can fail; the file is removed below.
      }
      final partial = File(outputPath);
      if (partial.existsSync()) await partial.delete();
      rethrow;
    }
  }
}
