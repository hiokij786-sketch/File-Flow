import 'dart:typed_data';

import 'package:material_ui/material_ui.dart';

import '../../app/theme/app_colors.dart';
import '../services/scanner_service.dart';

/// Shows an image with four draggable corner handles.
///
/// In [rectangular] mode the handles always form an axis-aligned rectangle
/// (used for cropping). Otherwise they can move freely (document scanning with
/// perspective correction). Coordinates are normalized 0..1.
class CropEditor extends StatefulWidget {
  const CropEditor({
    super.key,
    required this.imageBytes,
    required this.imageAspect,
    required this.corners,
    required this.onChanged,
    this.rectangular = false,
  });

  final Uint8List imageBytes;

  /// Width divided by height of the displayed image.
  final double imageAspect;
  final ScanCorners corners;
  final ValueChanged<ScanCorners> onChanged;
  final bool rectangular;

  @override
  State<CropEditor> createState() => _CropEditorState();
}

class _CropEditorState extends State<CropEditor> {
  int? _active;
  static const double _minSize = 0.06;

  Rect _imageRect(Size area) {
    final areaAspect = area.width / area.height;
    double w;
    double h;
    if (widget.imageAspect > areaAspect) {
      w = area.width;
      h = w / widget.imageAspect;
    } else {
      h = area.height;
      w = h * widget.imageAspect;
    }
    return Rect.fromLTWH((area.width - w) / 2, (area.height - h) / 2, w, h);
  }

  Offset _toScreen(NormPoint p, Rect r) => Offset(r.left + p.x * r.width, r.top + p.y * r.height);

  void _update(int index, Offset local, Rect r) {
    var x = ((local.dx - r.left) / r.width).clamp(0.0, 1.0);
    var y = ((local.dy - r.top) / r.height).clamp(0.0, 1.0);
    final pts = widget.corners.points;
    if (widget.rectangular) {
      final opp = pts[(index + 2) % 4];
      switch (index) {
        case 0:
          x = x.clamp(0.0, opp.x - _minSize);
          y = y.clamp(0.0, opp.y - _minSize);
        case 1:
          x = x.clamp(opp.x + _minSize, 1.0);
          y = y.clamp(0.0, opp.y - _minSize);
        case 2:
          x = x.clamp(opp.x + _minSize, 1.0);
          y = y.clamp(opp.y + _minSize, 1.0);
        case 3:
          x = x.clamp(0.0, opp.x - _minSize);
          y = y.clamp(opp.y + _minSize, 1.0);
      }
      final left = x < opp.x ? x : opp.x;
      final right = x < opp.x ? opp.x : x;
      final top = y < opp.y ? y : opp.y;
      final bottom = y < opp.y ? opp.y : y;
      widget.onChanged(
        ScanCorners(
          NormPoint(left, top),
          NormPoint(right, top),
          NormPoint(right, bottom),
          NormPoint(left, bottom),
        ),
      );
      return;
    }
    final next = [...pts];
    next[index] = NormPoint(x, y);
    widget.onChanged(ScanCorners(next[0], next[1], next[2], next[3]));
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final area = Size(constraints.maxWidth, constraints.maxHeight);
        final rect = _imageRect(area);
        final screenPoints = [for (final p in widget.corners.points) _toScreen(p, rect)];
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanStart: (d) {
            var best = -1;
            var bestDist = 56.0;
            for (var i = 0; i < 4; i++) {
              final dist = (screenPoints[i] - d.localPosition).distance;
              if (dist < bestDist) {
                bestDist = dist;
                best = i;
              }
            }
            _active = best >= 0 ? best : null;
          },
          onPanUpdate: (d) {
            final i = _active;
            if (i != null) _update(i, d.localPosition, rect);
          },
          onPanEnd: (_) => _active = null,
          child: Stack(
            children: [
              Positioned.fromRect(
                rect: rect,
                child: Image.memory(widget.imageBytes, fit: BoxFit.fill, gaplessPlayback: true),
              ),
              Positioned.fill(
                child: CustomPaint(painter: _OverlayPainter(screenPoints, rect)),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _OverlayPainter extends CustomPainter {
  _OverlayPainter(this.points, this.imageRect);

  final List<Offset> points;
  final Rect imageRect;

  @override
  void paint(Canvas canvas, Size size) {
    final quad = Path()..addPolygon(points, true);
    final dim = Path.combine(
      PathOperation.difference,
      Path()..addRect(imageRect),
      quad,
    );
    canvas.drawPath(dim, Paint()..color = Colors.black.withValues(alpha: 0.5));
    canvas.drawPath(
      quad,
      Paint()
        ..color = AppColors.gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    for (final p in points) {
      canvas.drawCircle(p, 13, Paint()..color = Colors.white);
      canvas.drawCircle(p, 13, Paint()
        ..color = AppColors.gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3);
      canvas.drawCircle(p, 4, Paint()..color = AppColors.gold);
    }
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter old) =>
      old.points != points || old.imageRect != imageRect;
}
