import 'dart:io';

import 'package:material_ui/material_ui.dart';

import '../utilities/file_types.dart';
import 'common.dart';

/// One row in [SelectedFilesList].
class SelectedItem {
  const SelectedItem({required this.path, required this.title, required this.subtitle});

  final String path;
  final String title;
  final String subtitle;
}

/// Reorderable list of selected files with remove buttons.
class SelectedFilesList extends StatelessWidget {
  const SelectedFilesList({
    super.key,
    required this.items,
    required this.onRemove,
    this.onReorder,
    this.imageThumbnails = false,
  });

  final List<SelectedItem> items;
  final void Function(int index) onRemove;
  final void Function(int oldIndex, int newIndex)? onReorder;
  final bool imageThumbnails;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget leading(SelectedItem item) {
      if (imageThumbnails && isImagePath(item.path)) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.file(
            File(item.path),
            width: 46,
            height: 46,
            fit: BoxFit.cover,
            cacheWidth: 140,
            errorBuilder: (_, _, _) => const IconBadge(Icons.broken_image_outlined, size: 46),
          ),
        );
      }
      return FileTypeBadge(categoryOfPath(item.path), size: 46);
    }

    Widget row(int index) {
      final item = items[index];
      return Padding(
        key: ValueKey('${item.path}#$index'),
        padding: const EdgeInsets.only(bottom: 8),
        child: AppCard(
          padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
          child: Row(
            children: [
              if (onReorder != null) ...[
                ReorderableDragStartListener(
                  index: index,
                  child: Icon(Icons.drag_indicator_rounded, color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(width: 8),
              ],
              leading(item),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${index + 1}. ${item.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      item.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Remove',
                icon: const Icon(Icons.close_rounded),
                onPressed: () => onRemove(index),
              ),
            ],
          ),
        ),
      );
    }

    if (onReorder == null) {
      return Column(children: [for (var i = 0; i < items.length; i++) row(i)]);
    }
    return ReorderableListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      buildDefaultDragHandles: false,
      itemCount: items.length,
      onReorderItem: (oldIndex, newIndex) => onReorder!(oldIndex, newIndex),
      itemBuilder: (_, i) => row(i),
    );
  }
}
