import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../../app/theme/app_colors.dart';
import '../errors/app_exception.dart';
import '../providers.dart';
import '../services/output_service.dart';
import '../utilities/cancel_token.dart';
import '../utilities/file_types.dart';
import '../utilities/format.dart';
import 'common.dart';

enum ToolPhase { configure, running, done, failed }

/// What a tool returns when it finishes.
class ToolOutcome {
  const ToolOutcome({
    this.files = const [],
    this.note,
    this.extra,
    this.headline,
    this.success = true,
  });

  final List<ProcessedFile> files;
  final String? note;
  final Widget? extra;
  final String? headline;

  /// `false` when the job ran fine but produced nothing worth saving.
  final bool success;
}

/// Services and callbacks available to a running tool job.
class ToolJobContext {
  ToolJobContext(this._ref, this._onProgress, this.cancel);

  final WidgetRef _ref;
  final ProgressCallback _onProgress;
  final CancelToken cancel;
  final List<ProcessedFile> _saved = [];

  void report(double fraction, String message) => _onProgress(fraction.clamp(0, 1), message);

  /// Saves output bytes to the Processed folder.
  Future<ProcessedFile> save(Uint8List bytes, String fileName, {String? subfolder}) async {
    final file = await _ref.read(outputServiceProvider).save(bytes, fileName, subfolder: subfolder);
    _saved.add(file);
    return file;
  }

  /// Progress callback to hand to services.
  ProgressCallback get progress => report;

  Future<void> _discardSaved() async {
    for (final f in _saved) {
      try {
        final file = File(f.path);
        if (file.existsSync()) await file.delete();
      } on FileSystemException {
        continue;
      }
    }
    _saved.clear();
  }
}

/// Shared workflow for every tool: configure -> process (real progress,
/// cancellable) -> result (preview, save, share, open).
mixin ToolRunMixin<T extends ConsumerStatefulWidget> on ConsumerState<T> {
  ToolPhase phase = ToolPhase.configure;
  double progressValue = 0;
  String progressMessage = 'Preparing…';
  CancelToken? _token;
  ToolOutcome? outcome;
  String? errorMessage;
  String? errorDetails;

  bool get isRunning => phase == ToolPhase.running;

  /// Runs [job] and moves through the processing/result/error screens.
  Future<void> runTool(
    Future<ToolOutcome> Function(ToolJobContext ctx) job, {
    int requiredBytes = 0,
  }) async {
    final token = CancelToken();
    _token = token;
    setState(() {
      phase = ToolPhase.running;
      progressValue = 0;
      progressMessage = 'Preparing…';
    });
    final ctx = ToolJobContext(ref, (fraction, message) {
      if (!mounted) return;
      setState(() {
        progressValue = fraction;
        progressMessage = message;
      });
    }, token);
    try {
      await ref.read(storageServiceProvider).ensureSpace(requiredBytes);
      final result = await job(ctx);
      token.throwIfCancelled();
      await ref.read(libraryProvider.notifier).refresh();
      if (!mounted) return;
      setState(() {
        outcome = result;
        phase = ToolPhase.done;
      });
      final settings = ref.read(settingsProvider);
      if (settings.askWhereToSave && result.files.length == 1) {
        try {
          await ref.read(outputServiceProvider).exportCopy(result.files.first.path);
        } on Object {
          // The saved copy in FILEFLOW is still available; ignore export errors here.
        }
      }
    } on CancelledException {
      await ctx._discardSaved();
      if (!mounted) return;
      setState(() => phase = ToolPhase.configure);
      showMessage(context, 'Cancelled. No files were kept.');
    } on AppException catch (e) {
      await ctx._discardSaved();
      if (!mounted) return;
      setState(() {
        errorMessage = e.message;
        errorDetails = e.details;
        phase = ToolPhase.failed;
      });
    } on Object catch (e) {
      await ctx._discardSaved();
      if (!mounted) return;
      setState(() {
        errorMessage = 'Something went wrong while processing your files.';
        errorDetails = e.toString();
        phase = ToolPhase.failed;
      });
    } finally {
      _token = null;
    }
  }

  /// Resets to the configuration screen.
  void resetTool() => setState(() {
        phase = ToolPhase.configure;
        outcome = null;
        errorMessage = null;
        errorDetails = null;
      });

  Future<void> _confirmCancel() async {
    final ok = await confirmAction(
      context,
      title: 'Stop processing?',
      message: 'The operation will be cancelled and unfinished files discarded.',
      confirmLabel: 'Stop',
      destructive: true,
    );
    if (ok) _token?.cancel();
  }

  /// Standard scaffold for a tool screen.
  Widget buildToolScaffold({
    required String title,
    required Widget configure,
    required String actionLabel,
    required bool actionEnabled,
    required VoidCallback onAction,
    IconData actionIcon = Icons.play_arrow_rounded,
    List<Widget>? actions,
  }) {
    final Widget body = switch (phase) {
      ToolPhase.configure => configure,
      ToolPhase.running => ProcessingPanel(
          progress: progressValue,
          message: progressMessage,
          onCancel: _confirmCancel,
        ),
      ToolPhase.done => ResultPanel(
          outcome: outcome!,
          onAgain: resetTool,
        ),
      ToolPhase.failed => ErrorPanel(
          message: errorMessage ?? 'Something went wrong.',
          details: errorDetails,
          onBack: resetTool,
        ),
    };
    return PopScope(
      canPop: !isRunning,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && isRunning) _confirmCancel();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
          actions: phase == ToolPhase.configure ? actions : null,
        ),
        body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: KeyedSubtree(key: ValueKey(phase), child: body))),
        bottomNavigationBar: phase == ToolPhase.configure
            ? SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: FilledButton.icon(
                    onPressed: actionEnabled ? onAction : null,
                    icon: Icon(actionIcon),
                    label: Text(actionLabel),
                  ),
                ),
              )
            : null,
      ),
    );
  }
}

/// Real progress with cancellation.
class ProcessingPanel extends StatelessWidget {
  const ProcessingPanel({
    super.key,
    required this.progress,
    required this.message,
    required this.onCancel,
  });

  final double progress;
  final String message;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 120,
              height: 120,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox.expand(
                    child: CircularProgressIndicator(
                      value: progress <= 0 ? null : progress,
                      strokeWidth: 8,
                      strokeCap: StrokeCap.round,
                      backgroundColor: theme.colorScheme.outline,
                    ),
                  ),
                  Text(
                    '${(progress * 100).round()}%',
                    style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            Text(message, textAlign: TextAlign.center, style: theme.textTheme.titleSmall),
            const SizedBox(height: 6),
            Text(
              'Processing happens on your device.',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 28),
            OutlinedButton.icon(
              onPressed: onCancel,
              icon: const Icon(Icons.close_rounded),
              label: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Error screen with retry.
class ErrorPanel extends StatelessWidget {
  const ErrorPanel({super.key, required this.message, this.details, required this.onBack});

  final String message;
  final String? details;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: AppColors.danger.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.error_outline_rounded, size: 44, color: AppColors.danger),
            ),
            const SizedBox(height: 20),
            Text('Could not finish', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: theme.textTheme.bodyMedium),
            if (details != null && details!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                details!,
                textAlign: TextAlign.center,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onBack,
              icon: const Icon(Icons.arrow_back_rounded),
              label: const Text('Back to options'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Success screen: preview, save a copy, share, open.
class ResultPanel extends ConsumerWidget {
  const ResultPanel({super.key, required this.outcome, required this.onAgain});

  final ToolOutcome outcome;
  final VoidCallback onAgain;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final files = outcome.files;
    final hasFiles = files.isNotEmpty;
    final color = outcome.success && hasFiles ? AppColors.success : AppColors.goldDark;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SizedBox(height: 8),
        Center(
          child: Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.14), shape: BoxShape.circle),
            child: Icon(
              hasFiles ? Icons.check_rounded : Icons.info_outline_rounded,
              size: 46,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          outcome.headline ?? (hasFiles ? 'All done' : 'Nothing to save'),
          textAlign: TextAlign.center,
          style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
        ),
        if (hasFiles)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              files.length == 1
                  ? 'Saved in FILEFLOW › Processed'
                  : '${files.length} files saved in FILEFLOW › Processed',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
        if (outcome.note != null) ...[
          const SizedBox(height: 12),
          InfoBanner(outcome.note!, warning: !hasFiles),
        ],
        if (outcome.extra != null) ...[
          const SizedBox(height: 16),
          outcome.extra!,
        ],
        const SizedBox(height: 16),
        for (final file in files) _ResultFileCard(file: file),
        if (files.length > 1) ...[
          const SizedBox(height: 4),
          OutlinedButton.icon(
            onPressed: () => _run(context, ref, () => ref.read(outputServiceProvider).share([for (final f in files) f.path])),
            icon: const Icon(Icons.share_rounded),
            label: const Text('Share all'),
          ),
        ],
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(onPressed: onAgain, child: const Text('Start over')),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton(
                onPressed: () => context.canPop() ? context.pop() : context.go('/'),
                child: const Text('Done'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

Future<void> _run(BuildContext context, WidgetRef ref, Future<void> Function() action) async {
  try {
    await action();
  } on AppException catch (e) {
    if (context.mounted) showMessage(context, e.message, error: true);
  } on Object {
    if (context.mounted) showMessage(context, 'The action could not be completed.', error: true);
  }
}

class _ResultFileCard extends ConsumerWidget {
  const _ResultFileCard({required this.file});

  final ProcessedFile file;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final output = ref.read(outputServiceProvider);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
        child: Row(
          children: [
            FileTypeBadge(categoryOfPath(file.path)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(file.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                  Text(formatBytes(file.size), style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Preview',
              icon: const Icon(Icons.visibility_rounded),
              onPressed: () {
                ref.read(libraryProvider.notifier).markOpened(file.path);
                context.push('/preview', extra: file.path);
              },
            ),
            PopupMenuButton<String>(
              tooltip: 'More',
              onSelected: (value) {
                switch (value) {
                  case 'share':
                    _run(context, ref, () => output.share([file.path]));
                  case 'save':
                    _run(context, ref, () async {
                      final ok = await output.exportCopy(file.path);
                      if (ok && context.mounted) showMessage(context, 'Copy saved.');
                    });
                  case 'open':
                    _run(context, ref, () => output.openExternally(file.path));
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'share', child: Text('Share')),
                PopupMenuItem(value: 'save', child: Text('Save a copy to…')),
                PopupMenuItem(value: 'open', child: Text('Open with…')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
