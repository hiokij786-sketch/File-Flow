import 'package:material_ui/material_ui.dart';

import '../../app/theme/app_colors.dart';
import '../constants/app_constants.dart';

/// The FILEFLOW mark: a black rounded square with a gold, flowing "F".
class FileFlowLogo extends StatelessWidget {
  const FileFlowLogo({super.key, this.size = 72});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'FILEFLOW logo',
      image: true,
      child: SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: _LogoPainter()),
      ),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / 108.0;
    final background = RRectPlus(size, k);
    canvas.drawRRect(background.rrect, Paint()..color = AppColors.ink);
    final gold = Paint()..color = AppColors.gold;
    final light = Paint()..color = AppColors.goldLight;
    final path = Path()
      ..moveTo(40 * k, 30 * k)
      ..lineTo(72 * k, 30 * k)
      ..lineTo(72 * k, 40 * k)
      ..lineTo(50 * k, 40 * k)
      ..lineTo(50 * k, 78 * k)
      ..lineTo(40 * k, 78 * k)
      ..close();
    canvas.drawPath(path, gold);
    canvas.drawRect(Rect.fromLTRB(50 * k, 49 * k, 64 * k, 58 * k), light);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Helper that builds the rounded square used by the logo.
class RRectPlus {
  RRectPlus(Size size, double k)
      : rrect = RRect.fromRectAndRadius(
          Rect.fromLTWH(6 * k, 6 * k, size.width - 12 * k, size.height - 12 * k),
          Radius.circular(18 * k),
        );

  final RRect rrect;
}

/// Logo + name + tagline, used on splash-like screens.
class FileFlowWordmark extends StatelessWidget {
  const FileFlowWordmark({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        FileFlowLogo(size: compact ? 34 : 56),
        SizedBox(width: compact ? 10 : 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              AppConstants.appName,
              style: (compact ? theme.textTheme.titleMedium : theme.textTheme.headlineSmall)
                  ?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 1.6),
            ),
            if (!compact)
              Text(
                AppConstants.tagline,
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
          ],
        ),
      ],
    );
  }
}
