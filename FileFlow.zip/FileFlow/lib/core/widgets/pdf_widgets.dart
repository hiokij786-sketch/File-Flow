import 'dart:ui' as ui;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:pdfrx/pdfrx.dart';

import '../errors/app_exception.dart';
import '../providers.dart';

/// Opens a PDF, shows a spinner or error, and disposes the document.
class PdfDocumentHolder extends ConsumerStatefulWidget {
  const PdfDocumentHolder({
    super.key,
    required this.path,
    this.password,
    required this.builder,
  });

  final String path;
  final String? password;
  final Widget Function(BuildContext context, PdfDocument document) builder;

  @override
  ConsumerState<PdfDocumentHolder> createState() => _PdfDocumentHolderState();
}

class _PdfDocumentHolderState extends ConsumerState<PdfDocumentHolder> {
  PdfDocument? _document;
  String? _error;
  bool _disposed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final doc = await ref.read(pdfServiceProvider).open(widget.path, password: widget.password);
      if (_disposed) {
        await doc.dispose();
        return;
      }
      setState(() => _document = doc);
    } on AppException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } on Object {
      if (mounted) setState(() => _error = 'This PDF could not be opened.');
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _document?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)));
    }
    final doc = _document;
    if (doc == null) return const Center(child: CircularProgressIndicator());
    return widget.builder(context, doc);
  }
}

/// A lazily rendered page thumbnail.
class PdfPageThumb extends ConsumerStatefulWidget {
  const PdfPageThumb({
    super.key,
    required this.document,
    required this.pageIndex,
    this.width = 120,
    this.quarterTurns = 0,
  });

  final PdfDocument document;
  final int pageIndex;
  final double width;
  final int quarterTurns;

  @override
  ConsumerState<PdfPageThumb> createState() => _PdfPageThumbState();
}

class _PdfPageThumbState extends ConsumerState<PdfPageThumb> {
  ui.Image? _image;
  bool _failed = false;
  bool _disposed = false;

  @override
  void initState() {
    super.initState();
    _render();
  }

  Future<void> _render() async {
    try {
      final image = await ref.read(pdfServiceProvider).renderUiImage(
            widget.document.pages[widget.pageIndex],
            targetWidth: widget.width * 2,
          );
      if (_disposed || image == null) {
        image?.dispose();
        if (!_disposed && mounted) setState(() => _failed = true);
        return;
      }
      setState(() => _image = image);
    } on Object {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _image?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget child;
    final image = _image;
    if (image != null) {
      child = AspectRatio(
        aspectRatio: image.width / image.height,
        child: RawImage(image: image, fit: BoxFit.contain),
      );
    } else if (_failed) {
      child = const AspectRatio(aspectRatio: 0.707, child: Icon(Icons.broken_image_outlined));
    } else {
      child = const AspectRatio(
        aspectRatio: 0.707,
        child: Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    return Container(
      width: widget.width,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: theme.colorScheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: RotatedBox(quarterTurns: widget.quarterTurns, child: child),
    );
  }
}
