import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../core/providers.dart';
import '../core/utilities/file_types.dart';
import '../features/archive_tools/creator/zip_creator_page.dart';
import '../features/archive_tools/extractor/zip_extractor_page.dart';
import '../features/file_manager/file_manager_page.dart';
import '../features/file_manager/preview_page.dart';
import '../features/home/home_page.dart';
import '../features/home/onboarding_page.dart';
import '../features/image_tools/compressor/image_compressor_page.dart';
import '../features/image_tools/converter/convert_hub_page.dart';
import '../features/image_tools/converter/image_converter_page.dart';
import '../features/image_tools/converter/text_to_pdf_page.dart';
import '../features/image_tools/cropper/image_cropper_page.dart';
import '../features/image_tools/image_tools_page.dart';
import '../features/image_tools/resizer/image_resizer_page.dart';
import '../features/pdf_tools/compressor/compressor_page.dart';
import '../features/pdf_tools/images_to_pdf/images_to_pdf_page.dart';
import '../features/pdf_tools/information/pdf_info_page.dart';
import '../features/pdf_tools/merger/merger_page.dart';
import '../features/pdf_tools/page_organizer/page_organizer_page.dart';
import '../features/pdf_tools/pdf_to_images/pdf_to_images_page.dart';
import '../features/pdf_tools/pdf_tools_page.dart';
import '../features/pdf_tools/protection/protection_page.dart';
import '../features/pdf_tools/splitter/splitter_page.dart';
import '../features/pdf_tools/viewer/pdf_viewer_page.dart';
import '../features/scanner/scanner_page.dart';
import '../features/settings/about_pages.dart';
import '../features/settings/settings_page.dart';
import '../features/settings/storage_page.dart';
import 'back_handling.dart';

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');

/// App router: five bottom-navigation tabs plus full-screen tool routes.
final routerProvider = Provider<GoRouter>((ref) {
  final prefs = ref.read(preferencesStoreProvider);
  return GoRouter(
    navigatorKey: rootNavigatorKey,
    initialLocation: '/',
    redirect: (context, state) {
      final onboarding = state.matchedLocation == '/onboarding';
      if (!prefs.onboardingDone && !onboarding) return '/onboarding';
      if (prefs.onboardingDone && onboarding) return '/';
      return null;
    },
    errorBuilder: (context, state) => Scaffold(
      appBar: AppBar(title: const Text('Not found')),
      body: Center(
        child: FilledButton(onPressed: () => context.go('/'), child: const Text('Back to Home')),
      ),
    ),
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => _Shell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/', builder: (_, _) => const HomePage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/pdf', builder: (_, _) => const PdfToolsPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/files', builder: (_, _) => const FileManagerPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/images', builder: (_, _) => const ImageToolsPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/settings', builder: (_, _) => const SettingsPage())]),
        ],
      ),
      GoRoute(path: '/onboarding', builder: (_, _) => const OnboardingPage()),
      GoRoute(path: '/pdf/merge', builder: (_, _) => const MergerPage()),
      GoRoute(path: '/pdf/split', builder: (_, _) => const SplitterPage()),
      GoRoute(path: '/pdf/compress', builder: (_, _) => const CompressorPage()),
      GoRoute(path: '/pdf/from-images', builder: (_, _) => const ImagesToPdfPage()),
      GoRoute(path: '/pdf/to-images', builder: (_, _) => const PdfToImagesPage()),
      GoRoute(path: '/pdf/organize', builder: (_, _) => const PageOrganizerPage()),
      GoRoute(path: '/pdf/protect', builder: (_, _) => const ProtectionPage()),
      GoRoute(path: '/pdf/info', builder: (_, state) => PdfInfoPage(path: state.extra as String?)),
      GoRoute(
        path: '/pdf/viewer',
        builder: (context, state) => PdfViewerPage(path: state.extra as String? ?? ''),
      ),
      GoRoute(
        path: '/preview',
        builder: (context, state) {
          final path = state.extra as String? ?? '';
          return isPdfPath(path) ? PdfViewerPage(path: path) : PreviewPage(path: path);
        },
      ),
      GoRoute(path: '/image/compress', builder: (_, _) => const ImageCompressorPage()),
      GoRoute(path: '/image/resize', builder: (_, _) => const ImageResizerPage()),
      GoRoute(path: '/image/crop', builder: (_, _) => const ImageCropperPage()),
      GoRoute(path: '/image/convert', builder: (_, _) => const ImageConverterPage()),
      GoRoute(path: '/convert', builder: (_, _) => const ConvertHubPage()),
      GoRoute(path: '/convert/text', builder: (_, _) => const TextToPdfPage()),
      GoRoute(path: '/scanner', builder: (_, _) => const ScannerPage()),
      GoRoute(path: '/archive/extract', builder: (_, _) => const ZipExtractorPage()),
      GoRoute(path: '/archive/create', builder: (_, _) => const ZipCreatorPage()),
      GoRoute(path: '/settings/storage', builder: (_, _) => const StoragePage()),
      GoRoute(path: '/settings/privacy', builder: (_, _) => const PrivacyPage()),
      GoRoute(path: '/settings/about', builder: (_, _) => const AboutPage()),
    ],
  );
});

/// Bottom navigation shell with proper Android back handling.
class _Shell extends StatelessWidget {
  const _Shell({required this.shell});

  final StatefulNavigationShell shell;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: shell.currentIndex == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop || fileBrowserHandlesBack.value) return;
        shell.goBranch(0);
      },
      child: Scaffold(
        body: shell,
        bottomNavigationBar: NavigationBar(
          selectedIndex: shell.currentIndex,
          onDestinationSelected: (i) => shell.goBranch(i, initialLocation: i == shell.currentIndex),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.picture_as_pdf_outlined), selectedIcon: Icon(Icons.picture_as_pdf_rounded), label: 'PDF Tools'),
            NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder_rounded), label: 'Files'),
            NavigationDestination(icon: Icon(Icons.image_outlined), selectedIcon: Icon(Icons.image_rounded), label: 'Image Tools'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
          ],
        ),
      ),
    );
  }
}
