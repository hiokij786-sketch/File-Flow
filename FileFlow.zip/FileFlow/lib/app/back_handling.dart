import 'package:flutter/foundation.dart';

/// `true` while the file browser (Files tab) wants to handle the Android back
/// button itself (go up a folder, close search, leave selection mode). The
/// navigation shell checks this before switching back to the Home tab.
final ValueNotifier<bool> fileBrowserHandlesBack = ValueNotifier<bool>(false);
