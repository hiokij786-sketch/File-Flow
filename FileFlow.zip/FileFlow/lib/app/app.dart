import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../core/constants/app_constants.dart';
import '../core/providers.dart';
import 'router.dart';
import 'theme/app_theme.dart';

class FileFlowApp extends ConsumerStatefulWidget {
  const FileFlowApp({super.key});

  @override
  ConsumerState<FileFlowApp> createState() => _FileFlowAppState();
}

class _FileFlowAppState extends ConsumerState<FileFlowApp> {
  @override
  void initState() {
    super.initState();
    // Remove leftovers from previous sessions (cached picker copies, scratch
    // files). User documents in the workspace are never touched.
    Future(() async {
      try {
        await ref.read(storageServiceProvider).clearTemporary();
      } on Object {
        // Cleanup is best effort.
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final router = ref.watch(routerProvider);
    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: buildLightTheme(),
      darkTheme: buildDarkTheme(),
      themeMode: settings.themeMode,
      routerConfig: router,
    );
  }
}
