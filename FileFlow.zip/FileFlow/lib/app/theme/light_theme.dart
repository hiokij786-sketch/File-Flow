import 'package:material_ui/material_ui.dart';

import 'app_colors.dart';
import 'app_theme.dart';

/// FILEFLOW light theme: white surfaces on soft grey, black text, gold accent.
ThemeData buildLightTheme() {
  const scheme = ColorScheme(
    brightness: Brightness.light,
    primary: AppColors.ink,
    onPrimary: AppColors.white,
    primaryContainer: AppColors.goldTint,
    onPrimaryContainer: AppColors.ink,
    secondary: AppColors.gold,
    onSecondary: AppColors.ink,
    secondaryContainer: AppColors.goldTint,
    onSecondaryContainer: AppColors.goldDark,
    tertiary: AppColors.goldDark,
    onTertiary: AppColors.white,
    error: AppColors.danger,
    onError: AppColors.white,
    surface: AppColors.white,
    onSurface: AppColors.ink,
    onSurfaceVariant: AppColors.mutedText,
    outline: AppColors.outline,
    outlineVariant: AppColors.outline,
    surfaceContainerLowest: AppColors.white,
    surfaceContainerLow: AppColors.paper,
    surfaceContainer: AppColors.paper,
    surfaceContainerHigh: Color(0xFFEDEDEA),
    surfaceContainerHighest: Color(0xFFE6E6E2),
  );
  return buildFileFlowTheme(
    scheme,
    background: AppColors.paper,
    outline: AppColors.outline,
  );
}
