import 'package:material_ui/material_ui.dart';

/// FILEFLOW brand palette: white surfaces, soft grey backgrounds, black type
/// and an elegant gold accent.
class AppColors {
  const AppColors._();

  static const Color ink = Color(0xFF111111);
  static const Color gold = Color(0xFFC9A227);
  static const Color goldLight = Color(0xFFE6CB6E);
  static const Color goldDark = Color(0xFF8A6D12);
  static const Color goldTint = Color(0xFFF6EFD6);

  static const Color paper = Color(0xFFF5F5F3);
  static const Color white = Color(0xFFFFFFFF);
  static const Color outline = Color(0xFFE4E4E0);
  static const Color mutedText = Color(0xFF6B6B66);

  static const Color night = Color(0xFF0E0E0E);
  static const Color nightSurface = Color(0xFF1A1A19);
  static const Color nightSurfaceHigh = Color(0xFF242423);
  static const Color nightOutline = Color(0xFF34342F);
  static const Color nightMutedText = Color(0xFFA5A59E);

  static const Color success = Color(0xFF2E7D4F);
  static const Color danger = Color(0xFFB3261E);
}
