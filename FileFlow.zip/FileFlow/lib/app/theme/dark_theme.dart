import 'package:material_ui/material_ui.dart';

import 'app_colors.dart';
import 'app_theme.dart';

/// FILEFLOW dark theme: charcoal surfaces with gold as the primary accent.
ThemeData buildDarkTheme() {
  const scheme = ColorScheme(
    brightness: Brightness.dark,
    primary: AppColors.goldLight,
    onPrimary: AppColors.ink,
    primaryContainer: Color(0xFF3A3010),
    onPrimaryContainer: AppColors.goldLight,
    secondary: AppColors.gold,
    onSecondary: AppColors.ink,
    secondaryContainer: Color(0xFF3A3010),
    onSecondaryContainer: AppColors.goldLight,
    tertiary: AppColors.goldLight,
    onTertiary: AppColors.ink,
    error: Color(0xFFF2B8B5),
    onError: AppColors.ink,
    surface: AppColors.nightSurface,
    onSurface: Color(0xFFF2F2EE),
    onSurfaceVariant: AppColors.nightMutedText,
    outline: AppColors.nightOutline,
    outlineVariant: AppColors.nightOutline,
    surfaceContainerLowest: AppColors.night,
    surfaceContainerLow: AppColors.nightSurface,
    surfaceContainer: AppColors.nightSurface,
    surfaceContainerHigh: AppColors.nightSurfaceHigh,
    surfaceContainerHighest: Color(0xFF2E2E2C),
  );
  return buildFileFlowTheme(
    scheme,
    background: AppColors.night,
    outline: AppColors.nightOutline,
  );
}
