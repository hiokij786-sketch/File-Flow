import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../core/errors/app_exception.dart';
import '../core/providers.dart';
import '../core/widgets/common.dart';

enum ToolGroup { pdf, image, file }

/// Description of one implemented tool. Every entry opens a working feature.
class ToolInfo {
  const ToolInfo({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.route,
    required this.group,
  });

  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final String route;
  final ToolGroup group;
}

const List<ToolInfo> allTools = [
  ToolInfo(id: 'merge', title: 'Merge PDF', subtitle: 'Combine several PDFs into one', icon: Icons.merge_rounded, route: '/pdf/merge', group: ToolGroup.pdf),
  ToolInfo(id: 'split', title: 'Split PDF', subtitle: 'Split by ranges or extract pages', icon: Icons.call_split_rounded, route: '/pdf/split', group: ToolGroup.pdf),
  ToolInfo(id: 'compress_pdf', title: 'Compress PDF', subtitle: 'Reduce file size, see real savings', icon: Icons.compress_rounded, route: '/pdf/compress', group: ToolGroup.pdf),
  ToolInfo(id: 'images_to_pdf', title: 'Images to PDF', subtitle: 'A4, Letter or custom pages', icon: Icons.photo_library_rounded, route: '/pdf/from-images', group: ToolGroup.pdf),
  ToolInfo(id: 'pdf_to_images', title: 'PDF to Images', subtitle: 'Export pages as PNG or JPEG', icon: Icons.image_rounded, route: '/pdf/to-images', group: ToolGroup.pdf),
  ToolInfo(id: 'organize', title: 'Organize pages', subtitle: 'Reorder, rotate, delete, extract', icon: Icons.dashboard_customize_rounded, route: '/pdf/organize', group: ToolGroup.pdf),
  ToolInfo(id: 'viewer', title: 'PDF viewer', subtitle: 'Read with search and dark mode', icon: Icons.menu_book_rounded, route: '/pdf', group: ToolGroup.pdf),
  ToolInfo(id: 'protect', title: 'Protect PDF', subtitle: 'Add or remove a password', icon: Icons.lock_rounded, route: '/pdf/protect', group: ToolGroup.pdf),
  ToolInfo(id: 'pdf_info', title: 'PDF information', subtitle: 'Pages, size, dates, metadata', icon: Icons.info_outline_rounded, route: '/pdf/info', group: ToolGroup.pdf),
  ToolInfo(id: 'compress_image', title: 'Compress image', subtitle: 'Smaller photos, before/after preview', icon: Icons.compress_rounded, route: '/image/compress', group: ToolGroup.image),
  ToolInfo(id: 'resize_image', title: 'Resize image', subtitle: 'Custom size with aspect lock', icon: Icons.photo_size_select_large_rounded, route: '/image/resize', group: ToolGroup.image),
  ToolInfo(id: 'crop_image', title: 'Crop & rotate', subtitle: 'Crop, rotate and flip', icon: Icons.crop_rounded, route: '/image/crop', group: ToolGroup.image),
  ToolInfo(id: 'convert_image', title: 'Convert image', subtitle: 'JPG, PNG and WEBP', icon: Icons.transform_rounded, route: '/image/convert', group: ToolGroup.image),
  ToolInfo(id: 'scan', title: 'Scan document', subtitle: 'Camera, edge detection, PDF', icon: Icons.document_scanner_rounded, route: '/scanner', group: ToolGroup.file),
  ToolInfo(id: 'convert', title: 'Convert files', subtitle: 'All supported conversions', icon: Icons.swap_horiz_rounded, route: '/convert', group: ToolGroup.file),
  ToolInfo(id: 'text_to_pdf', title: 'Text to PDF', subtitle: 'Turn a .txt file into a PDF', icon: Icons.text_snippet_rounded, route: '/convert/text', group: ToolGroup.file),
  ToolInfo(id: 'extract_zip', title: 'Extract ZIP', subtitle: 'Browse and safely extract', icon: Icons.unarchive_rounded, route: '/archive/extract', group: ToolGroup.file),
  ToolInfo(id: 'create_zip', title: 'Create ZIP', subtitle: 'Bundle files into an archive', icon: Icons.archive_rounded, route: '/archive/create', group: ToolGroup.file),
];

ToolInfo toolById(String id) => allTools.firstWhere((t) => t.id == id);

List<ToolInfo> toolsIn(ToolGroup group) => allTools.where((t) => t.group == group).toList();

/// The ten dashboard quick actions.
const List<String> quickActionIds = [
  'pdf_to_images',
  'images_to_pdf',
  'compress_pdf',
  'merge',
  'split',
  'scan',
  'compress_image',
  'convert',
  'extract_zip',
  'create_zip',
];

/// Opens a tool. The viewer first asks for a PDF through the system picker.
Future<void> launchTool(BuildContext context, WidgetRef ref, ToolInfo tool) async {
  if (tool.id == 'viewer') {
    await openPdfFromDevice(context, ref);
    return;
  }
  context.push(tool.route);
}

/// Picks a PDF, keeps a copy in the FILEFLOW library and opens the viewer.
Future<void> openPdfFromDevice(BuildContext context, WidgetRef ref) async {
  try {
    final picked = await ref.read(outputServiceProvider).pick(extensions: const ['pdf'], multiple: false);
    if (picked.isEmpty) return;
    final storage = ref.read(storageServiceProvider);
    final copy = await storage.copyUnique(File(picked.first.path), await storage.importedDir(), fileName: picked.first.name);
    await ref.read(libraryProvider.notifier).markOpened(copy.path);
    if (context.mounted) context.push('/pdf/viewer', extra: copy.path);
  } on AppException catch (e) {
    if (context.mounted) showMessage(context, e.message, error: true);
  }
}
