import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/constants/app_constants.dart';
import '../../../core/providers.dart';
import '../../../core/services/image_service.dart';
import '../../../core/services/output_service.dart';
import '../../../core/services/scanner_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/crop_editor.dart';
import '../../../core/widgets/tool_run.dart';

/// Crop, rotate and flip a single image.
class ImageCropperPage extends ConsumerStatefulWidget {
  const ImageCropperPage({super.key});

  @override
  ConsumerState<ImageCropperPage> createState() => _ImageCropperPageState();
}

class _ImageCropperPageState extends ConsumerState<ImageCropperPage> with ToolRunMixin<ImageCropperPage> {
  PickedFile? _file;
  Uint8List? _preview;
  double _aspect = 1;
  ({int width, int height})? _size;
  int _turns = 0;
  bool _flip = false;
  ScanCorners _corners = ScanCorners.full;
  late OutputImageFormat _format = ref.read(settingsProvider).defaultImageFormat;
  double _quality = 90;
  bool _loading = false;

  Future<void> _pick() async {
    final picked = await ref.read(outputServiceProvider).pick(extensions: AppConstants.imageExtensions, multiple: false);
    if (picked.isEmpty) return;
    setState(() {
      _file = picked.first;
      _turns = 0;
      _flip = false;
      _corners = ScanCorners.full;
      _loading = true;
    });
    try {
      final size = await ref.read(imageServiceProvider).sizeOf(picked.first.path);
      _size = size;
      await _refreshPreview();
    } on Object {
      if (mounted) {
        showMessage(context, 'This image could not be opened.', error: true);
        setState(() => _file = null);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refreshPreview() async {
    final file = _file;
    final size = _size;
    if (file == null || size == null) return;
    final bytes = await ref.read(imageServiceProvider).process(
          await _readBytes(file.path),
          ImageEdit(quality: 85, maxLongSide: 1400, quarterTurns: _turns, flipHorizontal: _flip),
        );
    if (!mounted) return;
    final odd = _turns % 2 == 1;
    setState(() {
      _preview = bytes;
      _aspect = odd ? size.height / size.width : size.width / size.height;
    });
  }

  Future<Uint8List> _readBytes(String path) => File(path).readAsBytes();

  Future<void> _transform({int turns = 0, bool flip = false}) async {
    setState(() {
      _turns = (_turns + turns) % 4;
      if (flip) _flip = !_flip;
      _corners = ScanCorners.full;
      _loading = true;
    });
    try {
      await _refreshPreview();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final file = _file!;
    final crop = CropRect(_corners.tl.x, _corners.tl.y, _corners.br.x, _corners.br.y);
    await runTool(
      (ctx) async {
        ctx.report(0.2, 'Applying edits');
        final result = await ref.read(imageServiceProvider).processFile(
              file.path,
              ImageEdit(
                format: _format,
                quality: _quality.round(),
                quarterTurns: _turns,
                flipHorizontal: _flip,
                crop: _corners.isFull ? null : crop,
              ),
            );
        ctx.cancel.throwIfCancelled();
        ctx.report(0.9, 'Saving');
        final saved = await ctx.save(result.bytes, '${p.basenameWithoutExtension(file.name)}_edited.${_format.extension}');
        return ToolOutcome(files: [saved], headline: 'Image saved');
      },
      requiredBytes: file.size * 3,
    );
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview;
    return buildToolScaffold(
      title: 'Crop & rotate',
      actionLabel: 'Save image',
      actionIcon: Icons.save_rounded,
      actionEnabled: preview != null && !_loading,
      onAction: _save,
      configure: _file == null
          ? EmptyState(
              icon: Icons.crop_rounded,
              title: 'Crop, rotate and flip',
              message: 'Choose an image, drag the corners to crop and rotate it in 90° steps.',
              actionLabel: 'Select an image',
              onAction: _pick,
            )
          : Column(
              children: [
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHigh,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    clipBehavior: Clip.antiAlias,
                    padding: const EdgeInsets.all(12),
                    child: preview == null
                        ? const Center(child: CircularProgressIndicator())
                        : Stack(
                            children: [
                              CropEditor(
                                imageBytes: preview,
                                imageAspect: _aspect,
                                corners: _corners,
                                rectangular: true,
                                onChanged: (c) => setState(() => _corners = c),
                              ),
                              if (_loading) const Positioned.fill(child: Center(child: CircularProgressIndicator())),
                            ],
                          ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton.filledTonal(tooltip: 'Rotate left', onPressed: _loading ? null : () => _transform(turns: 3), icon: const Icon(Icons.rotate_left_rounded)),
                      IconButton.filledTonal(tooltip: 'Rotate right', onPressed: _loading ? null : () => _transform(turns: 1), icon: const Icon(Icons.rotate_right_rounded)),
                      IconButton.filledTonal(tooltip: 'Flip horizontally', onPressed: _loading ? null : () => _transform(flip: true), icon: const Icon(Icons.flip_rounded)),
                      IconButton.filledTonal(
                        tooltip: 'Reset crop',
                        onPressed: () => setState(() => _corners = ScanCorners.full),
                        icon: const Icon(Icons.crop_free_rounded),
                      ),
                      IconButton.filledTonal(tooltip: 'Another image', onPressed: _pick, icon: const Icon(Icons.swap_horiz_rounded)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: Column(
                    children: [
                      ChoiceRow<OutputImageFormat>(
                        label: 'Save as',
                        value: _format,
                        options: OutputImageFormat.values,
                        optionLabel: (v) => v.label,
                        onChanged: (v) => setState(() => _format = v),
                      ),
                      if (_format != OutputImageFormat.png)
                        LabeledSlider(
                          label: 'Quality',
                          value: _quality,
                          min: 40,
                          max: 100,
                          divisions: 12,
                          suffix: '%',
                          onChanged: (v) => setState(() => _quality = v),
                        ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
