import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../app/tool_registry.dart';
import '../../core/widgets/common.dart';

/// Hub listing every image tool.
class ImageToolsPage extends ConsumerWidget {
  const ImageToolsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tools = [...toolsIn(ToolGroup.image), toolById('scan'), toolById('images_to_pdf')];
    return Scaffold(
      appBar: AppBar(title: const Text('Image tools')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: tools.length + 1,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          if (i == tools.length) {
            return const Padding(
              padding: EdgeInsets.only(top: 6),
              child: InfoBanner('Supports JPG, PNG and WEBP. Batch processing is available in compress, resize and convert.', icon: Icons.image_outlined),
            );
          }
          final t = tools[i];
          return ToolTile(icon: t.icon, title: t.title, subtitle: t.subtitle, onTap: () => launchTool(context, ref, t));
        },
      ),
    );
  }
}
