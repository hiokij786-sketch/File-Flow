import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/providers.dart';
import '../../../core/services/output_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/tool_run.dart';

class TextToPdfPage extends ConsumerStatefulWidget {
  const TextToPdfPage({super.key});

  @override
  ConsumerState<TextToPdfPage> createState() => _TextToPdfPageState();
}

class _TextToPdfPageState extends ConsumerState<TextToPdfPage> with ToolRunMixin<TextToPdfPage> {
  PickedFile? _file;
  String _text = '';
  int _fontSize = 12;

  Future<void> _pick() async {
    final picked = await ref.read(outputServiceProvider).pick(extensions: const ['txt', 'md', 'csv', 'log'], multiple: false);
    if (picked.isEmpty) return;
    if (picked.first.size > 5 * 1024 * 1024) {
      if (mounted) showMessage(context, 'Text files larger than 5 MB are not supported.', error: true);
      return;
    }
    final text = utf8.decode(await File(picked.first.path).readAsBytes(), allowMalformed: true);
    if (mounted) {
      setState(() {
        _file = picked.first;
        _text = text;
      });
    }
  }

  Future<void> _convert() async {
    final file = _file!;
    await runTool((ctx) async {
      ctx.report(0.3, 'Typesetting text');
      final bytes = await ref.read(pdfServiceProvider).textToPdf(_text, fontSize: _fontSize.toDouble());
      ctx.cancel.throwIfCancelled();
      final saved = await ctx.save(bytes, '${p.basenameWithoutExtension(file.name)}.pdf');
      return ToolOutcome(
        files: [saved],
        headline: 'PDF created',
        note: 'Characters outside the Latin alphabet are replaced with "?" because the built-in PDF fonts do not include them.',
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return buildToolScaffold(
      title: 'Text to PDF',
      actionLabel: 'Create PDF',
      actionIcon: Icons.picture_as_pdf_rounded,
      actionEnabled: _file != null && _text.trim().isNotEmpty,
      onAction: _convert,
      configure: _file == null
          ? EmptyState(
              icon: Icons.text_snippet_rounded,
              title: 'Convert a text file to PDF',
              message: 'Choose a .txt file (UTF-8). Lines are laid out on A4 pages.',
              actionLabel: 'Select a text file',
              onAction: _pick,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                AppCard(
                  child: Row(
                    children: [
                      const IconBadge(Icons.text_snippet_rounded),
                      const SizedBox(width: 12),
                      Expanded(child: Text(_file!.name, maxLines: 2, overflow: TextOverflow.ellipsis)),
                      TextButton(onPressed: _pick, child: const Text('Change')),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                ChoiceRow<int>(
                  label: 'Font size',
                  value: _fontSize,
                  options: const [10, 12, 14, 16],
                  optionLabel: (v) => '$v pt',
                  onChanged: (v) => setState(() => _fontSize = v),
                ),
                const SectionHeader('Preview'),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: theme.colorScheme.outline)),
                  child: Text(
                    _text.length > 900 ? '${_text.substring(0, 900)}…' : _text,
                    style: TextStyle(fontSize: _fontSize.toDouble(), color: Colors.black),
                  ),
                ),
              ],
            ),
    );
  }
}
