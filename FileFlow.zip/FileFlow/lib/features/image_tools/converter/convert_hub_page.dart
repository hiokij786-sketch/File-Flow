import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../../../core/widgets/common.dart';

/// Lists the conversions FILEFLOW can really perform on-device.
class ConvertHubPage extends ConsumerWidget {
  const ConvertHubPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = <(IconData, String, String, String)>[
      (Icons.transform_rounded, 'Image format', 'JPG ↔ PNG ↔ WEBP', '/image/convert'),
      (Icons.photo_library_rounded, 'Images to PDF', 'JPG, PNG, WEBP to PDF', '/pdf/from-images'),
      (Icons.image_rounded, 'PDF pages to images', 'PDF to PNG or JPEG', '/pdf/to-images'),
      (Icons.text_snippet_rounded, 'TXT to PDF', 'Plain text file to PDF', '/convert/text'),
      (Icons.unarchive_rounded, 'ZIP extraction', 'Extract files from ZIP', '/archive/extract'),
      (Icons.archive_rounded, 'ZIP creation', 'Bundle files into a ZIP', '/archive/create'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Convert files')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length + 1,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          if (i == items.length) {
            return const Padding(
              padding: EdgeInsets.only(top: 6),
              child: InfoBanner(
                'Only conversions that work fully offline are listed. Office documents (DOC, XLSX…) and HTML to PDF '
                'need a rendering engine that cannot run reliably on-device, so they are not offered.',
              ),
            );
          }
          final item = items[i];
          return ToolTile(icon: item.$1, title: item.$2, subtitle: item.$3, onTap: () => context.push(item.$4));
        },
      ),
    );
  }
}
