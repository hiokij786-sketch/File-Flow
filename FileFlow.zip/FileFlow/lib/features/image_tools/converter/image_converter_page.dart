import 'package:material_ui/material_ui.dart';

import '../common/image_batch_page.dart';

/// Converts images between JPG, PNG and WEBP.
class ImageConverterPage extends StatelessWidget {
  const ImageConverterPage({super.key});

  @override
  Widget build(BuildContext context) => const ImageBatchToolPage(mode: ImageToolMode.convert);
}
