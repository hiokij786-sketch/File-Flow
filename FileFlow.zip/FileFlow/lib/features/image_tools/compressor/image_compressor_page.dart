import 'package:material_ui/material_ui.dart';

import '../common/image_batch_page.dart';

/// Compresses images with quality, size and format controls.
class ImageCompressorPage extends StatelessWidget {
  const ImageCompressorPage({super.key});

  @override
  Widget build(BuildContext context) => const ImageBatchToolPage(mode: ImageToolMode.compress);
}
