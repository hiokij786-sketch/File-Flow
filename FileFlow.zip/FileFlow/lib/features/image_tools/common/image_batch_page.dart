import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/constants/app_constants.dart';
import '../../../core/providers.dart';
import '../../../core/services/image_service.dart';
import '../../../core/services/output_service.dart';
import '../../../core/utilities/file_types.dart';
import '../../../core/utilities/format.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/selected_files.dart';
import '../../../core/widgets/tool_run.dart';

enum ImageToolMode { compress, resize, convert }

/// Before/after preview for the first processed image.
class BeforeAfter extends StatelessWidget {
  const BeforeAfter({super.key, required this.original, required this.processed});

  final String original;
  final String processed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget cell(String label, String path) => Expanded(
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Image.file(File(path), fit: BoxFit.cover, cacheWidth: 500, errorBuilder: (_, _, _) => const Icon(Icons.image_not_supported_outlined)),
                ),
              ),
              const SizedBox(height: 6),
              Text(label, style: theme.textTheme.labelMedium),
            ],
          ),
        );
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [cell('Before', original), const SizedBox(width: 12), cell('After', processed)],
    );
  }
}

/// Shared implementation of the image compressor, resizer and converter.
class ImageBatchToolPage extends ConsumerStatefulWidget {
  const ImageBatchToolPage({super.key, required this.mode});

  final ImageToolMode mode;

  @override
  ConsumerState<ImageBatchToolPage> createState() => _ImageBatchToolPageState();
}

class _ImageBatchToolPageState extends ConsumerState<ImageBatchToolPage> with ToolRunMixin<ImageBatchToolPage> {
  final List<PickedFile> _images = [];
  OutputImageFormat? _format; // null = keep original format
  late double _quality = switch (widget.mode) {
    ImageToolMode.compress => 70,
    _ => 90,
  };
  int? _maxSide;
  // Resizer
  final _width = TextEditingController();
  final _height = TextEditingController();
  bool _lockAspect = true;
  double _percent = 100;
  bool _usePercent = true;
  ({int width, int height})? _firstSize;
  bool _updating = false;

  @override
  void initState() {
    super.initState();
    if (widget.mode == ImageToolMode.convert) {
      _format = ref.read(settingsProvider).defaultImageFormat;
    }
  }

  @override
  void dispose() {
    _width.dispose();
    _height.dispose();
    super.dispose();
  }

  String get _title => switch (widget.mode) {
        ImageToolMode.compress => 'Compress images',
        ImageToolMode.resize => 'Resize images',
        ImageToolMode.convert => 'Convert images',
      };

  Future<void> _add() async {
    final picked = await ref.read(outputServiceProvider).pick(extensions: AppConstants.imageExtensions);
    if (picked.isEmpty) return;
    setState(() => _images.addAll(picked));
    if (_firstSize == null) await _readFirstSize();
  }

  Future<void> _readFirstSize() async {
    if (_images.isEmpty) return;
    try {
      final size = await ref.read(imageServiceProvider).sizeOf(_images.first.path);
      if (!mounted) return;
      setState(() {
        _firstSize = size;
        _syncFromPercent();
      });
    } on Object {
      if (mounted) showMessage(context, 'The first image could not be read.', error: true);
    }
  }

  void _syncFromPercent() {
    final size = _firstSize;
    if (size == null) return;
    _updating = true;
    _width.text = (size.width * _percent / 100).round().toString();
    _height.text = (size.height * _percent / 100).round().toString();
    _updating = false;
  }

  void _onWidthChanged(String v) {
    if (_updating) return;
    final size = _firstSize;
    final w = int.tryParse(v);
    if (_lockAspect && size != null && w != null) {
      _updating = true;
      _height.text = (w * size.height / size.width).round().toString();
      _updating = false;
    }
    setState(() {});
  }

  void _onHeightChanged(String v) {
    if (_updating) return;
    final size = _firstSize;
    final h = int.tryParse(v);
    if (_lockAspect && size != null && h != null) {
      _updating = true;
      _width.text = (h * size.width / size.height).round().toString();
      _updating = false;
    }
    setState(() {});
  }

  OutputImageFormat _formatFor(String path) {
    if (_format != null) return _format!;
    return switch (extensionOf(path)) {
      'png' => OutputImageFormat.png,
      'webp' => OutputImageFormat.webp,
      _ => OutputImageFormat.jpg,
    };
  }

  bool get _resizeValid {
    if (widget.mode != ImageToolMode.resize) return true;
    if (_usePercent) return _percent > 0 && _firstSize != null;
    final w = int.tryParse(_width.text);
    final h = int.tryParse(_height.text);
    return (w != null && w > 0 && w <= 12000) && (h != null && h > 0 && h <= 12000);
  }

  ImageEdit _editFor(String path) {
    final format = _formatFor(path);
    final quality = _quality.round();
    switch (widget.mode) {
      case ImageToolMode.compress:
        return ImageEdit(format: format, quality: quality, maxLongSide: _maxSide);
      case ImageToolMode.convert:
        return ImageEdit(format: format, quality: quality);
      case ImageToolMode.resize:
        if (_usePercent) {
          return ImageEdit(format: format, quality: quality, scale: _percent / 100);
        }
        final w = int.parse(_width.text);
        final h = int.parse(_height.text);
        return _lockAspect
            ? ImageEdit(format: format, quality: quality, width: w)
            : ImageEdit(format: format, quality: quality, width: w, height: h);
    }
  }

  Future<void> _run() async {
    final images = [..._images];
    final tag = switch (widget.mode) {
      ImageToolMode.compress => 'compressed',
      ImageToolMode.resize => 'resized',
      ImageToolMode.convert => 'converted',
    };
    final saved = <ProcessedFile>[];
    final originals = <String, int>{};
    var originalTotal = 0;
    var resultTotal = 0;
    var skipped = 0;
    String? firstOriginal;
    await runTool(
      (ctx) async {
        for (var i = 0; i < images.length; i++) {
          ctx.cancel.throwIfCancelled();
          final img = images[i];
          ctx.report(i / images.length, 'Processing image ${i + 1} of ${images.length}');
          final edit = _editFor(img.path);
          final result = await ref.read(imageServiceProvider).processFile(img.path, edit);
          if (widget.mode == ImageToolMode.compress && result.size >= result.originalSize) {
            skipped++;
            continue;
          }
          final name = '${p.basenameWithoutExtension(img.name)}_$tag.${edit.format.extension}';
          final file = await ctx.save(result.bytes, widget.mode == ImageToolMode.convert ? '${p.basenameWithoutExtension(img.name)}.${edit.format.extension}' : name);
          saved.add(file);
          originals[file.path] = result.originalSize;
          originalTotal += result.originalSize;
          resultTotal += result.size;
          firstOriginal ??= img.path;
        }
        ctx.report(1, 'Done');
        if (saved.isEmpty) {
          return const ToolOutcome(
            success: false,
            headline: 'No smaller version created',
            note: 'These images are already well compressed. Each result would have been larger than the '
                'original, so nothing was saved. Try a lower quality, a smaller maximum size, or WEBP.',
          );
        }
        return ToolOutcome(
          files: saved,
          headline: switch (widget.mode) {
            ImageToolMode.compress => 'Images compressed',
            ImageToolMode.resize => 'Images resized',
            ImageToolMode.convert => 'Images converted',
          },
          note: skipped > 0
              ? '$skipped image(s) skipped because the result would have been larger than the original.'
              : null,
          extra: Column(
            children: [
              if (widget.mode != ImageToolMode.convert) ...[
                SizeComparison(original: originalTotal, result: resultTotal),
                const SizedBox(height: 12),
              ],
              BeforeAfter(original: firstOriginal!, processed: saved.first.path),
            ],
          ),
        );
      },
      requiredBytes: images.fold<int>(0, (s, e) => s + e.size) * 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final mode = widget.mode;
    final formats = mode == ImageToolMode.convert ? OutputImageFormat.values : <OutputImageFormat?>[null, ...OutputImageFormat.values];
    final effectiveFormat = _format;
    final qualityApplies = effectiveFormat != OutputImageFormat.png;
    return buildToolScaffold(
      title: _title,
      actionLabel: switch (mode) {
        ImageToolMode.compress => 'Compress',
        ImageToolMode.resize => 'Resize',
        ImageToolMode.convert => 'Convert',
      },
      actionIcon: Icons.auto_fix_high_rounded,
      actionEnabled: _images.isNotEmpty && _resizeValid,
      onAction: _run,
      configure: _images.isEmpty
          ? EmptyState(
              icon: switch (mode) {
                ImageToolMode.compress => Icons.compress_rounded,
                ImageToolMode.resize => Icons.photo_size_select_large_rounded,
                ImageToolMode.convert => Icons.transform_rounded,
              },
              title: switch (mode) {
                ImageToolMode.compress => 'Shrink your photos',
                ImageToolMode.resize => 'Resize to any dimensions',
                ImageToolMode.convert => 'Convert between JPG, PNG and WEBP',
              },
              message: 'Select one or many images. Processing is done on your device and originals are never changed.',
              actionLabel: 'Select images',
              onAction: _add,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SectionHeader('${_images.length} image(s)'),
                SelectedFilesList(
                  imageThumbnails: true,
                  items: [for (final i in _images) SelectedItem(path: i.path, title: i.name, subtitle: formatBytes(i.size))],
                  onRemove: (i) {
                    setState(() => _images.removeAt(i));
                    if (i == 0) {
                      _firstSize = null;
                      _readFirstSize();
                    }
                  },
                ),
                OutlinedButton.icon(onPressed: _add, icon: const Icon(Icons.add_photo_alternate_rounded), label: const Text('Add more')),
                const SizedBox(height: 16),
                SectionHeader(mode == ImageToolMode.resize ? 'Size' : 'Options'),
                if (mode == ImageToolMode.resize) ...[
                  ChoiceRow<bool>(
                    label: 'Resize by',
                    value: _usePercent,
                    options: const [true, false],
                    optionLabel: (v) => v ? 'Percentage' : 'Custom dimensions',
                    onChanged: (v) => setState(() => _usePercent = v),
                  ),
                  if (_usePercent)
                    LabeledSlider(
                      label: 'Scale',
                      value: _percent,
                      min: 10,
                      max: 100,
                      divisions: 18,
                      suffix: '%',
                      onChanged: (v) => setState(() {
                        _percent = v;
                        _syncFromPercent();
                      }),
                    )
                  else ...[
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _width,
                            keyboardType: TextInputType.number,
                            onChanged: _onWidthChanged,
                            decoration: const InputDecoration(labelText: 'Width', suffixText: 'px'),
                          ),
                        ),
                        IconButton(
                          tooltip: _lockAspect ? 'Aspect ratio locked' : 'Aspect ratio unlocked',
                          icon: Icon(_lockAspect ? Icons.link_rounded : Icons.link_off_rounded),
                          color: _lockAspect ? theme.colorScheme.secondary : null,
                          onPressed: () => setState(() => _lockAspect = !_lockAspect),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _height,
                            keyboardType: TextInputType.number,
                            onChanged: _onHeightChanged,
                            decoration: const InputDecoration(labelText: 'Height', suffixText: 'px'),
                          ),
                        ),
                      ],
                    ),
                    if (_images.length > 1 && _lockAspect)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: InfoBanner('With several images the width is applied and each height follows its own aspect ratio.'),
                      ),
                  ],
                ],
                if (mode == ImageToolMode.compress)
                  ChoiceRow<int?>(
                    label: 'Maximum size (long side)',
                    value: _maxSide,
                    options: const [null, 4096, 2048, 1280, 1024],
                    optionLabel: (v) => v == null ? 'Original' : '$v px',
                    onChanged: (v) => setState(() => _maxSide = v),
                  ),
                ChoiceRow<OutputImageFormat?>(
                  label: mode == ImageToolMode.convert ? 'Convert to' : 'Output format',
                  value: _format,
                  options: formats,
                  optionLabel: (v) => v?.label ?? 'Keep original',
                  onChanged: (v) => setState(() => _format = v),
                ),
                if (qualityApplies)
                  LabeledSlider(
                    label: 'Quality',
                    value: _quality,
                    min: 10,
                    max: 100,
                    divisions: 18,
                    suffix: '%',
                    onChanged: (v) => setState(() => _quality = v),
                  )
                else
                  const InfoBanner('PNG is lossless, so there is no quality setting. Resize or choose WEBP/JPG for smaller files.'),
              ],
            ),
    );
  }
}
