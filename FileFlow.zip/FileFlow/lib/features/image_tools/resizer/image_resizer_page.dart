import 'package:material_ui/material_ui.dart';

import '../common/image_batch_page.dart';

/// Resizes images by percentage or custom dimensions with aspect ratio lock.
class ImageResizerPage extends StatelessWidget {
  const ImageResizerPage({super.key});

  @override
  Widget build(BuildContext context) => const ImageBatchToolPage(mode: ImageToolMode.resize);
}
