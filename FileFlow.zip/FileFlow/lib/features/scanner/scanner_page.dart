import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../core/constants/app_constants.dart';
import '../../core/providers.dart';
import '../../core/services/pdf_service.dart';
import '../../core/services/scanner_service.dart';
import '../../core/utilities/format.dart';
import '../../core/utilities/safe_path.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/tool_run.dart';
import 'scan_edit_page.dart';

class _ScanPage {
  _ScanPage(this.path, this.edit, this.thumb);

  final String path;
  ScanEdit edit;
  Uint8List thumb;
}

/// Multi-page document scanner: camera or gallery import, edge detection,
/// perspective correction, filters, and PDF export.
class ScannerPage extends ConsumerStatefulWidget {
  const ScannerPage({super.key});

  @override
  ConsumerState<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends ConsumerState<ScannerPage> with ToolRunMixin<ScannerPage> {
  final List<_ScanPage> _pages = [];
  final _name = TextEditingController(text: 'scan');
  bool _adding = false;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _addPath(String path) async {
    final scanner = ref.read(scannerServiceProvider);
    final bytes = await File(path).readAsBytes();
    final preview = await scanner.basePreview(bytes, 0, maxSide: 900);
    final corners = await scanner.detectCorners(preview);
    final edit = ScanEdit(corners: corners);
    final thumb = await scanner.render(bytes, edit, maxSide: 360, quality: 80);
    if (mounted) setState(() => _pages.add(_ScanPage(path, edit, thumb)));
  }

  Future<void> _capture() async {
    setState(() => _adding = true);
    try {
      // The system camera app takes the photo, so FILEFLOW needs no CAMERA permission.
      final shot = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 95, maxWidth: 3600, maxHeight: 3600);
      if (shot != null) await _addPath(shot.path);
    } on Object {
      if (mounted) showMessage(context, 'The camera could not be opened. You can import photos instead.', error: true);
    } finally {
      if (mounted) setState(() => _adding = false);
    }
  }

  Future<void> _import() async {
    setState(() => _adding = true);
    try {
      final picked = await ref.read(outputServiceProvider).pick(extensions: AppConstants.imageExtensions);
      for (final f in picked) {
        await _addPath(f.path);
      }
    } on Object {
      if (mounted) showMessage(context, 'An image could not be imported.', error: true);
    } finally {
      if (mounted) setState(() => _adding = false);
    }
  }

  Future<void> _edit(int index) async {
    final page = _pages[index];
    final result = await Navigator.of(context).push<ScanEdit>(
      MaterialPageRoute(builder: (_) => ScanEditPage(path: page.path, initial: page.edit)),
    );
    if (result == null || !mounted) return;
    final bytes = await File(page.path).readAsBytes();
    final thumb = await ref.read(scannerServiceProvider).render(bytes, result, maxSide: 360, quality: 80);
    if (mounted) {
      setState(() {
        page.edit = result;
        page.thumb = thumb;
      });
    }
  }

  Future<void> _remove(int index) async {
    final ok = await confirmAction(
      context,
      title: 'Remove page ${index + 1}?',
      message: 'The page is removed from this scan. The photo itself is not deleted from your device.',
      confirmLabel: 'Remove',
      destructive: true,
    );
    if (ok && mounted) setState(() => _pages.removeAt(index));
  }

  Future<void> _export() async {
    final pages = [..._pages];
    final storage = ref.read(storageServiceProvider);
    await runTool(
      (ctx) async {
        final temp = await storage.tempDir();
        final tempFiles = <File>[];
        try {
          final scanner = ref.read(scannerServiceProvider);
          for (var i = 0; i < pages.length; i++) {
            ctx.cancel.throwIfCancelled();
            ctx.report(i / (pages.length + 1) * 0.7, 'Rendering page ${i + 1} of ${pages.length}');
            final source = await File(pages[i].path).readAsBytes();
            final rendered = await scanner.render(source, pages[i].edit, maxSide: 2600, quality: 92);
            final file = File(p.join(temp.path, 'scan_${DateTime.now().microsecondsSinceEpoch}_$i.jpg'));
            await file.writeAsBytes(rendered, flush: true);
            tempFiles.add(file);
          }
          final bytes = await ref.read(pdfServiceProvider).imagesToPdf(
                [for (final f in tempFiles) f.path],
                const ImagesToPdfOptions(marginMm: 0, quality: 92),
                onProgress: (f, m) => ctx.report(0.7 + f * 0.3, m),
                cancel: ctx.cancel,
              );
          final saved = await ctx.save(bytes, withExtension(_name.text, 'pdf'));
          return ToolOutcome(
            files: [saved],
            headline: 'Scan saved as PDF',
            note: '${pages.length} page(s) · ${formatBytes(bytes.length)}',
          );
        } finally {
          for (final f in tempFiles) {
            if (f.existsSync()) await f.delete();
          }
        }
      },
      requiredBytes: 32 * 1024 * 1024,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return buildToolScaffold(
      title: 'Scan document',
      actionLabel: 'Export ${_pages.length} page(s) as PDF',
      actionIcon: Icons.picture_as_pdf_rounded,
      actionEnabled: _pages.isNotEmpty && !_adding && _name.text.trim().isNotEmpty,
      onAction: _export,
      configure: _pages.isEmpty
          ? Stack(
              children: [
                const EmptyState(
                  icon: Icons.document_scanner_rounded,
                  title: 'Scan paper to PDF',
                  message: 'Take photos with your camera or import images. FILEFLOW finds the page edges, '
                      'straightens the perspective and cleans up the scan. No camera permission is needed.',
                ),
                Positioned(
                  left: 24,
                  right: 24,
                  bottom: 24,
                  child: Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(onPressed: _adding ? null : _capture, icon: const Icon(Icons.photo_camera_rounded), label: const Text('Camera')),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(onPressed: _adding ? null : _import, icon: const Icon(Icons.photo_library_rounded), label: const Text('Import')),
                      ),
                    ],
                  ),
                ),
                if (_adding) const Positioned.fill(child: Center(child: CircularProgressIndicator())),
              ],
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(onPressed: _adding ? null : _capture, icon: const Icon(Icons.photo_camera_rounded), label: const Text('Camera')),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(onPressed: _adding ? null : _import, icon: const Icon(Icons.photo_library_rounded), label: const Text('Import')),
                    ),
                  ],
                ),
                if (_adding) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
                const SizedBox(height: 12),
                SectionHeader('${_pages.length} page(s)'),
                ReorderableListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  buildDefaultDragHandles: false,
                  itemCount: _pages.length,
                  onReorderItem: (o, n) => setState(() {
                    final item = _pages.removeAt(o);
                    _pages.insert(n, item);
                  }),
                  itemBuilder: (context, i) {
                    final page = _pages[i];
                    return Padding(
                      key: ObjectKey(page),
                      padding: const EdgeInsets.only(bottom: 8),
                      child: AppCard(
                        padding: const EdgeInsets.all(8),
                        onTap: () => _edit(i),
                        child: Row(
                          children: [
                            ReorderableDragStartListener(index: i, child: const Padding(padding: EdgeInsets.all(8), child: Icon(Icons.drag_indicator_rounded))),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.memory(page.thumb, width: 56, height: 72, fit: BoxFit.cover, gaplessPlayback: true),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Page ${i + 1}', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                                  Text('${page.edit.filter.label} · tap to edit', style: theme.textTheme.bodySmall),
                                ],
                              ),
                            ),
                            IconButton(tooltip: 'Edit', icon: const Icon(Icons.tune_rounded), onPressed: () => _edit(i)),
                            IconButton(tooltip: 'Remove', icon: const Icon(Icons.delete_outline_rounded), onPressed: () => _remove(i)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _name,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(labelText: 'PDF name', suffixText: '.pdf'),
                ),
              ],
            ),
    );
  }
}
