import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../core/providers.dart';
import '../../core/services/scanner_service.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/crop_editor.dart';

/// Edits one scanned page: corners (perspective), rotation, filters, tone.
class ScanEditPage extends ConsumerStatefulWidget {
  const ScanEditPage({super.key, required this.path, required this.initial});

  final String path;
  final ScanEdit initial;

  @override
  ConsumerState<ScanEditPage> createState() => _ScanEditPageState();
}

class _ScanEditPageState extends ConsumerState<ScanEditPage> {
  late ScanEdit _edit = widget.initial;
  Uint8List? _base;
  double _aspect = 1;
  Uint8List? _result;
  bool _showResult = false;
  bool _busy = true;
  int _renderTicket = 0;
  Uint8List? _source;

  @override
  void initState() {
    super.initState();
    _loadBase();
  }

  Future<Uint8List> _bytes() async => _source ??= await File(widget.path).readAsBytes();

  Future<void> _loadBase() async {
    setState(() => _busy = true);
    try {
      final base = await ref.read(scannerServiceProvider).basePreview(await _bytes(), _edit.quarterTurns);
      final codec = await ui.instantiateImageCodec(base);
      final frame = await codec.getNextFrame();
      final aspect = frame.image.width / frame.image.height;
      frame.image.dispose();
      codec.dispose();
      if (!mounted) return;
      setState(() {
        _base = base;
        _aspect = aspect;
      });
    } on Object {
      if (mounted) showMessage(context, 'The page could not be loaded.', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _renderResult() async {
    final ticket = ++_renderTicket;
    setState(() => _busy = true);
    try {
      final bytes = await ref.read(scannerServiceProvider).render(await _bytes(), _edit, maxSide: 1100, quality: 85);
      if (!mounted || ticket != _renderTicket) return;
      setState(() => _result = bytes);
    } on Object {
      if (mounted) showMessage(context, 'Preview failed.', error: true);
    } finally {
      if (mounted && ticket == _renderTicket) setState(() => _busy = false);
    }
  }

  Future<void> _rotate(int delta) async {
    _edit = _edit.copyWith(quarterTurns: (_edit.quarterTurns + delta) % 4, corners: ScanCorners.full);
    await _loadBase();
    if (_showResult) await _renderResult();
  }

  Future<void> _detect() async {
    setState(() => _busy = true);
    try {
      final base = _base;
      if (base == null) return;
      final corners = await ref.read(scannerServiceProvider).detectCorners(base);
      if (mounted) setState(() => _edit = _edit.copyWith(corners: corners));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _setFilter(ScanFilter f) {
    setState(() => _edit = _edit.copyWith(filter: f));
    if (_showResult) _renderResult();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit page'),
        actions: [
          TextButton(onPressed: _busy && _base == null ? null : () => Navigator.pop(context, _edit), child: const Text('Done')),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SegmentedButton<bool>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: false, icon: Icon(Icons.crop_rounded), label: Text('Crop')),
                  ButtonSegment(value: true, icon: Icon(Icons.auto_awesome_rounded), label: Text('Result')),
                ],
                selected: {_showResult},
                onSelectionChanged: (s) {
                  setState(() => _showResult = s.first);
                  if (s.first) _renderResult();
                },
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: theme.colorScheme.surfaceContainerHigh, borderRadius: BorderRadius.circular(20)),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  children: [
                    if (_base != null && !_showResult)
                      CropEditor(
                        imageBytes: _base!,
                        imageAspect: _aspect,
                        corners: _edit.corners,
                        onChanged: (c) => setState(() => _edit = _edit.copyWith(corners: c)),
                      ),
                    if (_showResult && _result != null) Positioned.fill(child: Image.memory(_result!, fit: BoxFit.contain, gaplessPlayback: true)),
                    if (_busy) const Positioned.fill(child: Center(child: CircularProgressIndicator())),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton.filledTonal(tooltip: 'Rotate left', onPressed: _busy ? null : () => _rotate(3), icon: const Icon(Icons.rotate_left_rounded)),
                  IconButton.filledTonal(tooltip: 'Rotate right', onPressed: _busy ? null : () => _rotate(1), icon: const Icon(Icons.rotate_right_rounded)),
                  IconButton.filledTonal(tooltip: 'Detect edges', onPressed: _busy ? null : _detect, icon: const Icon(Icons.document_scanner_rounded)),
                  IconButton.filledTonal(
                    tooltip: 'Use full page',
                    onPressed: () => setState(() => _edit = _edit.copyWith(corners: ScanCorners.full)),
                    icon: const Icon(Icons.crop_free_rounded),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  for (final f in ScanFilter.values)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(f.label),
                        selected: _edit.filter == f,
                        showCheckmark: false,
                        onSelected: (_) => _setFilter(f),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Icon(Icons.brightness_6_rounded, size: 20),
                  Expanded(
                    child: Slider(
                      value: _edit.brightness,
                      min: 0.6,
                      max: 1.6,
                      onChanged: (v) => setState(() => _edit = _edit.copyWith(brightness: v)),
                      onChangeEnd: (_) => _showResult ? _renderResult() : null,
                    ),
                  ),
                  const Icon(Icons.contrast_rounded, size: 20),
                  Expanded(
                    child: Slider(
                      value: _edit.contrast,
                      min: 0.6,
                      max: 1.8,
                      onChanged: (v) => setState(() => _edit = _edit.copyWith(contrast: v)),
                      onChangeEnd: (_) => _showResult ? _renderResult() : null,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}
