import 'package:material_ui/material_ui.dart';

import '../../core/constants/app_constants.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/logo.dart';

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    const points = [
      (Icons.phone_android_rounded, 'Local processing', 'PDFs, images, scans and archives are processed on your device. Nothing is uploaded to a server.'),
      (Icons.person_off_outlined, 'No account', 'FILEFLOW has no sign-up, no login and no analytics or advertising SDKs.'),
      (Icons.wifi_off_rounded, 'Works offline', 'The app does not declare the internet permission and needs no network.'),
      (Icons.folder_shared_outlined, 'Minimal permissions', 'Files are chosen with the system picker. Scanning uses your camera app. No full-storage access is requested.'),
      (Icons.lock_outline_rounded, 'Your documents stay yours', 'Originals are never changed. Results are saved as new files, and nothing is deleted without confirmation.'),
      (Icons.vpn_key_outlined, 'Passwords', 'PDF passwords are used only in memory to open or protect a document. FILEFLOW never bypasses document security.'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final p in points)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    IconBadge(p.$1),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(p.$3, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.4)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Center(
            child: Image.asset(
              'assets/icons/app_icon.png',
              width: 96,
              height: 96,
              errorBuilder: (_, _, _) => const FileFlowLogo(size: 96),
            ),
          ),
          const SizedBox(height: 16),
          Text(AppConstants.appName, textAlign: TextAlign.center, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 2)),
          Text(AppConstants.tagline, textAlign: TextAlign.center, style: theme.textTheme.bodyMedium),
          const SizedBox(height: 4),
          Text('Version ${AppConstants.version} (${AppConstants.buildNumber})', textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
          const SizedBox(height: 24),
          const InfoBanner(
            'FILEFLOW is an offline-first file manager and PDF toolkit built with Flutter. '
            'It is free to use, collects no data, and works without an account.',
          ),
          const SizedBox(height: 12),
          Text(AppConstants.packageName, textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }
}
