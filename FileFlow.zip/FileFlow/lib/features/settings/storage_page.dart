import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../core/providers.dart';
import '../../core/services/native_service.dart';
import '../../core/utilities/file_types.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';
import '../file_library/file_actions.dart';

class _StorageData {
  const _StorageData({
    required this.device,
    required this.workspace,
    required this.processed,
    required this.temp,
    required this.categories,
    required this.large,
  });

  final StorageInfo? device;
  final int workspace;
  final int processed;
  final int temp;
  final Map<FileCategory, int> categories;
  final List<File> large;
}

final _storageDataProvider = FutureProvider.autoDispose<_StorageData>((ref) async {
  final storage = ref.watch(storageServiceProvider);
  return _StorageData(
    device: await storage.deviceStorage(),
    workspace: await storage.directorySize(await storage.workspace()),
    processed: await storage.directorySize(await storage.processedDir()),
    temp: await storage.temporarySize(),
    categories: await storage.categoryBreakdown(),
    large: await storage.largestFiles(limit: 10),
  );
});

/// Storage overview, temporary file cleanup and large files.
class StoragePage extends ConsumerWidget {
  const StoragePage({super.key});

  Future<void> _clearTemp(BuildContext context, WidgetRef ref) async {
    final ok = await confirmAction(
      context,
      title: 'Clear temporary files?',
      message: 'Cached copies of files you picked and other scratch data will be removed. '
          'Your documents and processed files are not touched.',
      confirmLabel: 'Clear',
    );
    if (!ok || !context.mounted) return;
    final freed = await ref.read(storageServiceProvider).clearTemporary();
    ref.invalidate(_storageDataProvider);
    if (context.mounted) showMessage(context, 'Freed ${formatBytes(freed)}.');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final data = ref.watch(_storageDataProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Storage')),
      body: SafeArea(
        child: data.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => const EmptyState(icon: Icons.error_outline_rounded, title: 'Storage unavailable', message: 'Storage information could not be read.'),
          data: (d) {
            final total = d.categories.values.fold<int>(0, (s, e) => s + e);
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(_storageDataProvider),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          d.device == null ? 'Device storage unavailable' : '${formatBytes(d.device!.used)} used of ${formatBytes(d.device!.total)}',
                          style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        if (d.device != null) ...[
                          const SizedBox(height: 10),
                          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: d.device!.usedFraction, minHeight: 10)),
                          const SizedBox(height: 6),
                          Text('${formatBytes(d.device!.free)} free', style: theme.textTheme.bodySmall),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  AppCard(
                    child: Column(
                      children: [
                        _Row('FILEFLOW files', formatBytes(d.workspace)),
                        _Row('Processed files', formatBytes(d.processed)),
                        _Row('Temporary files', formatBytes(d.temp)),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: d.temp == 0 ? null : () => _clearTemp(context, ref),
                            icon: const Icon(Icons.cleaning_services_rounded),
                            label: const Text('Clear temporary files'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SectionHeader('By category'),
                  AppCard(
                    child: Column(
                      children: [
                        for (final c in FileCategory.values)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(
                              children: [
                                Icon(c.icon, size: 20),
                                const SizedBox(width: 12),
                                Expanded(child: Text(c.label)),
                                Text(formatBytes(d.categories[c] ?? 0), style: const TextStyle(fontWeight: FontWeight.w700)),
                                const SizedBox(width: 12),
                                SizedBox(
                                  width: 60,
                                  child: LinearProgressIndicator(value: total == 0 ? 0 : (d.categories[c] ?? 0) / total),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SectionHeader('Largest files'),
                  if (d.large.isEmpty)
                    const InfoBanner('No files yet. Large files in FILEFLOW storage will be listed here.')
                  else
                    for (final f in d.large)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: AppCard(
                          padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
                          child: Row(
                            children: [
                              FileTypeBadge(categoryOfPath(f.path), size: 40),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(p.basename(f.path), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                                    Text(formatBytes(f.lengthSync()), style: theme.textTheme.bodySmall),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: 'Delete',
                                icon: const Icon(Icons.delete_outline_rounded),
                                onPressed: () async {
                                  final deleted = await deleteWithConfirm(context, ref, f.path);
                                  if (deleted) ref.invalidate(_storageDataProvider);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                  const SizedBox(height: 8),
                  const InfoBanner('FILEFLOW never deletes your documents automatically. Anything removed here asks for confirmation first.'),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [Expanded(child: Text(label)), Text(value, style: const TextStyle(fontWeight: FontWeight.w700))]),
      );
}
