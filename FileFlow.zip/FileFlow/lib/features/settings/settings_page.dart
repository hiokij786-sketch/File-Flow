import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../../core/constants/app_constants.dart';
import '../../core/providers.dart';
import '../../core/services/file_ops_service.dart';
import '../../core/services/image_service.dart';
import '../../core/services/pdf_service.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SectionHeader('Appearance'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: ThemeMode.light, icon: Icon(Icons.light_mode_rounded), label: Text('Light')),
                    ButtonSegment(value: ThemeMode.dark, icon: Icon(Icons.dark_mode_rounded), label: Text('Dark')),
                    ButtonSegment(value: ThemeMode.system, icon: Icon(Icons.brightness_auto_rounded), label: Text('System')),
                  ],
                  selected: {settings.themeMode},
                  onSelectionChanged: (s) => notifier.update((c) => c.copyWith(themeMode: s.first)),
                ),
              ],
            ),
          ),
          const SectionHeader('Defaults'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ChoiceRow<OutputImageFormat>(
                  label: 'Default image format',
                  value: settings.defaultImageFormat,
                  options: OutputImageFormat.values,
                  optionLabel: (v) => v.label,
                  onChanged: (v) => notifier.update((c) => c.copyWith(defaultImageFormat: v)),
                ),
                ChoiceRow<CompressionLevel>(
                  label: 'Default PDF compression',
                  value: settings.defaultPdfQuality,
                  options: CompressionLevel.values,
                  optionLabel: (v) => v.label,
                  onChanged: (v) => notifier.update((c) => c.copyWith(defaultPdfQuality: v)),
                ),
                ChoiceRow<SortField>(
                  label: 'Sort files by',
                  value: settings.sortField,
                  options: SortField.values,
                  optionLabel: (v) => v.name[0].toUpperCase() + v.name.substring(1),
                  onChanged: (v) => notifier.update((c) => c.copyWith(sortField: v)),
                ),
                ChoiceRow<bool>(
                  label: 'Sort order',
                  value: settings.sortAscending,
                  options: const [true, false],
                  optionLabel: (v) => v ? 'Ascending' : 'Descending',
                  onChanged: (v) => notifier.update((c) => c.copyWith(sortAscending: v)),
                ),
              ],
            ),
          ),
          const SectionHeader('Output'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FutureBuilder(
                  future: ref.read(storageServiceProvider).processedDir(),
                  builder: (context, snap) => Text(
                    'Processed files are saved in:\n${snap.data?.path ?? '…'}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Ask where to save a copy'),
                  subtitle: const Text('Opens the system "save as" dialog after a single file is created, so you can choose any folder.'),
                  value: settings.askWhereToSave,
                  onChanged: (v) => notifier.update((c) => c.copyWith(askWhereToSave: v)),
                ),
              ],
            ),
          ),
          const SectionHeader('Storage and privacy'),
          ToolTile(icon: Icons.storage_rounded, title: 'Storage', subtitle: 'Usage, temporary files, large files', onTap: () => context.push('/settings/storage')),
          const SizedBox(height: 8),
          ToolTile(
            icon: Icons.cleaning_services_rounded,
            title: 'Clear temporary files',
            subtitle: 'Frees cached copies of picked files',
            onTap: () async {
              final ok = await confirmAction(context, title: 'Clear temporary files?', message: 'Your documents and processed files are not touched.', confirmLabel: 'Clear');
              if (!ok) return;
              final freed = await ref.read(storageServiceProvider).clearTemporary();
              if (context.mounted) showMessage(context, 'Freed ${formatBytes(freed)}.');
            },
          ),
          const SizedBox(height: 8),
          ToolTile(icon: Icons.shield_outlined, title: 'Privacy', subtitle: 'How FILEFLOW treats your data', onTap: () => context.push('/settings/privacy')),
          const SectionHeader('About'),
          ToolTile(icon: Icons.info_outline_rounded, title: 'About ${AppConstants.appName}', subtitle: 'Version ${AppConstants.version} (${AppConstants.buildNumber})', onTap: () => context.push('/settings/about')),
          const SizedBox(height: 8),
          ToolTile(
            icon: Icons.description_outlined,
            title: 'Open-source licenses',
            subtitle: 'Libraries used by FILEFLOW',
            onTap: () => showLicensePage(
              context: context,
              applicationName: AppConstants.appName,
              applicationVersion: AppConstants.version,
            ),
          ),
        ],
      ),
    );
  }
}
