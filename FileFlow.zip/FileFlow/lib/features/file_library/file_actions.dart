import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../core/errors/app_exception.dart';
import '../../core/providers.dart';
import '../../core/utilities/file_types.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';
import '../../data/models/library_entry.dart';

/// Opens a file in the right in-app viewer. Missing files are handled
/// gracefully.
Future<void> openPath(BuildContext context, WidgetRef ref, String path) async {
  if (!File(path).existsSync()) {
    showMessage(context, 'This file is no longer available. It may have been moved or deleted.', error: true);
    await ref.read(libraryProvider.notifier).refresh();
    return;
  }
  await ref.read(libraryProvider.notifier).markOpened(path);
  if (!context.mounted) return;
  if (isPdfPath(path)) {
    context.push('/pdf/viewer', extra: path);
  } else {
    context.push('/preview', extra: path);
  }
}

Future<void> runGuarded(BuildContext context, Future<void> Function() action) async {
  try {
    await action();
  } on AppException catch (e) {
    if (context.mounted) showMessage(context, e.message, error: true);
  } on FileSystemException {
    if (context.mounted) showMessage(context, 'The file system rejected this action.', error: true);
  }
}

Future<void> showFileInfo(BuildContext context, String path) async {
  final type = FileSystemEntity.typeSync(path);
  if (type == FileSystemEntityType.notFound) {
    showMessage(context, 'This file no longer exists.', error: true);
    return;
  }
  final stat = FileStat.statSync(path);
  final isDir = type == FileSystemEntityType.directory;
  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(p.basename(path)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _InfoRow('Type', isDir ? 'Folder' : categoryOfPath(path).label),
          if (!isDir) _InfoRow('Size', formatBytes(stat.size)),
          _InfoRow('Modified', formatDate(stat.modified)),
          _InfoRow('Location', p.dirname(path)),
        ],
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
    ),
  );
}

class _InfoRow extends StatelessWidget {
  const _InfoRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

/// Asks, then deletes. Returns true when the file was deleted.
Future<bool> deleteWithConfirm(BuildContext context, WidgetRef ref, String path) async {
  final isDir = FileSystemEntity.isDirectorySync(path);
  final ok = await confirmAction(
    context,
    title: 'Delete ${isDir ? 'folder' : 'file'}?',
    message: '"${p.basename(path)}" will be permanently deleted from FILEFLOW storage.'
        '${isDir ? ' Everything inside it is deleted too.' : ''}',
    confirmLabel: 'Delete',
    destructive: true,
  );
  if (!ok) return false;
  await ref.read(fileOpsProvider).delete(path);
  await ref.read(libraryProvider.notifier).forget(path);
  return true;
}

/// Prompts for a new name and renames. Returns the new path or null.
Future<String?> renameWithPrompt(BuildContext context, WidgetRef ref, String path) async {
  final name = await promptText(context, title: 'Rename', initial: p.basename(path), label: 'New name', confirmLabel: 'Rename');
  if (name == null || name.trim().isEmpty) return null;
  final newPath = await ref.read(fileOpsProvider).rename(path, name.trim());
  await ref.read(libraryProvider.notifier).moved(path, newPath);
  return newPath;
}

/// List row for a library entry.
class LibraryEntryTile extends ConsumerWidget {
  const LibraryEntryTile({super.key, required this.entry, this.onChanged});

  final LibraryEntry entry;
  final VoidCallback? onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final output = ref.read(outputServiceProvider);
    final library = ref.read(libraryProvider.notifier);
    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
      onTap: entry.missing ? null : () => openPath(context, ref, entry.path),
      child: Row(
        children: [
          FileTypeBadge(entry.category),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  entry.missing ? 'File missing - moved or deleted' : '${formatBytes(entry.size)} · ${formatDate(entry.modified)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(color: entry.missing ? theme.colorScheme.error : theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          if (entry.missing)
            TextButton(onPressed: () => library.forget(entry.path), child: const Text('Remove'))
          else ...[
            IconButton(
              tooltip: entry.isFavorite ? 'Remove from favorites' : 'Add to favorites',
              icon: Icon(entry.isFavorite ? Icons.star_rounded : Icons.star_border_rounded, color: entry.isFavorite ? theme.colorScheme.secondary : null),
              onPressed: () => library.toggleFavorite(entry.path),
            ),
            PopupMenuButton<String>(
              onSelected: (v) => runGuarded(context, () async {
                switch (v) {
                  case 'share':
                    await output.share([entry.path]);
                  case 'save':
                    final ok = await output.exportCopy(entry.path);
                    if (ok && context.mounted) showMessage(context, 'Copy saved.');
                  case 'open':
                    await output.openExternally(entry.path);
                  case 'rename':
                    await renameWithPrompt(context, ref, entry.path);
                  case 'info':
                    await showFileInfo(context, entry.path);
                  case 'delete':
                    final deleted = await deleteWithConfirm(context, ref, entry.path);
                    if (deleted && context.mounted) showMessage(context, 'Deleted.');
                }
                onChanged?.call();
              }),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'share', child: Text('Share')),
                PopupMenuItem(value: 'save', child: Text('Export a copy…')),
                PopupMenuItem(value: 'open', child: Text('Open with…')),
                PopupMenuItem(value: 'rename', child: Text('Rename')),
                PopupMenuItem(value: 'info', child: Text('Information')),
                PopupMenuItem(value: 'delete', child: Text('Delete')),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
