import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../core/providers.dart';
import '../../core/services/file_ops_service.dart';
import '../../core/utilities/file_types.dart';
import '../../core/widgets/common.dart';
import '../../data/models/library_entry.dart';
import 'file_actions.dart';

enum _LibraryFilter { all, processed, recent, favorites }

/// The internal file library: all, processed, recent and favorite files with
/// search, filters and sorting.
class LibraryTab extends ConsumerStatefulWidget {
  const LibraryTab({super.key});

  @override
  ConsumerState<LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends ConsumerState<LibraryTab> {
  _LibraryFilter _filter = _LibraryFilter.all;
  FileCategory? _category;
  String _query = '';

  List<LibraryEntry> _apply(List<LibraryEntry> all) {
    final settings = ref.read(settingsProvider);
    final list = all.where((e) {
      if (_category != null && e.category != _category) return false;
      if (_query.isNotEmpty && !e.name.toLowerCase().contains(_query.toLowerCase())) return false;
      return switch (_filter) {
        _LibraryFilter.all => true,
        _LibraryFilter.processed => e.isProcessed,
        _LibraryFilter.recent => e.isRecent,
        _LibraryFilter.favorites => e.isFavorite,
      };
    }).toList();
    if (_filter == _LibraryFilter.recent) {
      list.sort((a, b) => a.lastOpenedIndex!.compareTo(b.lastOpenedIndex!));
      return list;
    }
    int cmp(LibraryEntry a, LibraryEntry b) => switch (settings.sortField) {
          SortField.name => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
          SortField.size => a.size.compareTo(b.size),
          SortField.date => a.modified.compareTo(b.modified),
          SortField.type => extensionOf(a.path).compareTo(extensionOf(b.path)),
        };
    list.sort((a, b) => settings.sortAscending ? cmp(a, b) : cmp(b, a));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final library = ref.watch(libraryProvider);
    ref.watch(settingsProvider);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: TextField(
            onChanged: (v) => setState(() => _query = v.trim()),
            decoration: const InputDecoration(hintText: 'Search the library', prefixIcon: Icon(Icons.search_rounded), isDense: true),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            children: [
              for (final f in _LibraryFilter.values)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(switch (f) {
                      _LibraryFilter.all => 'All files',
                      _LibraryFilter.processed => 'Processed',
                      _LibraryFilter.recent => 'Recent',
                      _LibraryFilter.favorites => 'Favorites',
                    }),
                    selected: _filter == f,
                    showCheckmark: false,
                    onSelected: (_) => setState(() => _filter = f),
                  ),
                ),
            ],
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilterChip(label: const Text('Any type'), selected: _category == null, showCheckmark: false, onSelected: (_) => setState(() => _category = null)),
              ),
              for (final c in FileCategory.values)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    avatar: Icon(c.icon, size: 16),
                    label: Text(c.label),
                    selected: _category == c,
                    showCheckmark: false,
                    onSelected: (_) => setState(() => _category = _category == c ? null : c),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: library.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => EmptyState(icon: Icons.error_outline_rounded, title: 'Library unavailable', message: 'The library could not be loaded.', actionLabel: 'Retry', onAction: () => ref.read(libraryProvider.notifier).refresh()),
            data: (all) {
              final items = _apply(all);
              if (items.isEmpty) {
                return EmptyState(
                  icon: Icons.folder_open_rounded,
                  title: switch (_filter) {
                    _LibraryFilter.all => 'No files yet',
                    _LibraryFilter.processed => 'Nothing processed yet',
                    _LibraryFilter.recent => 'No recent files',
                    _LibraryFilter.favorites => 'No favorites yet',
                  },
                  message: 'Files you create with FILEFLOW tools or import appear here.',
                );
              }
              return RefreshIndicator(
                onRefresh: () => ref.read(libraryProvider.notifier).refresh(),
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: items.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 8),
                  itemBuilder: (_, i) => LibraryEntryTile(key: ValueKey(items[i].path), entry: items[i]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

String relativeToWorkspace(String workspace, String path) =>
    p.isWithin(workspace, path) ? p.relative(path, from: workspace) : path;
