import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/services/archive_service.dart';
import '../../../core/services/output_service.dart';
import '../../../core/utilities/file_types.dart';
import '../../../core/utilities/format.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/tool_run.dart';

class ZipExtractorPage extends ConsumerStatefulWidget {
  const ZipExtractorPage({super.key});

  @override
  ConsumerState<ZipExtractorPage> createState() => _ZipExtractorPageState();
}

class _ZipExtractorPageState extends ConsumerState<ZipExtractorPage> with ToolRunMixin<ZipExtractorPage> {
  PickedFile? _zip;
  List<ArchiveEntryInfo> _entries = [];
  final Set<String> _selected = {};
  final Map<String, String> _renames = {};
  bool _loading = false;
  String? _error;

  Future<void> _pick() async {
    final picked = await ref.read(outputServiceProvider).pick(
      extensions: const ['zip', 'rar', '7z', 'tar', 'gz'],
      multiple: false,
    );
    if (picked.isEmpty) return;
    setState(() {
      _zip = picked.first;
      _loading = true;
      _error = null;
      _entries = [];
      _selected.clear();
      _renames.clear();
    });
    try {
      final entries = await ref.read(archiveServiceProvider).list(picked.first.path);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _selected.addAll(entries.where((e) => e.isFile && e.isSafe).map((e) => e.name));
      });
    } on AppException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _rename(ArchiveEntryInfo entry) async {
    final value = await promptText(
      context,
      title: 'Rename on extraction',
      initial: _renames[entry.name] ?? p.basename(entry.name),
      label: 'File name',
    );
    if (value == null || value.trim().isEmpty) return;
    setState(() => _renames[entry.name] = value.trim());
  }

  Future<void> _extract() async {
    final zip = _zip!;
    final storage = ref.read(storageServiceProvider);
    final processed = await storage.processedDir();
    final dest = Directory(uniquePath(processed.path, sanitizeFileName(p.basenameWithoutExtension(zip.name), fallback: 'archive')));
    await runTool(
      (ctx) async {
        try {
          final result = await ref.read(archiveServiceProvider).extract(
                zip.path,
                dest,
                only: _selected,
                renames: _renames,
                checkSpace: storage.ensureSpace,
                onProgress: ctx.progress,
                cancel: ctx.cancel,
              );
          final files = <ProcessedFile>[
            for (final path in result.written) await ref.read(outputServiceProvider).describe(File(path)),
          ];
          return ToolOutcome(
            files: files,
            headline: 'Archive extracted',
            note: result.skipped.isEmpty
                ? '${files.length} file(s) extracted to FILEFLOW › Processed › ${p.basename(dest.path)}.'
                : '${files.length} file(s) extracted. ${result.skipped.length} unsafe entr${result.skipped.length == 1 ? 'y was' : 'ies were'} skipped for your protection.',
          );
        } on Object {
          if (dest.existsSync()) await dest.delete(recursive: true);
          rethrow;
        }
      },
      requiredBytes: zip.size,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final files = _entries.where((e) => e.isFile).toList();
    Widget body;
    if (_zip == null) {
      body = EmptyState(
        icon: Icons.folder_zip_rounded,
        title: 'Extract a ZIP archive',
        message: 'Browse the contents, choose what to extract and rename files. Only ZIP archives are supported.',
        actionLabel: 'Select a ZIP file',
        onAction: _pick,
      );
    } else if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = EmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Cannot open this archive',
        message: _error!,
        actionLabel: 'Choose another file',
        onAction: _pick,
      );
    } else {
      body = ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Row(
              children: [
                const IconBadge(Icons.folder_zip_rounded),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_zip!.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                      Text('${files.length} files · ${formatBytes(_zip!.size)}', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
                TextButton(onPressed: _pick, child: const Text('Change')),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: Text('${_selected.length} selected', style: theme.textTheme.bodyMedium)),
              TextButton(
                onPressed: () => setState(() {
                  final safe = files.where((e) => e.isSafe).map((e) => e.name).toSet();
                  if (_selected.length == safe.length) {
                    _selected.clear();
                  } else {
                    _selected
                      ..clear()
                      ..addAll(safe);
                  }
                }),
                child: const Text('Toggle all'),
              ),
            ],
          ),
          for (final e in files)
            AppCard(
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
              child: Row(
                children: [
                  Checkbox(
                    value: _selected.contains(e.name),
                    onChanged: e.isSafe
                        ? (v) => setState(() => v == true ? _selected.add(e.name) : _selected.remove(e.name))
                        : null,
                  ),
                  Icon(categoryOfPath(e.name).icon, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_renames[e.name] ?? e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(
                          e.isSafe ? formatBytes(e.size) : 'Unsafe path - will be skipped',
                          style: theme.textTheme.bodySmall?.copyWith(color: e.isSafe ? null : theme.colorScheme.error),
                        ),
                      ],
                    ),
                  ),
                  if (e.isSafe)
                    IconButton(tooltip: 'Rename', icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _rename(e)),
                ],
              ),
            ),
          const SizedBox(height: 12),
          const InfoBanner('Entries with absolute paths or ".." segments are never extracted (path traversal protection). Existing files are not overwritten.'),
        ],
      );
    }
    return buildToolScaffold(
      title: 'Extract ZIP',
      actionLabel: 'Extract ${_selected.length} file(s)',
      actionIcon: Icons.unarchive_rounded,
      actionEnabled: _zip != null && !_loading && _error == null && _selected.isNotEmpty,
      onAction: _extract,
      configure: body,
    );
  }
}
