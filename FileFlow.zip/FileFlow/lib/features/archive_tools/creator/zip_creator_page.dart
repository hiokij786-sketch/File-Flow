import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../../core/providers.dart';
import '../../../core/services/archive_service.dart';
import '../../../core/services/output_service.dart';
import '../../../core/utilities/format.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/selected_files.dart';
import '../../../core/widgets/tool_run.dart';

class ZipCreatorPage extends ConsumerStatefulWidget {
  const ZipCreatorPage({super.key});

  @override
  ConsumerState<ZipCreatorPage> createState() => _ZipCreatorPageState();
}

class _ZipCreatorPageState extends ConsumerState<ZipCreatorPage> with ToolRunMixin<ZipCreatorPage> {
  final List<PickedFile> _files = [];
  final _name = TextEditingController(text: 'archive');
  int _level = 6;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final picked = await ref.read(outputServiceProvider).pick();
    if (picked.isNotEmpty) setState(() => _files.addAll(picked));
  }

  Future<void> _create() async {
    final files = [..._files];
    final storage = ref.read(storageServiceProvider);
    final processed = await storage.processedDir();
    final total = files.fold<int>(0, (s, e) => s + e.size);
    final target = uniquePath(processed.path, withExtension(_name.text, 'zip'));
    await runTool(
      (ctx) async {
        final zip = await ref.read(archiveServiceProvider).create(
          [for (final f in files) ArchiveInput(f.path, entryName: f.name)],
          target,
          level: _level,
          onProgress: ctx.progress,
          cancel: ctx.cancel,
        );
        final described = await ref.read(outputServiceProvider).describe(File(zip.path));
        return ToolOutcome(
          files: [described],
          headline: 'ZIP created',
          extra: SizeComparison(original: total, result: described.size),
          note: described.size >= total
              ? 'These files are already compressed, so the ZIP is not smaller than the originals.'
              : null,
        );
      },
      requiredBytes: total + 8 * 1024 * 1024,
    );
  }

  @override
  Widget build(BuildContext context) {
    return buildToolScaffold(
      title: 'Create ZIP',
      actionLabel: 'Create ZIP',
      actionIcon: Icons.archive_rounded,
      actionEnabled: _files.isNotEmpty && _name.text.trim().isNotEmpty,
      onAction: _create,
      configure: _files.isEmpty
          ? EmptyState(
              icon: Icons.archive_rounded,
              title: 'Bundle files into a ZIP',
              message: 'Choose any files from your device. They are copied into a new ZIP archive.',
              actionLabel: 'Select files',
              onAction: _add,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SectionHeader('${_files.length} files · ${formatBytes(_files.fold<int>(0, (s, e) => s + e.size))}'),
                SelectedFilesList(
                  items: [for (final f in _files) SelectedItem(path: f.path, title: f.name, subtitle: formatBytes(f.size))],
                  onRemove: (i) => setState(() => _files.removeAt(i)),
                  onReorder: (o, n) => setState(() {
                    final item = _files.removeAt(o);
                    _files.insert(n, item);
                  }),
                ),
                OutlinedButton.icon(onPressed: _add, icon: const Icon(Icons.add_rounded), label: const Text('Add more files')),
                const SizedBox(height: 16),
                TextField(
                  controller: _name,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(labelText: 'Archive name', suffixText: '.zip'),
                ),
                ChoiceRow<int>(
                  label: 'Compression',
                  value: _level,
                  options: const [0, 3, 6, 9],
                  optionLabel: (v) => switch (v) {
                    0 => 'Store only',
                    3 => 'Fast',
                    6 => 'Normal',
                    _ => 'Maximum',
                  },
                  onChanged: (v) => setState(() => _level = v),
                ),
              ],
            ),
    );
  }
}
