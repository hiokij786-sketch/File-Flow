import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';

import '../../app/tool_registry.dart';
import '../../core/constants/app_constants.dart';
import '../../core/providers.dart';
import '../../core/services/native_service.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/logo.dart';
import '../../data/models/library_entry.dart';
import '../file_library/file_actions.dart';

final _homeStorageProvider = FutureProvider.autoDispose<(StorageInfo?, int)>((ref) async {
  final storage = ref.watch(storageServiceProvider);
  final device = await storage.deviceStorage();
  final used = await storage.directorySize(await storage.workspace());
  return (device, used);
});

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final library = ref.watch(libraryProvider);
    final entries = library.asData?.value ?? const <LibraryEntry>[];
    final recents = (entries.where((e) => e.isRecent && !e.missing).toList()
          ..sort((a, b) => a.lastOpenedIndex!.compareTo(b.lastOpenedIndex!)))
        .take(10)
        .toList();
    final favorites = entries.where((e) => e.isFavorite && !e.missing).take(10).toList();
    final processed = (entries.where((e) => e.isProcessed && !e.missing).toList()
          ..sort((a, b) => b.modified.compareTo(a.modified)))
        .take(5)
        .toList();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            await ref.read(libraryProvider.notifier).refresh();
            ref.invalidate(_homeStorageProvider);
          },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              Row(
                children: [
                  const FileFlowWordmark(compact: true),
                  const Spacer(),
                  IconButton(
                    tooltip: 'Settings',
                    icon: const Icon(Icons.settings_rounded),
                    onPressed: () => context.go('/settings'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(greetingFor(DateTime.now()), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              Text(AppConstants.tagline, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, height: 1.2)),
              const SizedBox(height: 16),
              TextField(
                controller: _search,
                onChanged: (v) => setState(() => _query = v.trim()),
                decoration: InputDecoration(
                  hintText: 'Search tools and your files',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => setState(() {
                            _search.clear();
                            _query = '';
                          }),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              if (_query.isNotEmpty)
                _SearchResults(query: _query, entries: entries)
              else ...[
                const SectionHeader('Quick actions'),
                GridView.count(
                  crossAxisCount: 5,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 6,
                  childAspectRatio: 0.62,
                  children: [
                    for (final id in quickActionIds) _QuickAction(tool: toolById(id)),
                  ],
                ),
                const SizedBox(height: 8),
                if (recents.isNotEmpty) ...[
                  SectionHeader('Recent files', actionLabel: 'See all', onAction: () => context.go('/files')),
                  _FileStrip(entries: recents),
                ],
                if (favorites.isNotEmpty) ...[
                  const SectionHeader('Favorites'),
                  _FileStrip(entries: favorites),
                ],
                if (recents.isEmpty && favorites.isEmpty)
                  AppCard(
                    child: Row(
                      children: [
                        const IconBadge(Icons.history_rounded),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Files you open or mark as favorite will show up here.',
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                SectionHeader('PDF tools', actionLabel: 'All', onAction: () => context.go('/pdf')),
                _ToolStrip(tools: toolsIn(ToolGroup.pdf).take(6).toList()),
                SectionHeader('Image tools', actionLabel: 'All', onAction: () => context.go('/images')),
                _ToolStrip(tools: toolsIn(ToolGroup.image)),
                const SectionHeader('File tools'),
                _ToolStrip(tools: toolsIn(ToolGroup.file)),
                if (processed.isNotEmpty) ...[
                  const SectionHeader('Recently processed'),
                  for (final e in processed) Padding(padding: const EdgeInsets.only(bottom: 8), child: LibraryEntryTile(entry: e)),
                ],
                const SectionHeader('Storage'),
                const _StorageCard(),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends ConsumerWidget {
  const _QuickAction({required this.tool});

  final ToolInfo tool;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => launchTool(context, ref, tool),
      child: Column(
        children: [
          IconBadge(tool.icon, size: 52),
          const SizedBox(height: 6),
          Text(
            tool.title,
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w600, height: 1.15),
          ),
        ],
      ),
    );
  }
}

class _ToolStrip extends ConsumerWidget {
  const _ToolStrip({required this.tools});

  final List<ToolInfo> tools;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 112,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tools.length,
        separatorBuilder: (_, _) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final tool = tools[i];
          return SizedBox(
            width: 148,
            child: AppCard(
              onTap: () => launchTool(context, ref, tool),
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconBadge(tool.icon, size: 38),
                  const Spacer(),
                  Text(tool.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _FileStrip extends StatelessWidget {
  const _FileStrip({required this.entries});

  final List<LibraryEntry> entries;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      height: 112,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: entries.length,
        separatorBuilder: (_, _) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final e = entries[i];
          return SizedBox(
            width: 148,
            child: Consumer(
              builder: (context, ref, _) => AppCard(
                onTap: () => openPath(context, ref, e.path),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FileTypeBadge(e.category, size: 38),
                    const Spacer(),
                    Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text(formatBytes(e.size), style: theme.textTheme.bodySmall),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _SearchResults extends ConsumerWidget {
  const _SearchResults({required this.query, required this.entries});

  final String query;
  final List<LibraryEntry> entries;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final q = query.toLowerCase();
    final tools = allTools.where((t) => t.title.toLowerCase().contains(q) || t.subtitle.toLowerCase().contains(q)).toList();
    final files = entries.where((e) => !e.missing && e.name.toLowerCase().contains(q)).take(30).toList();
    if (tools.isEmpty && files.isEmpty) {
      return const SizedBox(
        height: 260,
        child: EmptyState(icon: Icons.search_off_rounded, title: 'No results', message: 'Try a different word, e.g. "merge" or a file name.'),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (tools.isNotEmpty) ...[
          const SectionHeader('Tools'),
          for (final t in tools)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ToolTile(icon: t.icon, title: t.title, subtitle: t.subtitle, onTap: () => launchTool(context, ref, t)),
            ),
        ],
        if (files.isNotEmpty) ...[
          const SectionHeader('Files'),
          for (final e in files) Padding(padding: const EdgeInsets.only(bottom: 8), child: LibraryEntryTile(entry: e)),
        ],
      ],
    );
  }
}

class _StorageCard extends ConsumerWidget {
  const _StorageCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final data = ref.watch(_homeStorageProvider);
    return AppCard(
      onTap: () => context.push('/settings/storage'),
      child: data.when(
        loading: () => const SizedBox(height: 56, child: Center(child: LinearProgressIndicator())),
        error: (_, _) => const Text('Storage information is unavailable.'),
        data: (value) {
          final device = value.$1;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const IconBadge(Icons.storage_rounded, size: 38),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      device == null ? 'FILEFLOW uses ${formatBytes(value.$2)}' : '${formatBytes(device.free)} free of ${formatBytes(device.total)}',
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded),
                ],
              ),
              if (device != null) ...[
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(value: device.usedFraction, minHeight: 8),
                ),
              ],
              const SizedBox(height: 8),
              Text('FILEFLOW files: ${formatBytes(value.$2)}', style: theme.textTheme.bodySmall),
            ],
          );
        },
      ),
    );
  }
}
