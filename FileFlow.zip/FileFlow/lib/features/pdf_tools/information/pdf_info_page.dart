import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/utilities/format.dart';
import '../../../core/widgets/common.dart';
import '../common/pdf_picking.dart';

class PdfInfoPage extends ConsumerStatefulWidget {
  const PdfInfoPage({super.key, this.path});

  final String? path;

  @override
  ConsumerState<PdfInfoPage> createState() => _PdfInfoPageState();
}

class _PdfInfoPageState extends ConsumerState<PdfInfoPage> {
  PdfInfo? _info;
  String? _error;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    if (widget.path != null) _load(widget.path!, null);
  }

  Future<void> _load(String path, String? password) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final info = await ref.read(pdfServiceProvider).info(path, password: password);
      if (mounted) setState(() => _info = info);
    } on AppException catch (e) {
      if (e is PasswordRequiredException || e is WrongPasswordException) {
        if (!mounted) return;
        final pw = await promptText(context, title: 'Password required', label: 'Password', obscure: true);
        if (pw != null && mounted) return _load(path, pw);
      }
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pick() async {
    final result = await pickPdfSources(context, ref, multiple: false);
    if (result.isNotEmpty) await _load(result.first.path, result.first.password);
  }

  @override
  Widget build(BuildContext context) {
    final info = _info;
    Widget body;
    if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = EmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Could not read this PDF',
        message: _error!,
        actionLabel: 'Choose another PDF',
        onAction: _pick,
      );
    } else if (info == null) {
      body = EmptyState(
        icon: Icons.info_outline_rounded,
        title: 'PDF information',
        message: 'Pick a PDF to see its size, pages, dates and metadata.',
        actionLabel: 'Select a PDF',
        onAction: _pick,
      );
    } else {
      final rows = <(String, String)>[
        ('File name', info.name),
        ('File size', formatBytes(info.sizeBytes)),
        ('Pages', '${info.pageCount}'),
        if (info.version != null) ('PDF version', info.version!),
        ('Password protected', info.isEncrypted ? 'Yes' : 'No'),
        if (info.created != null) ('Created', formatDate(info.created!)),
        if (info.modified != null) ('Modified', formatDate(info.modified!)),
        if (info.allowsCopying != null) ('Copying allowed', info.allowsCopying! ? 'Yes' : 'No'),
        if (info.allowsPrinting != null) ('Printing allowed', info.allowsPrinting! ? 'Yes' : 'No'),
        for (final e in info.metadata.entries) (e.key, e.value),
      ];
      body = ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                for (var i = 0; i < rows.length; i++) ...[
                  if (i > 0) const Divider(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 130,
                          child: Text(rows[i].$1, style: Theme.of(context).textTheme.bodySmall),
                        ),
                        Expanded(
                          child: Text(rows[i].$2, style: const TextStyle(fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          const InfoBanner('Metadata and dates are shown only when the document contains them.'),
        ],
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF information'),
        actions: [
          if (info != null) IconButton(tooltip: 'Another PDF', icon: const Icon(Icons.swap_horiz_rounded), onPressed: _pick),
        ],
      ),
      body: SafeArea(child: body),
    );
  }
}
