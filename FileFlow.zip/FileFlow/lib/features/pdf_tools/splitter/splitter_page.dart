import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/services/output_service.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/pdf_widgets.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

enum _SplitMode { ranges, selected, everyPage }

class SplitterPage extends ConsumerStatefulWidget {
  const SplitterPage({super.key});

  @override
  ConsumerState<SplitterPage> createState() => _SplitterPageState();
}

class _SplitterPageState extends ConsumerState<SplitterPage> with ToolRunMixin<SplitterPage> {
  PdfSource? _source;
  _SplitMode _mode = _SplitMode.ranges;
  final _ranges = TextEditingController();
  final Set<int> _selected = {};

  @override
  void dispose() {
    _ranges.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final result = await pickPdfSources(context, ref, multiple: false);
    if (result.isEmpty) return;
    setState(() {
      _source = result.first;
      _selected.clear();
      _ranges.clear();
    });
  }

  bool get _ready {
    if (_source == null) return false;
    return switch (_mode) {
      _SplitMode.ranges => _ranges.text.trim().isNotEmpty,
      _SplitMode.selected => _selected.isNotEmpty,
      _SplitMode.everyPage => true,
    };
  }

  Future<void> _split() async {
    final source = _source!;
    final base = p.basenameWithoutExtension(source.name);
    late final List<List<int>> groups;
    try {
      groups = switch (_mode) {
        _SplitMode.ranges => parsePageRanges(_ranges.text, source.pageCount),
        _SplitMode.selected => [(_selected.toList()..sort())],
        _SplitMode.everyPage => [for (var i = 0; i < source.pageCount; i++) [i]],
      };
    } on AppException catch (e) {
      showMessage(context, e.message, error: true);
      return;
    }
    await runTool(
      (ctx) async {
        final files = <ProcessedFile>[];
        await ref.read(pdfServiceProvider).splitGroups(
              source.path,
              groups,
              password: source.password,
              onProgress: ctx.progress,
              cancel: ctx.cancel,
              onFile: (i, bytes) async {
                final name = switch (_mode) {
                  _SplitMode.selected => '${base}_selected_pages.pdf',
                  _SplitMode.everyPage => '${base}_page_${i + 1}.pdf',
                  _SplitMode.ranges => '${base}_part_${i + 1}.pdf',
                };
                final saved = await ctx.save(
                  bytes,
                  name,
                  subfolder: groups.length > 1 ? sanitizeFileName('${base}_split') : null,
                );
                files.add(saved);
              },
            );
        return ToolOutcome(
          files: files,
          headline: files.length == 1 ? 'Pages extracted' : 'PDF split',
          note: '${files.length} file(s) created from ${source.pageCount} pages.',
        );
      },
      requiredBytes: source.sizeBytes * 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final source = _source;
    return buildToolScaffold(
      title: 'Split PDF',
      actionLabel: 'Split PDF',
      actionIcon: Icons.call_split_rounded,
      actionEnabled: _ready,
      onAction: _split,
      configure: source == null
          ? EmptyState(
              icon: Icons.call_split_rounded,
              title: 'Split or extract pages',
              message: 'Choose a PDF, then split it by page ranges, extract selected pages, or save every page separately.',
              actionLabel: 'Select a PDF',
              onAction: _pick,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                PdfSourceCard(source: source, onChange: _pick),
                const SizedBox(height: 16),
                SegmentedButton<_SplitMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: _SplitMode.ranges, label: Text('Ranges')),
                    ButtonSegment(value: _SplitMode.selected, label: Text('Selected')),
                    ButtonSegment(value: _SplitMode.everyPage, label: Text('Every page')),
                  ],
                  selected: {_mode},
                  onSelectionChanged: (s) => setState(() => _mode = s.first),
                ),
                const SizedBox(height: 12),
                if (_mode == _SplitMode.ranges) ...[
                  TextField(
                    controller: _ranges,
                    onChanged: (_) => setState(() {}),
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: 'Page ranges',
                      hintText: 'e.g. 1-3, 5, 8-${source.pageCount}',
                      helperText: 'Each comma separated range becomes its own PDF.',
                    ),
                  ),
                ] else if (_mode == _SplitMode.selected) ...[
                  Row(
                    children: [
                      Expanded(
                        child: Text('${_selected.length} of ${source.pageCount} pages selected'),
                      ),
                      TextButton(
                        onPressed: () => setState(() {
                          if (_selected.length == source.pageCount) {
                            _selected.clear();
                          } else {
                            _selected.addAll(List.generate(source.pageCount, (i) => i));
                          }
                        }),
                        child: Text(_selected.length == source.pageCount ? 'Clear' : 'Select all'),
                      ),
                    ],
                  ),
                ] else
                  InfoBanner('${source.pageCount} separate PDF files will be created.'),
                const SizedBox(height: 12),
                const SectionHeader('Pages'),
                PdfDocumentHolder(
                  key: ValueKey(source.path),
                  path: source.path,
                  password: source.password,
                  builder: (context, doc) => GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.66,
                    ),
                    itemCount: doc.pages.length,
                    itemBuilder: (context, i) {
                      final selected = _selected.contains(i);
                      return GestureDetector(
                        onTap: () {
                          if (_mode == _SplitMode.selected) {
                            setState(() => selected ? _selected.remove(i) : _selected.add(i));
                          } else {
                            showPdfPagePreview(context, doc, i);
                          }
                        },
                        onLongPress: () => showPdfPagePreview(context, doc, i),
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: selected ? Theme.of(context).colorScheme.secondary : Colors.transparent,
                                    width: 3,
                                  ),
                                ),
                                child: Center(child: PdfPageThumb(document: doc, pageIndex: i, width: 96)),
                              ),
                            ),
                            Positioned(
                              left: 6,
                              bottom: 6,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.7),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontSize: 12)),
                              ),
                            ),
                            if (selected)
                              const Positioned(
                                right: 6,
                                top: 6,
                                child: Icon(Icons.check_circle_rounded, color: Color(0xFFC9A227)),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
