import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/providers.dart';
import '../../../core/services/output_service.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/utilities/format.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/selected_files.dart';
import '../../../core/widgets/tool_run.dart';

class ImagesToPdfPage extends ConsumerStatefulWidget {
  const ImagesToPdfPage({super.key});

  @override
  ConsumerState<ImagesToPdfPage> createState() => _ImagesToPdfPageState();
}

class _ImagesToPdfPageState extends ConsumerState<ImagesToPdfPage> with ToolRunMixin<ImagesToPdfPage> {
  final List<PickedFile> _images = [];
  final _name = TextEditingController(text: 'images');
  final _customW = TextEditingController(text: '210');
  final _customH = TextEditingController(text: '297');
  PdfPageSizeChoice _size = PdfPageSizeChoice.a4;
  PdfOrientation _orientation = PdfOrientation.auto;
  bool _fill = false;
  double _margin = 10;
  double _quality = 85;

  @override
  void dispose() {
    _name.dispose();
    _customW.dispose();
    _customH.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final picked = await ref.read(outputServiceProvider).pick(extensions: AppConstants.imageExtensions);
    if (picked.isNotEmpty) setState(() => _images.addAll(picked));
  }

  ImagesToPdfOptions get _options => ImagesToPdfOptions(
        size: _size,
        orientation: _orientation,
        customWidthMm: double.tryParse(_customW.text) ?? 210,
        customHeightMm: double.tryParse(_customH.text) ?? 297,
        marginMm: _margin,
        fill: _fill,
        quality: _quality.round(),
      );

  Future<void> _create() async {
    final images = [..._images];
    final options = _options;
    await runTool(
      (ctx) async {
        final bytes = await ref.read(pdfServiceProvider).imagesToPdf(
              [for (final i in images) i.path],
              options,
              onProgress: ctx.progress,
              cancel: ctx.cancel,
            );
        final file = await ctx.save(bytes, withExtension(_name.text, 'pdf'));
        return ToolOutcome(
          files: [file],
          headline: 'PDF created',
          note: '${images.length} image(s) · ${formatBytes(bytes.length)}',
        );
      },
      requiredBytes: images.fold<int>(0, (s, e) => s + e.size) * 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    return buildToolScaffold(
      title: 'Images to PDF',
      actionLabel: 'Create PDF',
      actionIcon: Icons.picture_as_pdf_rounded,
      actionEnabled: _images.isNotEmpty && _name.text.trim().isNotEmpty,
      onAction: _create,
      configure: _images.isEmpty
          ? EmptyState(
              icon: Icons.photo_library_rounded,
              title: 'Turn images into a PDF',
              message: 'Pick one or more images (JPG, PNG, WEBP). Each image becomes a page.',
              actionLabel: 'Select images',
              onAction: _add,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SectionHeader('${_images.length} images'),
                SelectedFilesList(
                  imageThumbnails: true,
                  items: [
                    for (final i in _images)
                      SelectedItem(path: i.path, title: i.name, subtitle: formatBytes(i.size)),
                  ],
                  onRemove: (i) => setState(() => _images.removeAt(i)),
                  onReorder: (o, n) => setState(() {
                    final item = _images.removeAt(o);
                    _images.insert(n, item);
                  }),
                ),
                OutlinedButton.icon(
                  onPressed: _add,
                  icon: const Icon(Icons.add_photo_alternate_rounded),
                  label: const Text('Add more images'),
                ),
                const SizedBox(height: 16),
                const SectionHeader('Page setup'),
                ChoiceRow<PdfPageSizeChoice>(
                  label: 'Page size',
                  value: _size,
                  options: PdfPageSizeChoice.values,
                  optionLabel: (v) => switch (v) {
                    PdfPageSizeChoice.a4 => 'A4',
                    PdfPageSizeChoice.letter => 'Letter',
                    PdfPageSizeChoice.custom => 'Custom',
                  },
                  onChanged: (v) => setState(() => _size = v),
                ),
                if (_size == PdfPageSizeChoice.custom)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _customW,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Width', suffixText: 'mm'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _customH,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Height', suffixText: 'mm'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ChoiceRow<PdfOrientation>(
                  label: 'Orientation',
                  value: _orientation,
                  options: PdfOrientation.values,
                  optionLabel: (v) => switch (v) {
                    PdfOrientation.portrait => 'Portrait',
                    PdfOrientation.landscape => 'Landscape',
                    PdfOrientation.auto => 'Auto',
                  },
                  onChanged: (v) => setState(() => _orientation = v),
                ),
                ChoiceRow<bool>(
                  label: 'Image placement',
                  value: _fill,
                  options: const [false, true],
                  optionLabel: (v) => v ? 'Fill page' : 'Fit inside',
                  onChanged: (v) => setState(() => _fill = v),
                ),
                LabeledSlider(
                  label: 'Margin',
                  value: _margin,
                  min: 0,
                  max: 30,
                  divisions: 30,
                  suffix: ' mm',
                  onChanged: (v) => setState(() => _margin = v),
                ),
                LabeledSlider(
                  label: 'Image quality',
                  value: _quality,
                  min: 30,
                  max: 100,
                  divisions: 14,
                  suffix: '%',
                  onChanged: (v) => setState(() => _quality = v),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _name,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(labelText: 'Output file name', suffixText: '.pdf'),
                ),
              ],
            ),
    );
  }
}
