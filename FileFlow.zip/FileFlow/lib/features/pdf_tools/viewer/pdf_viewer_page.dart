import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;
import 'package:pdfrx/pdfrx.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/widgets/common.dart';

class PdfViewerPage extends ConsumerStatefulWidget {
  const PdfViewerPage({super.key, required this.path});

  final String path;

  @override
  ConsumerState<PdfViewerPage> createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends ConsumerState<PdfViewerPage> {
  final PdfViewerController _controller = PdfViewerController();
  late final PdfTextSearcher _searcher = PdfTextSearcher(_controller)..addListener(_onSearchChanged);
  final TextEditingController _query = TextEditingController();
  bool _dark = false;
  bool _searching = false;
  int _page = 1;
  int _count = 0;

  static const _invert = ColorFilter.matrix(<double>[
    -1, 0, 0, 0, 255, //
    0, -1, 0, 0, 255,
    0, 0, -1, 0, 255,
    0, 0, 0, 1, 0,
  ]);

  @override
  void initState() {
    super.initState();
    Future(() => ref.read(libraryProvider.notifier).markOpened(widget.path));
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searcher.removeListener(_onSearchChanged);
    _searcher.dispose();
    _query.dispose();
    super.dispose();
  }

  Future<void> _jump() async {
    final value = await promptText(context, title: 'Go to page', label: 'Page number (1-$_count)');
    final n = int.tryParse(value ?? '');
    if (n == null || n < 1 || n > _count) return;
    await _controller.goToPage(pageNumber: n);
  }

  Future<void> _action(Future<void> Function() job) async {
    try {
      await job();
    } on AppException catch (e) {
      if (mounted) showMessage(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final output = ref.read(outputServiceProvider);
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            tooltip: 'Search text',
            icon: Icon(_searching ? Icons.search_off_rounded : Icons.search_rounded),
            onPressed: () => setState(() {
              _searching = !_searching;
              if (!_searching) _searcher.resetTextSearch();
            }),
          ),
          IconButton(
            tooltip: 'Dark reading mode',
            icon: Icon(_dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
            onPressed: () => setState(() => _dark = !_dark),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              switch (v) {
                case 'share':
                  _action(() => output.share([widget.path]));
                case 'save':
                  _action(() async {
                    final ok = await output.exportCopy(widget.path);
                    if (ok && context.mounted) showMessage(context, 'Copy saved.');
                  });
                case 'open':
                  _action(() => output.openExternally(widget.path));
                case 'info':
                  context.push('/pdf/info', extra: widget.path);
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'share', child: Text('Share')),
              PopupMenuItem(value: 'save', child: Text('Save a copy to…')),
              PopupMenuItem(value: 'open', child: Text('Open with another app')),
              PopupMenuItem(value: 'info', child: Text('Document information')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          if (_searching)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _query,
                      autofocus: true,
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        hintText: 'Search in document',
                        isDense: true,
                        suffixText: _searcher.matches.isEmpty
                            ? (_searcher.isSearching ? '…' : '')
                            : '${(_searcher.currentIndex ?? 0) + 1}/${_searcher.matches.length}',
                      ),
                      onSubmitted: (v) {
                        if (v.trim().isEmpty) {
                          _searcher.resetTextSearch();
                        } else {
                          _searcher.startTextSearch(v.trim());
                        }
                      },
                    ),
                  ),
                  IconButton(
                    tooltip: 'Previous match',
                    icon: const Icon(Icons.keyboard_arrow_up_rounded),
                    onPressed: _searcher.hasMatches ? _searcher.goToPrevMatch : null,
                  ),
                  IconButton(
                    tooltip: 'Next match',
                    icon: const Icon(Icons.keyboard_arrow_down_rounded),
                    onPressed: _searcher.hasMatches ? _searcher.goToNextMatch : null,
                  ),
                ],
              ),
            ),
          Expanded(
            child: ColorFiltered(
              colorFilter: _dark ? _invert : const ColorFilter.mode(Colors.transparent, BlendMode.dst),
              child: PdfViewer.file(
                widget.path,
                controller: _controller,
                passwordProvider: () => promptText(
                  context,
                  title: 'Password required',
                  label: 'Password',
                  obscure: true,
                  confirmLabel: 'Open',
                ),
                params: PdfViewerParams(
                  backgroundColor: _dark ? Colors.black : const Color(0xFFE9E9E6),
                  onViewerReady: (document, controller) {
                    if (mounted) setState(() => _count = document.pages.length);
                  },
                  onPageChanged: (n) {
                    if (mounted && n != null) setState(() => _page = n);
                  },
                  pagePaintCallbacks: [_searcher.pageTextMatchPaintCallback],
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                tooltip: 'Previous page',
                icon: const Icon(Icons.chevron_left_rounded),
                onPressed: _page > 1 ? () => _controller.goToPage(pageNumber: _page - 1) : null,
              ),
              TextButton(
                onPressed: _count > 0 ? _jump : null,
                child: Text(_count == 0 ? 'Loading…' : 'Page $_page of $_count', style: theme.textTheme.titleSmall),
              ),
              IconButton(
                tooltip: 'Next page',
                icon: const Icon(Icons.chevron_right_rounded),
                onPressed: _page < _count ? () => _controller.goToPage(pageNumber: _page + 1) : null,
              ),
              const SizedBox(width: 12),
              IconButton(
                tooltip: 'Zoom out',
                icon: const Icon(Icons.zoom_out_rounded),
                onPressed: _count > 0 ? _controller.zoomDown : null,
              ),
              IconButton(
                tooltip: 'Zoom in',
                icon: const Icon(Icons.zoom_in_rounded),
                onPressed: _count > 0 ? _controller.zoomUp : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
