import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../../core/providers.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/utilities/format.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/selected_files.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

class MergerPage extends ConsumerStatefulWidget {
  const MergerPage({super.key});

  @override
  ConsumerState<MergerPage> createState() => _MergerPageState();
}

class _MergerPageState extends ConsumerState<MergerPage> with ToolRunMixin<MergerPage> {
  final List<PdfSource> _sources = [];
  final _name = TextEditingController(text: 'merged');

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final added = await pickPdfSources(context, ref);
    if (added.isEmpty) return;
    setState(() => _sources.addAll(added));
  }

  Future<void> _merge() async {
    final sources = [..._sources];
    final total = sources.fold<int>(0, (s, e) => s + e.sizeBytes);
    await runTool(
      (ctx) async {
        final bytes = await ref.read(pdfServiceProvider).merge(
              sources,
              onProgress: ctx.progress,
              cancel: ctx.cancel,
            );
        final file = await ctx.save(bytes, withExtension(_name.text, 'pdf'));
        final pages = sources.fold<int>(0, (s, e) => s + e.pageCount);
        return ToolOutcome(
          files: [file],
          headline: 'PDFs merged',
          note: '${sources.length} documents · $pages pages · ${formatBytes(bytes.length)}',
        );
      },
      requiredBytes: total * 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalPages = _sources.fold<int>(0, (s, e) => s + e.pageCount);
    return buildToolScaffold(
      title: 'Merge PDF',
      actionLabel: 'Merge ${_sources.length} PDFs',
      actionIcon: Icons.merge_rounded,
      actionEnabled: _sources.length >= 2 && _name.text.trim().isNotEmpty,
      onAction: _merge,
      configure: _sources.isEmpty
          ? EmptyState(
              icon: Icons.merge_rounded,
              title: 'Combine PDFs into one',
              message: 'Choose two or more PDF files. You can reorder them before merging.',
              actionLabel: 'Select PDFs',
              onAction: _add,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SectionHeader('${_sources.length} documents · $totalPages pages'),
                SelectedFilesList(
                  items: [
                    for (final s in _sources)
                      SelectedItem(
                        path: s.path,
                        title: s.name,
                        subtitle: '${s.pageCount} pages · ${formatBytes(s.sizeBytes)}',
                      ),
                  ],
                  onRemove: (i) => setState(() => _sources.removeAt(i)),
                  onReorder: (o, n) => setState(() {
                    final item = _sources.removeAt(o);
                    _sources.insert(n, item);
                  }),
                ),
                OutlinedButton.icon(
                  onPressed: _add,
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('Add more PDFs'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _name,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(labelText: 'Output file name', suffixText: '.pdf'),
                ),
                const SizedBox(height: 12),
                const InfoBanner(
                  'Drag the handles to change the order. Your original files are never modified; '
                  'the merged PDF is saved as a new file.',
                ),
              ],
            ),
    );
  }
}
