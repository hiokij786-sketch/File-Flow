import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/services/output_service.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/utilities/safe_path.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

class PdfToImagesPage extends ConsumerStatefulWidget {
  const PdfToImagesPage({super.key});

  @override
  ConsumerState<PdfToImagesPage> createState() => _PdfToImagesPageState();
}

class _PdfToImagesPageState extends ConsumerState<PdfToImagesPage> with ToolRunMixin<PdfToImagesPage> {
  PdfSource? _source;
  bool _png = true;
  int _dpi = 150;
  double _quality = 90;
  final _ranges = TextEditingController();

  @override
  void dispose() {
    _ranges.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final result = await pickPdfSources(context, ref, multiple: false);
    if (result.isNotEmpty) setState(() => _source = result.first);
  }

  Future<void> _export() async {
    final source = _source!;
    List<int>? pages;
    if (_ranges.text.trim().isNotEmpty) {
      try {
        pages = parsePageRanges(_ranges.text, source.pageCount).expand((g) => g).toSet().toList()..sort();
      } on AppException catch (e) {
        showMessage(context, e.message, error: true);
        return;
      }
    }
    final base = p.basenameWithoutExtension(source.name);
    final ext = _png ? 'png' : 'jpg';
    final files = <ProcessedFile>[];
    final width = source.pageCount.toString().length;
    await runTool(
      (ctx) async {
        await ref.read(pdfServiceProvider).pdfToImages(
              source.path,
              pages: pages,
              png: _png,
              dpi: _dpi,
              quality: _quality.round(),
              password: source.password,
              onProgress: ctx.progress,
              cancel: ctx.cancel,
              onPage: (number, Uint8List bytes) async {
                files.add(
                  await ctx.save(
                    bytes,
                    '${base}_page_${number.toString().padLeft(width, '0')}.$ext',
                    subfolder: sanitizeFileName('${base}_images'),
                  ),
                );
              },
            );
        return ToolOutcome(
          files: files,
          headline: 'Pages exported',
          note: '${files.length} ${ext.toUpperCase()} image(s) at $_dpi dpi.',
        );
      },
      requiredBytes: source.sizeBytes * 4 + 64 * 1024 * 1024,
    );
  }

  @override
  Widget build(BuildContext context) {
    final source = _source;
    return buildToolScaffold(
      title: 'PDF to Images',
      actionLabel: 'Export images',
      actionIcon: Icons.image_rounded,
      actionEnabled: source != null,
      onAction: _export,
      configure: source == null
          ? EmptyState(
              icon: Icons.image_rounded,
              title: 'Export PDF pages as images',
              message: 'Choose a PDF, then export all or selected pages as PNG or JPEG.',
              actionLabel: 'Select a PDF',
              onAction: _pick,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                PdfSourceCard(source: source, onChange: _pick),
                const SizedBox(height: 12),
                ChoiceRow<bool>(
                  label: 'Format',
                  value: _png,
                  options: const [true, false],
                  optionLabel: (v) => v ? 'PNG (lossless)' : 'JPEG (smaller)',
                  onChanged: (v) => setState(() => _png = v),
                ),
                ChoiceRow<int>(
                  label: 'Resolution',
                  value: _dpi,
                  options: const [72, 150, 200, 300],
                  optionLabel: (v) => '$v dpi',
                  onChanged: (v) => setState(() => _dpi = v),
                ),
                if (!_png)
                  LabeledSlider(
                    label: 'JPEG quality',
                    value: _quality,
                    min: 40,
                    max: 100,
                    divisions: 12,
                    suffix: '%',
                    onChanged: (v) => setState(() => _quality = v),
                  ),
                const SizedBox(height: 8),
                TextField(
                  controller: _ranges,
                  decoration: InputDecoration(
                    labelText: 'Pages (optional)',
                    hintText: 'All ${source.pageCount} pages, or e.g. 1-3, 7',
                  ),
                ),
                const SizedBox(height: 12),
                const InfoBanner('Higher resolutions use more memory and storage. Pages are rendered one at a time.'),
              ],
            ),
    );
  }
}
