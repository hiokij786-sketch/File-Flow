import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../app/tool_registry.dart';
import '../../core/widgets/common.dart';

/// Hub listing every PDF tool.
class PdfToolsPage extends ConsumerWidget {
  const PdfToolsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tools = toolsIn(ToolGroup.pdf);
    return Scaffold(
      appBar: AppBar(title: const Text('PDF tools')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: tools.length + 1,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          if (i == tools.length) {
            return const Padding(
              padding: EdgeInsets.only(top: 6),
              child: InfoBanner('All PDF processing happens on your device. Original files are never modified or uploaded.', icon: Icons.lock_outline_rounded),
            );
          }
          final t = tools[i];
          return ToolTile(icon: t.icon, title: t.title, subtitle: t.subtitle, onTap: () => launchTool(context, ref, t));
        },
      ),
    );
  }
}
