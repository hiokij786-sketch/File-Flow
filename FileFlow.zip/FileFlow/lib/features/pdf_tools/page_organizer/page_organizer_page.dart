import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/providers.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/pdf_widgets.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

class _PageState {
  _PageState(this.index);

  final int index;
  int turns = 0;
  bool checked = false;
}

class PageOrganizerPage extends ConsumerStatefulWidget {
  const PageOrganizerPage({super.key});

  @override
  ConsumerState<PageOrganizerPage> createState() => _PageOrganizerPageState();
}

class _PageOrganizerPageState extends ConsumerState<PageOrganizerPage> with ToolRunMixin<PageOrganizerPage> {
  PdfSource? _source;
  List<_PageState> _pages = [];

  Future<void> _pick() async {
    final result = await pickPdfSources(context, ref, multiple: false);
    if (result.isEmpty) return;
    setState(() {
      _source = result.first;
      _pages = [for (var i = 0; i < result.first.pageCount; i++) _PageState(i)];
    });
  }

  bool get _modified {
    final source = _source;
    if (source == null) return false;
    if (_pages.length != source.pageCount) return true;
    for (var i = 0; i < _pages.length; i++) {
      if (_pages[i].index != i || _pages[i].turns % 4 != 0) return true;
    }
    return false;
  }

  Future<void> _delete(int position) async {
    if (_pages.length == 1) {
      showMessage(context, 'A PDF needs at least one page.', error: true);
      return;
    }
    final ok = await confirmAction(
      context,
      title: 'Remove page ${_pages[position].index + 1}?',
      message: 'The page is removed from the new document. Your original file is not changed.',
      confirmLabel: 'Remove',
      destructive: true,
    );
    if (ok && mounted) setState(() => _pages.removeAt(position));
  }

  Future<void> _save({required bool onlyChecked}) async {
    final source = _source!;
    final chosen = onlyChecked ? _pages.where((e) => e.checked).toList() : [..._pages];
    if (chosen.isEmpty) {
      showMessage(context, 'Tick at least one page to extract.', error: true);
      return;
    }
    final base = p.basenameWithoutExtension(source.name);
    await runTool(
      (ctx) async {
        ctx.report(0.2, 'Building new document');
        final bytes = await ref.read(pdfServiceProvider).buildFromPages(
              source.path,
              [for (final e in chosen) PageSelection(e.index, quarterTurns: e.turns)],
              password: source.password,
            );
        ctx.cancel.throwIfCancelled();
        ctx.report(0.9, 'Saving');
        final file = await ctx.save(bytes, onlyChecked ? '${base}_extracted.pdf' : '${base}_organized.pdf');
        return ToolOutcome(
          files: [file],
          headline: onlyChecked ? 'Pages extracted' : 'PDF saved',
          note: '${chosen.length} page(s) in the new document.',
        );
      },
      requiredBytes: source.sizeBytes * 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final source = _source;
    final theme = Theme.of(context);
    return buildToolScaffold(
      title: 'Organize pages',
      actionLabel: 'Save modified PDF',
      actionIcon: Icons.save_rounded,
      actionEnabled: source != null && _modified,
      onAction: () => _save(onlyChecked: false),
      configure: source == null
          ? EmptyState(
              icon: Icons.dashboard_customize_rounded,
              title: 'Reorder, rotate and delete pages',
              message: 'Choose a PDF to rearrange its pages. The result is saved as a new file.',
              actionLabel: 'Select a PDF',
              onAction: _pick,
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: Column(
                    children: [
                      PdfSourceCard(source: source, onChange: _pick),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${_pages.length} pages · hold the handle to reorder',
                              style: theme.textTheme.bodySmall,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: () => _save(onlyChecked: true),
                            icon: const Icon(Icons.output_rounded, size: 18),
                            label: const Text('Extract ticked'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: PdfDocumentHolder(
                    key: ValueKey(source.path),
                    path: source.path,
                    password: source.password,
                    builder: (context, doc) => ReorderableListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      buildDefaultDragHandles: false,
                      itemCount: _pages.length,
                      onReorderItem: (o, n) => setState(() {
                        final item = _pages.removeAt(o);
                        _pages.insert(n, item);
                      }),
                      itemBuilder: (context, i) {
                        final page = _pages[i];
                        return Padding(
                          key: ValueKey('page-${page.index}'),
                          padding: const EdgeInsets.only(bottom: 8),
                          child: AppCard(
                            padding: const EdgeInsets.all(10),
                            child: Row(
                              children: [
                                ReorderableDragStartListener(
                                  index: i,
                                  child: Icon(Icons.drag_indicator_rounded, color: theme.colorScheme.onSurfaceVariant),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  onTap: () => showPdfPagePreview(context, doc, page.index, quarterTurns: page.turns),
                                  child: SizedBox(
                                    width: 64,
                                    height: 84,
                                    child: Center(
                                      child: PdfPageThumb(
                                        document: doc,
                                        pageIndex: page.index,
                                        width: 64,
                                        quarterTurns: page.turns,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Position ${i + 1}', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                                      Text(
                                        'Original page ${page.index + 1}${page.turns % 4 != 0 ? ' · rotated ${(page.turns % 4) * 90}°' : ''}',
                                        style: theme.textTheme.bodySmall,
                                      ),
                                    ],
                                  ),
                                ),
                                Checkbox(
                                  value: page.checked,
                                  onChanged: (v) => setState(() => page.checked = v ?? false),
                                ),
                                IconButton(
                                  tooltip: 'Rotate',
                                  icon: const Icon(Icons.rotate_right_rounded),
                                  onPressed: () => setState(() => page.turns = (page.turns + 1) % 4),
                                ),
                                IconButton(
                                  tooltip: 'Remove page',
                                  icon: const Icon(Icons.delete_outline_rounded),
                                  onPressed: () => _delete(i),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
