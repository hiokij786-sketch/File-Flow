import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/providers.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

class CompressorPage extends ConsumerStatefulWidget {
  const CompressorPage({super.key});

  @override
  ConsumerState<CompressorPage> createState() => _CompressorPageState();
}

class _CompressorPageState extends ConsumerState<CompressorPage> with ToolRunMixin<CompressorPage> {
  PdfSource? _source;
  late CompressionLevel _level = ref.read(settingsProvider).defaultPdfQuality;

  Future<void> _pick() async {
    final result = await pickPdfSources(context, ref, multiple: false);
    if (result.isNotEmpty) setState(() => _source = result.first);
  }

  Future<void> _compress() async {
    final source = _source!;
    await runTool(
      (ctx) async {
        final result = await ref.read(pdfServiceProvider).compress(
              source.path,
              _level,
              password: source.password,
              onProgress: ctx.progress,
              cancel: ctx.cancel,
            );
        if (!result.reduced) {
          return ToolOutcome(
            success: false,
            headline: 'No size reduction possible',
            note: result.note,
            extra: SizeComparison(original: result.originalSize, result: result.originalSize),
          );
        }
        final base = p.basenameWithoutExtension(source.name);
        final file = await ctx.save(result.bytes!, '${base}_compressed.pdf');
        return ToolOutcome(
          files: [file],
          headline: 'PDF compressed',
          note: '${result.method}.${result.note == null ? '' : ' ${result.note}'}',
          extra: SizeComparison(original: result.originalSize, result: result.resultSize),
        );
      },
      requiredBytes: source.sizeBytes * 3,
    );
  }

  @override
  Widget build(BuildContext context) {
    final source = _source;
    return buildToolScaffold(
      title: 'Compress PDF',
      actionLabel: 'Compress',
      actionIcon: Icons.compress_rounded,
      actionEnabled: source != null,
      onAction: _compress,
      configure: source == null
          ? EmptyState(
              icon: Icons.compress_rounded,
              title: 'Make your PDF smaller',
              message: 'Choose a PDF and a compression level. FILEFLOW only keeps the result when it is really smaller.',
              actionLabel: 'Select a PDF',
              onAction: _pick,
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                PdfSourceCard(source: source, onChange: _pick),
                const SizedBox(height: 16),
                const SectionHeader('Compression level'),
                for (final level in CompressionLevel.values)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AppCard(
                      color: level == _level ? Theme.of(context).colorScheme.primaryContainer : null,
                      onTap: () => setState(() => _level = level),
                      child: Row(
                        children: [
                          Icon(
                            level == _level ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                            color: Theme.of(context).colorScheme.secondary,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(level.label, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                                Text(level.description, style: Theme.of(context).textTheme.bodySmall),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 8),
                const InfoBanner(
                  'Compression runs locally. Medium and High may convert pages to images, which makes '
                  'text non-selectable. PDFs that are already optimized (or text-only) often cannot be '
                  'reduced further; in that case no file is created and you are told why.',
                  warning: true,
                ),
              ],
            ),
    );
  }
}
