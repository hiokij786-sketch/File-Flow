import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../../core/providers.dart';
import '../../../core/services/output_service.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/tool_run.dart';
import '../common/pdf_picking.dart';

enum _Mode { add, remove }

class ProtectionPage extends ConsumerStatefulWidget {
  const ProtectionPage({super.key});

  @override
  ConsumerState<ProtectionPage> createState() => _ProtectionPageState();
}

class _ProtectionPageState extends ConsumerState<ProtectionPage> with ToolRunMixin<ProtectionPage> {
  _Mode _mode = _Mode.add;
  PdfSource? _source;
  PickedFile? _rawFile;
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _confirmedRights = false;

  @override
  void dispose() {
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    if (_mode == _Mode.add) {
      final result = await pickPdfSources(context, ref, multiple: false);
      if (result.isNotEmpty) setState(() => _source = result.first);
    } else {
      final picked = await ref.read(outputServiceProvider).pick(extensions: const ['pdf'], multiple: false);
      if (picked.isNotEmpty) setState(() => _rawFile = picked.first);
    }
  }

  bool get _ready {
    if (_mode == _Mode.add) {
      return _source != null && _password.text.isNotEmpty && _password.text == _confirm.text;
    }
    return _rawFile != null && _password.text.isNotEmpty && _confirmedRights;
  }

  Future<void> _run() async {
    final pdf = ref.read(pdfServiceProvider);
    if (_mode == _Mode.add) {
      final source = _source!;
      final password = _password.text;
      await runTool(
        (ctx) async {
          final bytes = await pdf.protect(
            source.path,
            userPassword: password,
            sourcePassword: source.password,
            onProgress: ctx.progress,
            cancel: ctx.cancel,
          );
          final file = await ctx.save(bytes, '${p.basenameWithoutExtension(source.name)}_protected.pdf');
          return ToolOutcome(
            files: [file],
            headline: 'Password added',
            note: 'The new PDF asks for your password when opened. Keep the password safe: it cannot be recovered. '
                'The protected copy is built from page images, so its text is not selectable.',
          );
        },
        requiredBytes: source.sizeBytes * 4,
      );
    } else {
      final file = _rawFile!;
      final password = _password.text;
      await runTool(
        (ctx) async {
          ctx.report(0.3, 'Checking password');
          final bytes = await pdf.removePassword(file.path, password);
          ctx.report(0.9, 'Saving');
          final saved = await ctx.save(bytes, '${p.basenameWithoutExtension(file.name)}_unlocked.pdf');
          return ToolOutcome(
            files: [saved],
            headline: 'Password removed',
            note: 'A copy without a password was saved. Your original file is unchanged.',
          );
        },
        requiredBytes: file.size * 2,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final adding = _mode == _Mode.add;
    final name = adding ? _source?.name : _rawFile?.name;
    return buildToolScaffold(
      title: 'PDF protection',
      actionLabel: adding ? 'Protect PDF' : 'Remove password',
      actionIcon: adding ? Icons.lock_rounded : Icons.lock_open_rounded,
      actionEnabled: _ready,
      onAction: _run,
      configure: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<_Mode>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: _Mode.add, icon: Icon(Icons.lock_rounded), label: Text('Add password')),
              ButtonSegment(value: _Mode.remove, icon: Icon(Icons.lock_open_rounded), label: Text('Remove')),
            ],
            selected: {_mode},
            onSelectionChanged: (s) => setState(() {
              _mode = s.first;
              _password.clear();
              _confirm.clear();
              _confirmedRights = false;
            }),
          ),
          const SizedBox(height: 16),
          AppCard(
            onTap: _pick,
            child: Row(
              children: [
                const IconBadge(Icons.picture_as_pdf_rounded),
                const SizedBox(width: 12),
                Expanded(child: Text(name ?? 'Select a PDF', maxLines: 2, overflow: TextOverflow.ellipsis)),
                Icon(name == null ? Icons.add_rounded : Icons.swap_horiz_rounded),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _password,
            obscureText: true,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(labelText: adding ? 'New password' : 'Current password'),
          ),
          if (adding) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _confirm,
              obscureText: true,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: 'Repeat password',
                errorText: _confirm.text.isNotEmpty && _confirm.text != _password.text ? 'Passwords do not match' : null,
              ),
            ),
          ] else ...[
            const SizedBox(height: 8),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: _confirmedRights,
              onChanged: (v) => setState(() => _confirmedRights = v ?? false),
              title: const Text('I own this document or I am authorized to unlock it.'),
            ),
          ],
          const SizedBox(height: 12),
          InfoBanner(
            adding
                ? 'Uses standard PDF password security (RC4 128-bit). The protected copy is built from page images '
                    'so that it can be encrypted on-device. Your original stays untouched.'
                : 'The correct password is required. FILEFLOW never bypasses or guesses PDF passwords.',
            icon: Icons.shield_outlined,
          ),
        ],
      ),
    );
  }
}
