import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;
import 'package:pdfrx/pdfrx.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/providers.dart';
import '../../../core/services/pdf_service.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/pdf_widgets.dart';

/// Opens the system picker for PDFs, validates every file and asks for the
/// password of protected documents.
Future<List<PdfSource>> pickPdfSources(
  BuildContext context,
  WidgetRef ref, {
  bool multiple = true,
}) async {
  final picked = await ref.read(outputServiceProvider).pick(extensions: const ['pdf'], multiple: multiple);
  final pdf = ref.read(pdfServiceProvider);
  final result = <PdfSource>[];
  for (final file in picked) {
    String? password;
    while (true) {
      try {
        final source = await pdf.inspect(file.path, password: password);
        result.add(
          PdfSource(
            path: source.path,
            name: file.name,
            sizeBytes: source.sizeBytes,
            pageCount: source.pageCount,
            password: password,
          ),
        );
        break;
      } on AppException catch (e) {
        if (!context.mounted) return result;
        if (e is PasswordRequiredException || e is WrongPasswordException) {
          password = await _askPassword(context, file.name, retry: e is WrongPasswordException);
          if (password == null) break;
        } else {
          showMessage(context, '${file.name}: ${e.message}', error: true);
          break;
        }
      }
    }
  }
  return result;
}

Future<String?> _askPassword(BuildContext context, String name, {required bool retry}) {
  return promptText(
    context,
    title: retry ? 'Wrong password' : 'Password required',
    label: 'Password for ${p.basename(name)}',
    obscure: true,
    confirmLabel: 'Unlock',
    helper: 'The password is only used on this device to read the document.',
  );
}

/// Large preview of one page in a dialog.
Future<void> showPdfPagePreview(
  BuildContext context,
  PdfDocument document,
  int pageIndex, {
  int quarterTurns = 0,
}) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      insetPadding: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: SingleChildScrollView(
                child: PdfPageThumb(
                  document: document,
                  pageIndex: pageIndex,
                  width: MediaQuery.sizeOf(ctx).width - 64,
                  quarterTurns: quarterTurns,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text('Page ${pageIndex + 1}'),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ],
        ),
      ),
    ),
  );
}

/// Compact card describing a selected PDF.
class PdfSourceCard extends StatelessWidget {
  const PdfSourceCard({super.key, required this.source, this.onChange});

  final PdfSource source;
  final VoidCallback? onChange;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AppCard(
      child: Row(
        children: [
          const IconBadge(Icons.picture_as_pdf_rounded),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(source.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                Text(
                  '${source.pageCount} pages · ${formatSize(source.sizeBytes)}',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          if (onChange != null) TextButton(onPressed: onChange, child: const Text('Change')),
        ],
      ),
    );
  }
}

String formatSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
}
