import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../core/providers.dart';
import '../../core/utilities/file_types.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';
import '../file_library/file_actions.dart';

/// Preview for images, text files and a fallback for everything else.
class PreviewPage extends ConsumerWidget {
  const PreviewPage({super.key, required this.path});

  final String path;

  static const _textExt = {'txt', 'md', 'csv', 'json', 'xml', 'html', 'htm', 'log'};

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final output = ref.read(outputServiceProvider);
    final exists = File(path).existsSync();
    final category = categoryOfPath(path);
    final ext = extensionOf(path);
    Widget body;
    if (!exists) {
      body = const EmptyState(icon: Icons.link_off_rounded, title: 'File not found', message: 'This file was moved or deleted.');
    } else if (category == FileCategory.image) {
      body = Container(
        color: Colors.black,
        child: InteractiveViewer(
          maxScale: 6,
          child: Center(child: Image.file(File(path), fit: BoxFit.contain, errorBuilder: (_, _, _) => const Icon(Icons.broken_image_outlined, color: Colors.white, size: 48))),
        ),
      );
    } else if (_textExt.contains(ext) && File(path).lengthSync() < 1024 * 1024) {
      body = FutureBuilder<String>(
        future: File(path).readAsBytes().then((b) => utf8.decode(b, allowMalformed: true)),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: SelectableText(snap.data!, style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.4)),
          );
        },
      );
    } else {
      final stat = File(path).statSync();
      body = Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              FileTypeBadge(category, size: 84),
              const SizedBox(height: 16),
              Text(p.basename(path), textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('${category.label} · ${formatBytes(stat.size)}'),
              const SizedBox(height: 20),
              const Text('FILEFLOW cannot preview this type of file.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => runGuarded(context, () => output.openExternally(path)),
                icon: const Icon(Icons.open_in_new_rounded),
                label: const Text('Open with another app'),
              ),
            ],
          ),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basename(path), style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(tooltip: 'Share', icon: const Icon(Icons.share_rounded), onPressed: exists ? () => runGuarded(context, () => output.share([path])) : null),
          PopupMenuButton<String>(
            onSelected: (v) => runGuarded(context, () async {
              switch (v) {
                case 'save':
                  final ok = await output.exportCopy(path);
                  if (ok && context.mounted) showMessage(context, 'Copy saved.');
                case 'open':
                  await output.openExternally(path);
                case 'info':
                  await showFileInfo(context, path);
              }
            }),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'save', child: Text('Save a copy to…')),
              PopupMenuItem(value: 'open', child: Text('Open with another app')),
              PopupMenuItem(value: 'info', child: Text('Information')),
            ],
          ),
        ],
      ),
      body: SafeArea(top: false, child: body),
    );
  }
}
