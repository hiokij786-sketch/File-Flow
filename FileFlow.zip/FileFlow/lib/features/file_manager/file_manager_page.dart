import 'package:material_ui/material_ui.dart';

import '../file_library/library_tab.dart';
import 'browse_tab.dart';

/// Files tab: folder browser and the internal library.
class FileManagerPage extends StatelessWidget {
  const FileManagerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Files'),
          bottom: const TabBar(
            indicatorColor: Color(0xFFC9A227),
            tabs: [
              Tab(icon: Icon(Icons.folder_rounded), text: 'Browse'),
              Tab(icon: Icon(Icons.collections_bookmark_rounded), text: 'Library'),
            ],
          ),
        ),
        body: const TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [BrowseTab(), LibraryTab()],
        ),
      ),
    );
  }
}
