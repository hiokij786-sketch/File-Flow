import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;

import '../../app/back_handling.dart';
import '../../core/errors/app_exception.dart';
import '../../core/providers.dart';
import '../../core/services/file_ops_service.dart';
import '../../core/utilities/file_types.dart';
import '../../core/utilities/format.dart';
import '../../core/widgets/common.dart';
import '../file_library/file_actions.dart';

/// Browses the FILEFLOW workspace: folders, rename, copy, move, delete, share,
/// search, sort, grid/list, multi-selection.
class BrowseTab extends ConsumerStatefulWidget {
  const BrowseTab({super.key});

  @override
  ConsumerState<BrowseTab> createState() => BrowseTabState();
}

class BrowseTabState extends ConsumerState<BrowseTab> {
  Directory? _root;
  Directory? _current;
  List<FileItem> _items = [];
  bool _loading = true;
  String? _error;
  final Set<String> _selected = {};
  bool _searching = false;
  String _query = '';
  FileCategory? _category;

  bool get _selecting => _selected.isNotEmpty;
  bool get _atRoot => _current != null && _root != null && p.equals(_current!.path, _root!.path);
  bool get _handlesBack => _selecting || _searching || !_atRoot;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    fileBrowserHandlesBack.value = false;
    super.dispose();
  }

  void _syncBack() => fileBrowserHandlesBack.value = _handlesBack;

  Future<void> _init() async {
    final ws = await ref.read(storageServiceProvider).workspace();
    _root = ws;
    _current = ws;
    await _load();
  }

  Future<void> _load() async {
    final dir = _current;
    if (dir == null) return;
    setState(() => _loading = true);
    try {
      final settings = ref.read(settingsProvider);
      final ops = ref.read(fileOpsProvider);
      final items = (_searching && _query.isNotEmpty)
          ? await ops.search(_root!, _query)
          : await ops.list(dir, sort: settings.sortField, ascending: settings.sortAscending, category: _category);
      if (!mounted) return;
      setState(() {
        _items = items;
        _error = null;
      });
    } on AppException catch (e) {
      if (mounted) {
        setState(() => _error = e.message);
        _current = _root;
      }
    } on FileSystemException {
      if (mounted) setState(() => _error = 'This folder could not be read.');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
        _syncBack();
      }
    }
  }

  void _goUp() {
    if (_selecting) {
      setState(_selected.clear);
    } else if (_searching) {
      setState(() {
        _searching = false;
        _query = '';
      });
    } else if (!_atRoot) {
      _current = _current!.parent;
    }
    _load();
  }

  Future<void> _onTap(FileItem item) async {
    if (_selecting) {
      setState(() => _selected.contains(item.path) ? _selected.remove(item.path) : _selected.add(item.path));
      _syncBack();
      return;
    }
    if (item.isDirectory) {
      _current = Directory(item.path);
      _searching = false;
      _query = '';
      await _load();
    } else {
      await openPath(context, ref, item.path);
    }
  }

  void _onLongPress(FileItem item) {
    setState(() => _selected.add(item.path));
    _syncBack();
  }

  Future<Directory?> _chooseFolder() async {
    final root = _root!;
    final dirs = <Directory>[root];
    await for (final e in root.list(recursive: true, followLinks: false)) {
      if (e is Directory && !p.basename(e.path).startsWith('.')) dirs.add(e);
    }
    if (!context.mounted) return null;
    return showModalBottomSheet<Directory>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 8), child: Text('Choose a folder', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            for (final d in dirs)
              ListTile(
                leading: const Icon(Icons.folder_rounded),
                title: Text(p.equals(d.path, root.path) ? 'FILEFLOW (main folder)' : p.relative(d.path, from: root.path)),
                onTap: () => Navigator.pop(ctx, d),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _transfer({required bool move}) async {
    final paths = _selected.toList();
    final dest = await _chooseFolder();
    if (dest == null || !mounted) return;
    await runGuarded(context, () async {
      final ops = ref.read(fileOpsProvider);
      for (final path in paths) {
        if (move) {
          final target = await ops.move(path, dest);
          await ref.read(libraryProvider.notifier).moved(path, target);
        } else {
          await ops.copy(path, dest);
        }
      }
      if (mounted) {
        setState(_selected.clear);
        showMessage(context, move ? 'Moved ${paths.length} item(s).' : 'Copied ${paths.length} item(s).');
      }
    });
    await ref.read(libraryProvider.notifier).refresh();
    await _load();
  }

  Future<void> _deleteSelected() async {
    final paths = _selected.toList();
    final ok = await confirmAction(
      context,
      title: 'Delete ${paths.length} item(s)?',
      message: 'The selected files and folders will be permanently deleted from FILEFLOW storage.',
      confirmLabel: 'Delete',
      destructive: true,
    );
    if (!ok || !mounted) return;
    await runGuarded(context, () async {
      for (final path in paths) {
        await ref.read(fileOpsProvider).delete(path);
        await ref.read(libraryProvider.notifier).forget(path);
      }
    });
    if (mounted) setState(_selected.clear);
    await _load();
  }

  Future<void> _newFolder() async {
    final name = await promptText(context, title: 'New folder', label: 'Folder name', confirmLabel: 'Create');
    if (name == null || name.trim().isEmpty || !mounted) return;
    await runGuarded(context, () => ref.read(fileOpsProvider).createFolder(_current!, name.trim()));
    await _load();
  }

  Future<void> _import() async {
    await runGuarded(context, () async {
      final picked = await ref.read(outputServiceProvider).pick();
      final storage = ref.read(storageServiceProvider);
      for (final f in picked) {
        await storage.copyUnique(File(f.path), _current!, fileName: f.name);
      }
      if (picked.isNotEmpty && mounted) showMessage(context, 'Imported ${picked.length} file(s).');
    });
    await ref.read(libraryProvider.notifier).refresh();
    await _load();
  }

  void _showAddSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.create_new_folder_rounded),
              title: const Text('New folder'),
              onTap: () {
                Navigator.pop(ctx);
                _newFolder();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload_rounded),
              title: const Text('Import files from device'),
              subtitle: const Text('Uses the system file picker'),
              onTap: () {
                Navigator.pop(ctx);
                _import();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _itemMenu(FileItem item, String value) async {
    final output = ref.read(outputServiceProvider);
    await runGuarded(context, () async {
      switch (value) {
        case 'open':
          await _onTap(item);
        case 'rename':
          await renameWithPrompt(context, ref, item.path);
        case 'copy':
        case 'move':
          setState(() {
            _selected
              ..clear()
              ..add(item.path);
          });
          await _transfer(move: value == 'move');
        case 'share':
          await output.share([item.path]);
        case 'export':
          final ok = await output.exportCopy(item.path);
          if (ok && mounted) showMessage(context, 'Copy saved.');
        case 'favorite':
          await ref.read(libraryProvider.notifier).toggleFavorite(item.path);
        case 'info':
          await showFileInfo(context, item.path);
        case 'delete':
          await deleteWithConfirm(context, ref, item.path);
      }
    });
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final theme = Theme.of(context);
    ref.listen(settingsProvider, (previous, next) {
      if (previous?.sortField != next.sortField || previous?.sortAscending != next.sortAscending) _load();
    });
    final rel = (_current == null || _root == null) ? '' : p.relative(_current!.path, from: _root!.path);

    Widget content;
    if (_loading && _items.isEmpty) {
      content = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      content = EmptyState(icon: Icons.error_outline_rounded, title: 'Cannot open folder', message: _error!, actionLabel: 'Go to main folder', onAction: () {
        _current = _root;
        _load();
      });
    } else if (_items.isEmpty) {
      content = EmptyState(
        icon: _searching ? Icons.search_off_rounded : Icons.folder_open_rounded,
        title: _searching ? 'No matches' : 'This folder is empty',
        message: _searching ? 'No file name contains "$_query".' : 'Import files from your device or create a folder. Files you process appear in "Processed".',
        actionLabel: _searching ? null : 'Add',
        onAction: _showAddSheet,
      );
    } else if (settings.gridView) {
      content = GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 0.85),
        itemCount: _items.length,
        itemBuilder: (context, i) {
          final item = _items[i];
          final selected = _selected.contains(item.path);
          return AppCard(
            color: selected ? theme.colorScheme.primaryContainer : null,
            padding: const EdgeInsets.all(10),
            onTap: () => _onTap(item),
            child: GestureDetector(
              onLongPress: () => _onLongPress(item),
              behavior: HitTestBehavior.opaque,
              child: Column(
                children: [
                  Expanded(
                    child: item.category == FileCategory.image && !item.isDirectory
                        ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(item.path), fit: BoxFit.cover, width: double.infinity, cacheWidth: 300, errorBuilder: (_, _, _) => const Icon(Icons.image_not_supported_outlined)))
                        : Center(child: item.isDirectory ? const IconBadge(Icons.folder_rounded, size: 56) : FileTypeBadge(item.category, size: 56)),
                  ),
                  const SizedBox(height: 6),
                  Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: theme.textTheme.labelMedium),
                ],
              ),
            ),
          );
        },
      );
    } else {
      content = ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        itemCount: _items.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final item = _items[i];
          final selected = _selected.contains(item.path);
          return AppCard(
            color: selected ? theme.colorScheme.primaryContainer : null,
            padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
            onTap: () => _onTap(item),
            child: GestureDetector(
              onLongPress: () => _onLongPress(item),
              behavior: HitTestBehavior.opaque,
              child: Row(
                children: [
                  if (_selecting) Padding(padding: const EdgeInsets.only(right: 8), child: Icon(selected ? Icons.check_circle_rounded : Icons.circle_outlined, color: theme.colorScheme.secondary)),
                  item.isDirectory ? const IconBadge(Icons.folder_rounded) : FileTypeBadge(item.category),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                        Text(
                          item.isDirectory ? '${item.childCount} item(s)' : '${formatBytes(item.size)} · ${formatShortDate(item.modified)}',
                          style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  if (!_selecting)
                    PopupMenuButton<String>(
                      onSelected: (v) => _itemMenu(item, v),
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'open', child: Text('Open')),
                        const PopupMenuItem(value: 'rename', child: Text('Rename')),
                        const PopupMenuItem(value: 'copy', child: Text('Copy to…')),
                        const PopupMenuItem(value: 'move', child: Text('Move to…')),
                        if (!item.isDirectory) ...const [
                          PopupMenuItem(value: 'share', child: Text('Share')),
                          PopupMenuItem(value: 'export', child: Text('Export a copy…')),
                          PopupMenuItem(value: 'favorite', child: Text('Favorite / unfavorite')),
                        ],
                        const PopupMenuItem(value: 'info', child: Text('Information')),
                        const PopupMenuItem(value: 'delete', child: Text('Delete')),
                      ],
                    ),
                ],
              ),
            ),
          );
        },
      );
    }

    return PopScope(
      canPop: !_handlesBack,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _handlesBack) _goUp();
      },
      child: Stack(
        children: [
          Column(
            children: [
              if (_selecting)
                Container(
                  color: theme.colorScheme.primaryContainer,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    children: [
                      IconButton(icon: const Icon(Icons.close_rounded), onPressed: () {
                        setState(_selected.clear);
                        _syncBack();
                      }),
                      Expanded(child: Text('${_selected.length} selected', style: const TextStyle(fontWeight: FontWeight.w700))),
                      IconButton(tooltip: 'Select all', icon: const Icon(Icons.select_all_rounded), onPressed: () => setState(() => _selected.addAll(_items.map((e) => e.path)))),
                      IconButton(
                        tooltip: 'Share',
                        icon: const Icon(Icons.share_rounded),
                        onPressed: () => runGuarded(context, () => ref.read(outputServiceProvider).share([for (final path in _selected) if (File(path).existsSync()) path])),
                      ),
                      IconButton(tooltip: 'Copy', icon: const Icon(Icons.copy_rounded), onPressed: () => _transfer(move: false)),
                      IconButton(tooltip: 'Move', icon: const Icon(Icons.drive_file_move_rounded), onPressed: () => _transfer(move: true)),
                      IconButton(tooltip: 'Delete', icon: const Icon(Icons.delete_outline_rounded), onPressed: _deleteSelected),
                    ],
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                  child: Row(
                    children: [
                      if (!_atRoot && !_searching) IconButton(tooltip: 'Up', icon: const Icon(Icons.arrow_upward_rounded), onPressed: _goUp),
                      Expanded(
                        child: _searching
                            ? TextField(
                                autofocus: true,
                                onChanged: (v) {
                                  _query = v.trim();
                                  _load();
                                },
                                decoration: const InputDecoration(hintText: 'Search all folders', isDense: true, prefixIcon: Icon(Icons.search_rounded)),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(rel == '.' ? 'FILEFLOW' : 'FILEFLOW / $rel', maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall),
                              ),
                      ),
                      IconButton(
                        tooltip: 'Search',
                        icon: Icon(_searching ? Icons.search_off_rounded : Icons.search_rounded),
                        onPressed: () {
                          setState(() {
                            _searching = !_searching;
                            _query = '';
                          });
                          _load();
                        },
                      ),
                      PopupMenuButton<SortField>(
                        tooltip: 'Sort',
                        icon: const Icon(Icons.sort_rounded),
                        onSelected: (f) => ref.read(settingsProvider.notifier).update((s) => s.copyWith(
                              sortField: f,
                              sortAscending: s.sortField == f ? !s.sortAscending : true,
                            )),
                        itemBuilder: (_) => [
                          for (final f in SortField.values)
                            CheckedPopupMenuItem(value: f, checked: settings.sortField == f, child: Text('Sort by ${f.name}${settings.sortField == f ? (settings.sortAscending ? ' ↑' : ' ↓') : ''}')),
                        ],
                      ),
                      IconButton(
                        tooltip: settings.gridView ? 'List view' : 'Grid view',
                        icon: Icon(settings.gridView ? Icons.view_list_rounded : Icons.grid_view_rounded),
                        onPressed: () => ref.read(settingsProvider.notifier).update((s) => s.copyWith(gridView: !s.gridView)),
                      ),
                    ],
                  ),
                ),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: FilterChip(label: const Text('All'), selected: _category == null, showCheckmark: false, onSelected: (_) {
                        setState(() => _category = null);
                        _load();
                      }),
                    ),
                    for (final c in FileCategory.values)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          avatar: Icon(c.icon, size: 16),
                          label: Text(c.label),
                          selected: _category == c,
                          showCheckmark: false,
                          onSelected: (_) {
                            setState(() => _category = _category == c ? null : c);
                            _load();
                          },
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(child: RefreshIndicator(onRefresh: _load, child: content)),
            ],
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              onPressed: _showAddSheet,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add'),
            ),
          ),
        ],
      ),
    );
  }
}
