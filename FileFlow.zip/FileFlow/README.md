# FILEFLOW — Everything Your Files Need.

Offline-first file manager and PDF toolkit for Android, written entirely in **Flutter / Dart** (Material 3).
Package `com.fileflow.app` · version `1.0.0` · no account, no uploads, no WebView.

## Features

| Area | What works (all on-device) |
| --- | --- |
| **PDF** | Merge (reorder/remove), split by ranges / selected pages / every page, compress (Low/Medium/High with real size comparison), images → PDF (A4, Letter, custom size, orientation, margins, fit/fill, quality), PDF → PNG/JPEG (page ranges, 72–300 dpi), page organizer (thumbnails, reorder, rotate, delete with confirmation, extract), viewer (zoom, page jump, text search, dark reading mode, share/save/open externally), protection (add password / remove with the correct password), information (pages, size, version, dates, metadata) |
| **Images** | Compress, resize (percentage or custom size with aspect lock), crop + rotate + flip, convert JPG ↔ PNG ↔ WEBP, batch processing, before/after preview, size comparison |
| **Scanner** | Camera (system camera app, no permission) or import, automatic edge detection, manual 4-corner crop, perspective correction, rotate, brightness/contrast, Original/Enhanced/Grayscale/Black & white, multi-page, PDF export |
| **Archives** | ZIP create (compression levels), browse, selective extract, rename on extract, path-traversal protection, invalid/unsupported archive detection (RAR/7z are reported as unsupported), storage check |
| **Files** | Folder browser for the FILEFLOW workspace (create folder, rename, copy, move, delete with confirmation, share, search, 4 sort fields, grid/list, multi-select, info), import via the system picker, export via the system "save as" dialog, favorites, recents, library (All / Processed / Recent / Favorites + categories), missing-file handling |
| **Other** | Dashboard with 10 quick actions, universal search, storage overview + temp cleanup + large files, light/dark/system theme, defaults, privacy + about + open-source licenses, onboarding |

Conversions that cannot run reliably offline (Office documents, HTML → PDF) are **not** offered.

## Architecture

* Flutter + Dart, Material 3 (`material_ui`), **Riverpod** (state), **GoRouter** (navigation, bottom-nav shell with back handling), SharedPreferences (settings, favorites, recents). No database is required.
* Feature-first layout with a service/repository layer:

```
lib/
  main.dart                    # bootstrap, error handling, ProviderScope
  app/                         # app widget, router, theme (light/dark/colors), tool registry
  core/
    constants, errors, utilities
    services/                  # pdf, image, archive, scanner, storage, file ops, output, native bridge
    widgets/                   # shared UI: tool-run workflow, result/progress panels, crop editor …
    providers.dart
  data/                        # models, local preferences store, library repository
  features/                    # home, pdf_tools/*, image_tools/*, scanner, archive_tools/*,
                               # file_manager, file_library, settings
android/                       # Gradle (Kotlin DSL), manifest, MainActivity.kt, icons, splash
.github/workflows/android-release.yml
test/ integration_test/
```

Every tool follows the same workflow (`ToolRunMixin`): select → configure → process with **real progress** and cancel → result (preview, save a copy, share, open) with error handling. Heavy work runs in the pdfrx worker isolate or `Isolate.run`. Originals are never modified; results are written to **FILEFLOW › Processed** under unique names.

### Storage model (no storage permission)

FILEFLOW uses the Android **Storage Access Framework**: you pick files with the system picker (read-only copies are cached and cleaned up on every launch), results are stored in app-specific storage, and you can **export a copy anywhere** with the system "save as" dialog or share it. The app declares **no** storage, camera or internet permission. Consequence: the file manager browses the FILEFLOW workspace, not the whole device.

### Libraries

`pdfrx` (PDFium: rendering, page assembly, viewer), `pdf` (PDF creation), `image` (decode/encode/transform), `archive` (ZIP), `file_picker` (SAF pick/save), `share_plus`, `image_picker` (system camera), `flutter_riverpod`, `go_router`, `shared_preferences`, `path_provider`, `crypto`, `intl`. WEBP **encoding** uses Android's own codec through a small Kotlin platform channel (`MainActivity.kt`), which also opens files with other apps via a `FileProvider`.

## Setup and local development

Requirements: Flutter stable (3.50+ / Dart 3.14+), JDK 17, Android SDK. A C compiler (`clang`) is needed on the host for `flutter test` because of pdfrx's native-asset hooks.

```bash
flutter pub get
flutter analyze
flutter test                  # unit, service, widget tests (downloads PDFium on first PDF test)
flutter run                   # device/emulator
flutter build apk --release   # build/app/outputs/flutter-apk/app-release.apk
flutter test integration_test # on a connected device
```

Regenerate launcher PNGs after changing the logo: `dart --packages=.dart_tool/package_config.json tool/generate_icons.dart`.

## Tests

61 automated tests: PDF merge/split/extract/rotate/reorder/compress/images→PDF/PDF→images/protect/unlock/info against the real PDFium engine; image conversion, compression, resize, rotate, crop, batch; scanner edge detection, perspective and filters; ZIP create/browse/extract/selective/rename/invalid/unsafe-path/insufficient-storage/cancel; file operations (create/rename/copy/move/delete/search/sort); storage cleanup; RC4 test vector; widget tests for onboarding, all five tabs, every tool route and theme switching. `integration_test/app_test.dart` drives the real app on a device.

Not covered by automated tests (needs a real device): system file picker, system camera, share sheet, `FileProvider` open-with, WEBP encoding through the Android codec.

## GitHub upload and Actions

1. Create a repository named `FILEFLOW` on GitHub.
2. Upload the **contents** of the extracted folder (so `pubspec.yaml` is at the repository root). On a phone: GitHub app/website → *Add file → Upload files*, select everything inside the folder (include the hidden `.github` folder; if your file picker hides it, create `.github/workflows/android-release.yml` with *Add file → Create new file* and paste the file contents).
3. Open **Actions → Android Release → Run workflow** (or just push to `main`).
4. When it succeeds, open the run and download **FILEFLOW-Android-APK** from **Artifacts**, unzip it and install `app-release.apk` (allow *Install unknown apps*).

The workflow (`android-release.yml`) runs on Ubuntu with JDK 17, Flutter stable and the Android SDK, then: `flutter pub get` → `flutter analyze` → `flutter test` → `flutter build apk --release` → verifies the APK exists → uploads the artifact. Any failing step fails the run; nothing is uploaded or released if the build fails. The build job only has `contents: read`.

### Releases

```bash
git tag v1.0.0
git push origin v1.0.0
```

Pushing a tag like `v1.0.0` builds from that tag, takes the app version from the tag, and creates a GitHub Release with `FILEFLOW-v1.0.0.apk` attached (needs `contents: write`, granted only to the release job). From a phone: GitHub → *Releases → Draft a new release → Choose a tag → Create new tag `v1.0.0`* and publish. Download the APK from the release page.

## Release signing

Without secrets the workflow still builds an installable APK, but it is signed with the **debug key**; the log shows a warning and tag releases are marked *pre-release*. A debug-signed APK is not a production release.

Create a keystore once (keep it private, **never commit it**):

```bash
keytool -genkey -v -keystore fileflow-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fileflow
base64 -w0 fileflow-release.jks   # copy the output
```

Add these repository secrets (*Settings → Secrets and variables → Actions*): `FILEFLOW_KEYSTORE_BASE64`, `FILEFLOW_KEYSTORE_PASSWORD`, `FILEFLOW_KEY_ALIAS`, `FILEFLOW_KEY_PASSWORD`. **Back up the keystore and passwords** (password manager + offline copy): Android only installs updates signed with the same key, so losing it means users must uninstall. For local release builds create `android/key.properties` (git-ignored) with `storeFile`, `storePassword`, `keyAlias`, `keyPassword`.

## Troubleshooting

* *Workflow fails at `flutter test` with a native asset / compiler error*: make sure the "Install clang" step is present.
* *Gradle / AGP errors after a Flutter upgrade*: re-run `flutter create --platforms android .` in a scratch folder and compare `android/*.gradle.kts` and `gradle-wrapper.properties`.
* *"App not installed"*: uninstall a previous build signed with a different key.
* *PDF compress says no reduction*: the PDF is already optimized; this is reported instead of producing a bigger file.

## Known limitations

* The file manager browses FILEFLOW's own workspace; device files come in through the picker and leave through export/share (Android storage rules, no broad permissions).
* **Protected PDFs** are built from page images (150 dpi) so they can be encrypted on-device; their text is not selectable. Encryption is the standard RC4 128-bit PDF security handler (widely compatible, not AES). Removing a password requires the correct password.
* **Medium/High PDF compression** may convert pages to images (text no longer selectable); Low only re-saves the structure. Embedded images cannot be recompressed in place.
* TXT → PDF supports Latin characters only (built-in PDF fonts); HTML/Office → PDF are not offered.
* Archives: ZIP only. Password-protected ZIP files are not supported.
* Scanner edge detection is a brightness-based heuristic; adjust the corners manually when needed. Camera capture uses the system camera app.
* Monetization: nothing is implemented (no fake purchases or unlocks); core tools are free by design.
* **Build status**: this source was analyzed (`flutter analyze`: no issues) and tested (61 tests passing) with Flutter 3.50 / Dart 3.14. The Android APK itself was **not** built in the authoring environment (no JDK/Android SDK there); the APK is produced by the GitHub Actions workflow.
