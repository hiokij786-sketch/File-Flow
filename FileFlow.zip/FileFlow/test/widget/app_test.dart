@Timeout(Duration(seconds: 90))
library;

import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/app/app.dart';
import 'package:fileflow/app/tool_registry.dart';
import 'package:fileflow/core/providers.dart';
import 'package:fileflow/core/services/native_service.dart';
import 'package:fileflow/core/services/storage_service.dart';
import 'package:fileflow/core/utilities/file_types.dart';
import 'package:fileflow/data/models/library_entry.dart';
import 'package:fileflow/core/widgets/common.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Storage without any real file IO, so widget tests never wait on the disk.
class _FakeStorage extends StorageService {
  _FakeStorage() : super();

  static final Directory _dir = Directory('/fileflow_test_missing');

  @override
  Future<Directory> workspace() async => _dir;
  @override
  Future<Directory> processedDir() async => _dir;
  @override
  Future<Directory> importedDir() async => _dir;
  @override
  Future<StorageInfo?> deviceStorage() async => null;
  @override
  Future<int> directorySize(Directory dir) async => 0;
  @override
  Future<int> temporarySize() async => 0;
  @override
  Future<int> clearTemporary() async => 0;
  @override
  Future<Map<FileCategory, int>> categoryBreakdown() async => {};
  @override
  Future<List<File>> largestFiles({int limit = 20}) async => [];
  @override
  Future<void> ensureSpace(int bytes) async {}
}

class _EmptyLibrary extends LibraryNotifier {
  @override
  Future<List<LibraryEntry>> build() async => const [];
}

Future<ProviderScope> buildApp({required bool onboardingDone}) async {
  SharedPreferences.setMockInitialValues({'onboarding_done': onboardingDone});
  final prefs = await SharedPreferences.getInstance();
  return ProviderScope(
    overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
      storageServiceProvider.overrideWithValue(_FakeStorage()),
      libraryProvider.overrideWith(_EmptyLibrary.new),
    ],
    child: const FileFlowApp(),
  );
}

void main() {
  testWidgets('first launch shows onboarding and leads to Home', (tester) async {
    await tester.pumpWidget(await buildApp(onboardingDone: false));
    await tester.pumpAndSettle();
    expect(find.text('Every PDF tool you need'), findsOneWidget);
    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Get started'));
    await tester.pumpAndSettle();
    expect(find.text('Quick actions'), findsOneWidget);
  });

  testWidgets('home shows dashboard sections and quick actions', (tester) async {
    await tester.pumpWidget(await buildApp(onboardingDone: true));
    await tester.pumpAndSettle();
    expect(find.text('Quick actions'), findsOneWidget);
    expect(find.text('Merge PDF'), findsWidgets);
    expect(find.text('Scan Document'), findsNothing); // titles use registry names
    expect(find.text('Scan document'), findsWidgets);
    expect(find.byType(NavigationBar), findsOneWidget);
  });

  testWidgets('bottom navigation switches between all five tabs', (tester) async {
    await tester.pumpWidget(await buildApp(onboardingDone: true));
    await tester.pumpAndSettle();
    for (final (label, title) in [
      ('PDF Tools', 'Merge PDF'),
      ('Files', 'Browse'),
      ('Image Tools', 'Crop & rotate'),
      ('Settings', 'Appearance'),
      ('Home', 'Quick actions'),
    ]) {
      await tester.tap(find.descendant(of: find.byType(NavigationBar), matching: find.text(label)));
      await tester.pumpAndSettle();
      expect(find.text(title), findsWidgets, reason: 'tab $label should show $title');
    }
  });

  testWidgets('every tool opens its screen without errors', (tester) async {
    await tester.pumpWidget(await buildApp(onboardingDone: true));
    await tester.pumpAndSettle();
    final router = GoRouterLookup.of(tester);
    for (final tool in allTools.where((t) => t.id != 'viewer')) {
      router.push(tool.route);
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull, reason: tool.route);
      expect(find.byType(Scaffold), findsWidgets, reason: tool.route);
      router.pop();
      await tester.pumpAndSettle();
    }
  });

  testWidgets('empty state offers a working action', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: EmptyState(icon: Icons.add, title: 'Nothing here', message: 'Add something', actionLabel: 'Add', onAction: () {}),
        ),
      ),
    );
    expect(find.text('Nothing here'), findsOneWidget);
    expect(find.text('Add'), findsOneWidget);
  });

  testWidgets('settings change the theme mode', (tester) async {
    await tester.pumpWidget(await buildApp(onboardingDone: true));
    await tester.pumpAndSettle();
    await tester.tap(find.descendant(of: find.byType(NavigationBar), matching: find.text('Settings')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Dark'));
    await tester.pumpAndSettle();
    final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
    expect(app.themeMode, ThemeMode.dark);
  });
}

/// Finds the app's [GoRouter] from the widget tree.
class GoRouterLookup {
  static GoRouter of(WidgetTester tester) => GoRouter.of(tester.element(find.byType(Scaffold).first));
}
