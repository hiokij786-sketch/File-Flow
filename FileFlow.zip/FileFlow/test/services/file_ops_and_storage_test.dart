import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/core/errors/app_exception.dart';
import 'package:fileflow/core/services/file_ops_service.dart';
import 'package:fileflow/core/services/storage_service.dart';
import 'package:fileflow/core/utilities/file_types.dart';
import 'package:path/path.dart' as p;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory root;
  late Directory temp;
  late StorageService storage;
  const ops = FileOpsService();

  setUp(() async {
    root = await Directory.systemTemp.createTemp('fileflow_root');
    temp = await Directory.systemTemp.createTemp('fileflow_temp');
    storage = StorageService(rootProvider: () async => root, tempProvider: () async => temp);
  });

  tearDown(() async {
    if (root.existsSync()) await root.delete(recursive: true);
    if (temp.existsSync()) await temp.delete(recursive: true);
  });

  group('file operations', () {
    test('create, rename, copy, move and delete', () async {
      final ws = await storage.workspace();
      final folder = await ops.createFolder(ws, 'Reports');
      expect(folder.existsSync(), isTrue);
      await expectLater(ops.createFolder(ws, 'Reports'), throwsA(isA<AppException>()));

      final file = await storage.writeUnique(ws, 'a.txt', Uint8List.fromList([1, 2, 3]));
      final renamed = await ops.rename(file.path, 'b.txt');
      expect(p.basename(renamed), 'b.txt');
      expect(File(renamed).existsSync(), isTrue);

      final copied = await ops.copy(renamed, folder);
      expect(File(copied).existsSync(), isTrue);
      expect(File(renamed).existsSync(), isTrue);

      final moved = await ops.move(renamed, folder);
      expect(File(renamed).existsSync(), isFalse);
      expect(p.basename(moved), 'b (1).txt', reason: 'never overwrite the copy that already exists');

      await ops.delete(moved);
      expect(File(moved).existsSync(), isFalse);
    });

    test('rename refuses to overwrite', () async {
      final ws = await storage.workspace();
      final a = await storage.writeUnique(ws, 'a.txt', Uint8List(1));
      await storage.writeUnique(ws, 'b.txt', Uint8List(1));
      await expectLater(ops.rename(a.path, 'b.txt'), throwsA(isA<AppException>()));
    });

    test('a folder cannot be moved into itself', () async {
      final ws = await storage.workspace();
      final folder = await ops.createFolder(ws, 'Parent');
      final child = await ops.createFolder(folder, 'Child');
      await expectLater(ops.move(folder.path, child), throwsA(isA<AppException>()));
      await expectLater(ops.copy(folder.path, child), throwsA(isA<AppException>()));
    });

    test('list sorts folders first and supports sort fields and filters', () async {
      final ws = await storage.workspace();
      await ops.createFolder(ws, 'Zed');
      await storage.writeUnique(ws, 'b.pdf', Uint8List(300));
      await storage.writeUnique(ws, 'a.png', Uint8List(100));
      final byName = await ops.list(ws);
      expect(byName.first.isDirectory, isTrue);
      expect(byName.skip(1).map((e) => e.name), ['a.png', 'b.pdf']);
      final bySize = await ops.list(ws, sort: SortField.size, ascending: false);
      expect(bySize.skip(1).map((e) => e.name), ['b.pdf', 'a.png']);
      final pdfs = await ops.list(ws, category: FileCategory.pdf);
      expect(pdfs.where((e) => !e.isDirectory).map((e) => e.name), ['b.pdf']);
    });

    test('search finds files recursively', () async {
      final ws = await storage.workspace();
      final folder = await ops.createFolder(ws, 'Deep');
      await storage.writeUnique(folder, 'invoice_2024.pdf', Uint8List(10));
      final found = await ops.search(ws, 'INVOICE');
      expect(found.map((e) => e.name), ['invoice_2024.pdf']);
      expect(await ops.search(ws, ''), isEmpty);
    });

    test('listing a missing folder fails gracefully', () async {
      await expectLater(ops.list(Directory(p.join(root.path, 'nope'))), throwsA(isA<AppException>()));
    });
  });

  group('storage service', () {
    test('writeUnique never overwrites existing output', () async {
      final dir = await storage.processedDir();
      final first = await storage.writeUnique(dir, 'out.pdf', Uint8List.fromList([1]));
      final second = await storage.writeUnique(dir, 'out.pdf', Uint8List.fromList([2]));
      expect(first.path, isNot(second.path));
      expect(first.readAsBytesSync(), [1]);
    });

    test('clearTemporary removes cache but never workspace files', () async {
      final dir = await storage.processedDir();
      final keep = await storage.writeUnique(dir, 'keep.pdf', Uint8List(2048));
      File(p.join(temp.path, 'picked.pdf')).writeAsBytesSync(Uint8List(4096));
      Directory(p.join(temp.path, 'file_picker')).createSync();
      File(p.join(temp.path, 'file_picker', 'x.jpg')).writeAsBytesSync(Uint8List(1000));
      expect(await storage.temporarySize(), 5096);
      final freed = await storage.clearTemporary();
      expect(freed, 5096);
      expect(await storage.temporarySize(), 0);
      expect(keep.existsSync(), isTrue);
    });

    test('category breakdown and largest files', () async {
      final dir = await storage.processedDir();
      await storage.writeUnique(dir, 'a.pdf', Uint8List(500));
      await storage.writeUnique(dir, 'b.jpg', Uint8List(200));
      final breakdown = await storage.categoryBreakdown();
      expect(breakdown[FileCategory.pdf], 500);
      expect(breakdown[FileCategory.image], 200);
      final large = await storage.largestFiles(limit: 1);
      expect(p.basename(large.single.path), 'a.pdf');
    });
  });
}
