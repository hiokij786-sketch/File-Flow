import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/core/errors/app_exception.dart';
import 'package:fileflow/core/services/archive_service.dart';
import 'package:fileflow/core/utilities/cancel_token.dart';
import 'package:path/path.dart' as p;

void main() {
  late Directory dir;
  const service = ArchiveService();

  setUp(() async {
    dir = await Directory.systemTemp.createTemp('fileflow_zip');
  });

  tearDown(() async {
    if (dir.existsSync()) await dir.delete(recursive: true);
  });

  File writeFile(String name, List<int> bytes) => File(p.join(dir.path, name))..writeAsBytesSync(bytes);

  Future<File> makeZip(Map<String, String> entries) async {
    final archive = Archive();
    entries.forEach((name, content) => archive.addFile(ArchiveFile.bytes(name, content.codeUnits)));
    return writeFile('test.zip', ZipEncoder().encode(archive));
  }

  test('create then browse then extract round-trips content', () async {
    final a = writeFile('a.txt', 'hello'.codeUnits);
    final b = writeFile('b.txt', 'world'.codeUnits);
    final zipPath = p.join(dir.path, 'out.zip');
    final progress = <double>[];
    final zip = await service.create(
      [ArchiveInput(a.path), ArchiveInput(b.path, entryName: 'renamed.txt')],
      zipPath,
      onProgress: (f, _) => progress.add(f),
    );
    expect(zip.existsSync(), isTrue);
    expect(progress.last, 1);

    final entries = await service.list(zipPath);
    expect(entries.map((e) => e.name), unorderedEquals(['a.txt', 'renamed.txt']));
    expect(entries.every((e) => e.isSafe), isTrue);

    final dest = Directory(p.join(dir.path, 'extracted'));
    final result = await service.extract(zipPath, dest);
    expect(result.skipped, isEmpty);
    expect(File(p.join(dest.path, 'a.txt')).readAsStringSync(), 'hello');
    expect(File(p.join(dest.path, 'renamed.txt')).readAsStringSync(), 'world');
  });

  test('duplicate input names get unique entry names', () async {
    final a = writeFile('a.txt', [1]);
    final zipPath = p.join(dir.path, 'dup.zip');
    await service.create([ArchiveInput(a.path), ArchiveInput(a.path)], zipPath);
    final names = (await service.list(zipPath)).map((e) => e.name).toList();
    expect(names.toSet().length, 2);
  });

  test('path traversal entries are skipped and never written outside', () async {
    final zip = await makeZip({'../evil.txt': 'bad', 'safe/ok.txt': 'ok', '/abs.txt': 'bad'});
    final entries = await service.list(zip.path);
    expect(entries.where((e) => !e.isSafe).length, 2);

    final dest = Directory(p.join(dir.path, 'out'));
    final result = await service.extract(zip.path, dest);
    expect(result.skipped.length, 2);
    expect(File(p.join(dir.path, 'evil.txt')).existsSync(), isFalse);
    expect(File(p.join(dest.path, 'safe', 'ok.txt')).existsSync(), isTrue);
  });

  test('selective extraction and renaming', () async {
    final zip = await makeZip({'one.txt': '1', 'two.txt': '2', 'three.txt': '3'});
    final dest = Directory(p.join(dir.path, 'sel'));
    final result = await service.extract(
      zip.path,
      dest,
      only: {'two.txt'},
      renames: {'two.txt': 'second.txt'},
    );
    expect(result.written.length, 1);
    expect(File(p.join(dest.path, 'second.txt')).readAsStringSync(), '2');
    expect(File(p.join(dest.path, 'one.txt')).existsSync(), isFalse);
  });

  test('existing files are not overwritten', () async {
    final zip = await makeZip({'a.txt': 'new'});
    final dest = Directory(p.join(dir.path, 'ex'))..createSync();
    File(p.join(dest.path, 'a.txt')).writeAsStringSync('old');
    await service.extract(zip.path, dest);
    expect(File(p.join(dest.path, 'a.txt')).readAsStringSync(), 'old');
    expect(File(p.join(dest.path, 'a (1).txt')).readAsStringSync(), 'new');
  });

  test('invalid and unsupported archives give clear errors', () async {
    final junk = writeFile('junk.zip', List.generate(64, (i) => i));
    await expectLater(service.list(junk.path), throwsA(isA<AppException>()));

    final rar = writeFile('x.rar', [0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00, 0, 0, 0]);
    await expectLater(
      service.list(rar.path),
      throwsA(isA<AppException>().having((e) => e.message, 'message', contains('RAR'))),
    );
    expect(ArchiveService.unsupportedFormat(Uint8List.fromList([0x37, 0x7A, 0xBC, 0xAF])), '7-Zip');
  });

  test('insufficient storage aborts before writing', () async {
    final zip = await makeZip({'a.txt': 'abc'});
    final dest = Directory(p.join(dir.path, 'nospace'));
    await expectLater(
      service.extract(zip.path, dest, checkSpace: (_) async => throw const InsufficientStorageException('full')),
      throwsA(isA<InsufficientStorageException>()),
    );
    expect(dest.existsSync() && dest.listSync().isNotEmpty, isFalse);
  });

  test('cancellation stops extraction', () async {
    final zip = await makeZip({'a.txt': '1', 'b.txt': '2'});
    final token = CancelToken()..cancel();
    await expectLater(
      service.extract(zip.path, Directory(p.join(dir.path, 'c')), cancel: token),
      throwsA(isA<CancelledException>()),
    );
  });
}
