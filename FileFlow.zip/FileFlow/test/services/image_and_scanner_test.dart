import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/core/errors/app_exception.dart';
import 'package:fileflow/core/services/image_service.dart';
import 'package:fileflow/core/services/scanner_service.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;

Uint8List noisyJpeg(int w, int h) {
  final image = img.Image(width: w, height: h);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      image.setPixelRgb(x, y, (x * 7 + y * 3) % 256, (x * 5) % 256, (y * 11) % 256);
    }
  }
  return img.encodeJpg(image, quality: 95);
}

void main() {
  const service = ImageService();

  group('image edits', () {
    test('JPG to PNG and PNG to JPG conversion', () {
      final jpg = noisyJpeg(64, 48);
      final png = applyImageEdit(jpg, const ImageEdit(format: OutputImageFormat.png));
      expect(png.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]);
      expect(img.decodePng(png)!.width, 64);

      final back = applyImageEdit(png, const ImageEdit(format: OutputImageFormat.jpg, quality: 80));
      expect(back.sublist(0, 2), [0xFF, 0xD8]);
    });

    test('transparent PNG is flattened on white for JPG', () {
      final image = img.Image(width: 8, height: 8, numChannels: 4);
      final png = img.encodePng(image);
      final jpg = applyImageEdit(png, const ImageEdit(format: OutputImageFormat.jpg, quality: 100));
      final decoded = img.decodeJpg(jpg)!;
      final px = decoded.getPixel(4, 4);
      expect(px.r, greaterThan(240));
    });

    test('WEBP target yields a lossless intermediate for the native codec', () {
      final out = applyImageEdit(noisyJpeg(32, 32), const ImageEdit(format: OutputImageFormat.webp));
      expect(out.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]);
    });

    test('WEBP input can be decoded', () {
      // Minimal 1x1 lossless WEBP.
      final webp = Uint8List.fromList([
        0x52, 0x49, 0x46, 0x46, 0x1A, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50, 0x56, 0x50, 0x38, 0x4C, //
        0x0D, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x10, 0x07, 0x10, 0x11, 0x11, 0x88, 0x88, 0xFE,
        0x07, 0x00,
      ]);
      final out = applyImageEdit(webp, const ImageEdit(format: OutputImageFormat.png));
      expect(img.decodePng(out), isNotNull);
    });

    test('compression reduces size with lower quality', () {
      final jpg = noisyJpeg(200, 200);
      final small = applyImageEdit(jpg, const ImageEdit(quality: 30));
      expect(small.length, lessThan(jpg.length));
    });

    test('resize by dimensions, scale and long side', () {
      final jpg = noisyJpeg(200, 100);
      expect(img.decodeJpg(applyImageEdit(jpg, const ImageEdit(width: 100)))!.height, 50);
      final exact = img.decodeJpg(applyImageEdit(jpg, const ImageEdit(width: 40, height: 40)))!;
      expect((exact.width, exact.height), (40, 40));
      expect(img.decodeJpg(applyImageEdit(jpg, const ImageEdit(scale: 0.5)))!.width, 100);
      expect(img.decodeJpg(applyImageEdit(jpg, const ImageEdit(maxLongSide: 50)))!.width, 50);
    });

    test('rotation, flip and crop', () {
      final jpg = noisyJpeg(200, 100);
      final rotated = img.decodeJpg(applyImageEdit(jpg, const ImageEdit(quarterTurns: 1)))!;
      expect((rotated.width, rotated.height), (100, 200));
      final cropped = img.decodeJpg(applyImageEdit(jpg, const ImageEdit(crop: CropRect(0, 0, 0.5, 0.5))))!;
      expect((cropped.width, cropped.height), (100, 50));
      expect(img.decodeJpg(applyImageEdit(jpg, const ImageEdit(flipHorizontal: true)))!.width, 200);
    });

    test('damaged images raise a friendly error', () {
      expect(() => applyImageEdit(Uint8List.fromList([1, 2, 3]), const ImageEdit()), throwsA(isA<AppException>()));
    });
  });

  group('batch processing', () {
    test('processes every file with real progress', () async {
      final dir = await Directory.systemTemp.createTemp('fileflow_img');
      addTearDown(() => dir.delete(recursive: true));
      final paths = <String>[];
      for (var i = 0; i < 3; i++) {
        final f = File(p.join(dir.path, 'i$i.jpg'))..writeAsBytesSync(noisyJpeg(80 + i * 10, 60));
        paths.add(f.path);
      }
      final fractions = <double>[];
      final results = <String, ImageResult>{};
      await service.processBatch(
        paths,
        const ImageEdit(format: OutputImageFormat.png),
        onResult: (path, r) async => results[path] = r,
        onProgress: (f, _) => fractions.add(f),
      );
      expect(results.length, 3);
      expect(fractions.first, 0);
      expect(fractions.last, 1);
      expect(results.values.every((r) => r.bytes.sublist(0, 4).first == 0x89), isTrue);
      expect((await service.sizeOf(paths[1])).width, 90);
    });
  });

  group('scanner', () {
    Uint8List documentPhoto() {
      final image = img.Image(width: 300, height: 400);
      img.fill(image, color: img.ColorRgb8(30, 30, 30));
      img.fillRect(image, x1: 60, y1: 80, x2: 240, y2: 340, color: img.ColorRgb8(245, 245, 240));
      return img.encodeJpg(image, quality: 95);
    }

    test('edge detection finds the bright page', () {
      final corners = detectCornersSync(documentPhoto());
      expect(corners.tl.x, closeTo(0.2, 0.08));
      expect(corners.tl.y, closeTo(0.2, 0.08));
      expect(corners.br.x, closeTo(0.8, 0.08));
      expect(corners.br.y, closeTo(0.85, 0.08));
      expect(corners.isFull, isFalse);
    });

    test('perspective correction and all filters render', () {
      final photo = documentPhoto();
      final corners = detectCornersSync(photo);
      for (final filter in ScanFilter.values) {
        final out = renderScanSync(photo, ScanEdit(corners: corners, filter: filter, brightness: 1.1, contrast: 1.1));
        final decoded = img.decodeJpg(out)!;
        expect(decoded.width, greaterThan(100));
        expect(decoded.height, greaterThan(100));
      }
    });

    test('rotation swaps dimensions', () {
      final photo = documentPhoto();
      final out = renderScanSync(photo, const ScanEdit(quarterTurns: 1, filter: ScanFilter.original));
      final decoded = img.decodeJpg(out)!;
      expect((decoded.width, decoded.height), (400, 300));
    });

    test('black and white output only contains two tones', () {
      final out = renderScanSync(documentPhoto(), const ScanEdit(filter: ScanFilter.blackWhite), quality: 100);
      final decoded = img.decodeJpg(out)!;
      final px = decoded.getPixel(150, 200);
      expect(px.r > 200 || px.r < 55, isTrue);
    });
  });
}
