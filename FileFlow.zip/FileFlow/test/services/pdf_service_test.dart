import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/core/errors/app_exception.dart';
import 'package:fileflow/core/services/pdf_service.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:pdf/widgets.dart' as pw;
import 'package:pdfrx_engine/pdfrx_engine.dart' as engine;

Future<Uint8List> buildPdf(int pages, {String label = 'Page'}) async {
  final doc = pw.Document();
  for (var i = 0; i < pages; i++) {
    doc.addPage(
      pw.Page(
        build: (_) => pw.Center(child: pw.Text('$label ${i + 1}', style: const pw.TextStyle(fontSize: 40))),
      ),
    );
  }
  return doc.save();
}

void main() {
  late Directory dir;
  const service = PdfService();

  setUpAll(() async {
    PdfService.initializer = () => engine.pdfrxInitialize(tmpPath: Directory.systemTemp.path);
    await PdfService.ensureInitialized();
  });

  setUp(() async {
    dir = await Directory.systemTemp.createTemp('fileflow_pdf_test');
  });

  tearDown(() async {
    if (dir.existsSync()) await dir.delete(recursive: true);
  });

  Future<String> write(String name, Uint8List bytes) async {
    final file = File(p.join(dir.path, name));
    await file.writeAsBytes(bytes);
    return file.path;
  }

  Future<int> pageCount(Uint8List bytes) async {
    final path = await write('count_${bytes.length}.pdf', bytes);
    return (await service.inspect(path)).pageCount;
  }

  test('merge combines pages in order', () async {
    final a = await write('a.pdf', await buildPdf(2, label: 'A'));
    final b = await write('b.pdf', await buildPdf(3, label: 'B'));
    final sources = [
      await service.inspect(a),
      await service.inspect(b),
    ];
    final merged = await service.merge(sources);
    expect(await pageCount(merged), 5);
  });

  test('merge needs at least two documents', () async {
    final a = await write('a.pdf', await buildPdf(1));
    final source = await service.inspect(a);
    expect(() => service.merge([source]), throwsA(isA<AppException>()));
  });

  test('extract, reorder and rotate pages', () async {
    final path = await write('src.pdf', await buildPdf(4));
    final extracted = await service.buildFromPages(path, const [PageSelection(0), PageSelection(2)]);
    expect(await pageCount(extracted), 2);

    final reordered = await service.buildFromPages(path, const [PageSelection(3), PageSelection(2), PageSelection(1), PageSelection(0)]);
    expect(await pageCount(reordered), 4);

    final rotated = await service.buildFromPages(path, const [PageSelection(0, quarterTurns: 1)]);
    final rotatedPath = await write('rot.pdf', rotated);
    final doc = await service.open(rotatedPath);
    expect(doc.pages.first.rotation.index, 1);
    await doc.dispose();
  });

  test('split into groups produces one file per group', () async {
    final path = await write('src.pdf', await buildPdf(5));
    final outputs = <Uint8List>[];
    await service.splitGroups(
      path,
      [
        [0, 1],
        [2],
        [3, 4],
      ],
      onFile: (i, bytes) async => outputs.add(bytes),
    );
    expect(outputs.length, 3);
    expect(await pageCount(outputs[0]), 2);
    expect(await pageCount(outputs[1]), 1);
    expect(await pageCount(outputs[2]), 2);
  });

  test('compress never reports a larger file as compressed', () async {
    final path = await write('src.pdf', await buildPdf(3));
    final original = File(path).lengthSync();
    for (final level in CompressionLevel.values) {
      final result = await service.compress(path, level);
      expect(result.originalSize, original);
      if (result.bytes != null) {
        expect(result.bytes!.length, lessThan(original));
        expect(result.reduced, isTrue);
      } else {
        expect(result.reduced, isFalse);
        expect(result.note, isNotNull);
      }
    }
  });

  test('images to PDF creates one page per image', () async {
    final paths = <String>[];
    for (var i = 0; i < 3; i++) {
      final image = img.Image(width: 120 + i * 30, height: 80);
      img.fill(image, color: img.ColorRgb8(40 * i, 120, 200));
      paths.add(await write('img$i.png', img.encodePng(image)));
    }
    final bytes = await service.imagesToPdf(paths, const ImagesToPdfOptions(orientation: PdfOrientation.auto));
    expect(await pageCount(bytes), 3);
    final landscape = await service.imagesToPdf(paths.take(1).toList(), const ImagesToPdfOptions(size: PdfPageSizeChoice.letter, fill: true));
    expect(await pageCount(landscape), 1);
  });

  test('PDF pages export to PNG and JPEG', () async {
    final path = await write('src.pdf', await buildPdf(3));
    final png = <int, Uint8List>{};
    await service.pdfToImages(path, png: true, dpi: 72, onPage: (n, b) async => png[n] = b);
    expect(png.keys, [1, 2, 3]);
    expect(png[1]!.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]);

    final jpg = <int, Uint8List>{};
    await service.pdfToImages(path, pages: [1], png: false, dpi: 96, quality: 80, onPage: (n, b) async => jpg[n] = b);
    expect(jpg.keys, [2]);
    expect(jpg[2]!.sublist(0, 2), [0xFF, 0xD8]);
  });

  test('protect requires the password; remove needs the correct one', () async {
    final path = await write('src.pdf', await buildPdf(2));
    final protectedBytes = await service.protect(path, userPassword: 'secret');
    final protectedPath = await write('protected.pdf', protectedBytes);

    await expectLater(service.open(protectedPath), throwsA(isA<PasswordRequiredException>()));
    await expectLater(service.open(protectedPath, password: 'wrong'), throwsA(isA<WrongPasswordException>()));
    final doc = await service.open(protectedPath, password: 'secret');
    expect(doc.pages.length, 2);
    await doc.dispose();

    await expectLater(service.removePassword(protectedPath, 'wrong'), throwsA(isA<AppException>()));
    final unlocked = await service.removePassword(protectedPath, 'secret');
    final unlockedPath = await write('unlocked.pdf', unlocked);
    final open = await service.open(unlockedPath);
    expect(open.isEncrypted, isFalse);
    await open.dispose();
  });

  test('info reports pages, version and size', () async {
    final path = await write('src.pdf', await buildPdf(2));
    final info = await service.info(path);
    expect(info.pageCount, 2);
    expect(info.sizeBytes, File(path).lengthSync());
    expect(info.version, isNotNull);
    expect(info.isEncrypted, isFalse);
  });

  test('damaged files raise a friendly error', () async {
    final path = await write('bad.pdf', Uint8List.fromList(List.generate(200, (i) => i % 256)));
    await expectLater(service.open(path), throwsA(isA<AppException>()));
  });

  test('text to PDF produces readable pages', () async {
    final bytes = await service.textToPdf('Hello FILEFLOW\n${'line\n' * 120}');
    expect(await pageCount(bytes), greaterThanOrEqualTo(2));
  });
}
