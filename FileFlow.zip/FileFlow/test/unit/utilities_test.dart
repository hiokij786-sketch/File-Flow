import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:fileflow/core/errors/app_exception.dart';
import 'package:fileflow/core/services/pdf_service.dart';
import 'package:fileflow/core/utilities/cancel_token.dart';
import 'package:fileflow/core/utilities/file_types.dart';
import 'package:fileflow/core/utilities/format.dart';
import 'package:fileflow/core/utilities/safe_path.dart';
import 'package:fileflow/core/services/pdf_encryption.dart';
import 'package:path/path.dart' as p;
import 'dart:typed_data';
import 'dart:convert';

void main() {
  group('safe paths', () {
    test('sanitizeFileName removes unsafe characters', () {
      expect(sanitizeFileName('a/b\\c:d*e?.pdf'), 'a_b_c_d_e_.pdf');
      expect(sanitizeFileName('...hidden'), 'hidden');
      expect(sanitizeFileName('   '), 'file');
      expect(sanitizeFileName('x' * 300).length, lessThanOrEqualTo(120));
    });

    test('archive entry names that escape the folder are rejected', () {
      expect(isSafeArchiveEntryName('docs/readme.txt'), isTrue);
      expect(isSafeArchiveEntryName('../evil.txt'), isFalse);
      expect(isSafeArchiveEntryName('a/../../evil.txt'), isFalse);
      expect(isSafeArchiveEntryName('/etc/passwd'), isFalse);
      expect(isSafeArchiveEntryName('C:\\Windows\\x.dll'), isFalse);
      expect(isSafeArchiveEntryName('..\\evil.txt'), isFalse);
      expect(isSafeArchiveEntryName(''), isFalse);
    });

    test('uniquePath never overwrites', () async {
      final dir = await Directory.systemTemp.createTemp('fileflow_unique');
      addTearDown(() => dir.delete(recursive: true));
      File(p.join(dir.path, 'a.pdf')).writeAsStringSync('x');
      File(p.join(dir.path, 'a (1).pdf')).writeAsStringSync('x');
      expect(p.basename(uniquePath(dir.path, 'a.pdf')), 'a (2).pdf');
      expect(p.basename(uniquePath(dir.path, 'b.pdf')), 'b.pdf');
    });

    test('withExtension appends only when needed', () {
      expect(withExtension('report', 'pdf'), 'report.pdf');
      expect(withExtension('report.PDF', 'pdf'), 'report.PDF');
      expect(withExtension('notes.txt', 'pdf'), 'notes.pdf');
    });
  });

  group('formatting', () {
    test('formatBytes', () {
      expect(formatBytes(0), '0 B');
      expect(formatBytes(1023), '1023 B');
      expect(formatBytes(1536), '1.5 KB');
      expect(formatBytes(5 * 1024 * 1024), '5.0 MB');
    });

    test('reductionPercent is real and can be negative', () {
      expect(reductionPercent(1000, 250), 75);
      expect(reductionPercent(1000, 1200), -20);
      expect(reductionPercent(0, 10), 0);
    });

    test('greeting depends on time', () {
      expect(greetingFor(DateTime(2024, 1, 1, 8)), 'Good morning');
      expect(greetingFor(DateTime(2024, 1, 1, 14)), 'Good afternoon');
      expect(greetingFor(DateTime(2024, 1, 1, 20)), 'Good evening');
    });
  });

  group('file categories', () {
    test('categoryOfPath', () {
      expect(categoryOfPath('/a/b.PDF'), FileCategory.pdf);
      expect(categoryOfPath('x.webp'), FileCategory.image);
      expect(categoryOfPath('x.mp4'), FileCategory.video);
      expect(categoryOfPath('x.mp3'), FileCategory.audio);
      expect(categoryOfPath('x.docx'), FileCategory.document);
      expect(categoryOfPath('x.zip'), FileCategory.archive);
      expect(categoryOfPath('x.bin'), FileCategory.other);
    });
  });

  group('page ranges', () {
    test('parses ranges and single pages', () {
      expect(parsePageRanges('1-3, 5', 10), [
        [0, 1, 2],
        [4],
      ]);
      expect(parsePageRanges('8-', 10), [
        [7, 8, 9],
      ]);
      expect(parsePageRanges('-2', 10), [
        [0, 1],
      ]);
    });

    test('rejects invalid input', () {
      expect(() => parsePageRanges('', 10), throwsA(isA<AppException>()));
      expect(() => parsePageRanges('0', 10), throwsA(isA<AppException>()));
      expect(() => parsePageRanges('11', 10), throwsA(isA<AppException>()));
      expect(() => parsePageRanges('5-2', 10), throwsA(isA<AppException>()));
      expect(() => parsePageRanges('a-b', 10), throwsA(isA<AppException>()));
    });
  });

  group('cancel token', () {
    test('throws after cancel', () {
      final token = CancelToken();
      token.throwIfCancelled();
      token.cancel();
      expect(token.throwIfCancelled, throwsA(isA<CancelledException>()));
    });
  });

  group('PDF metadata parsing', () {
    test('reads version, fields and dates', () {
      final bytes = Uint8List.fromList(latin1.encode(
        '%PDF-1.7\n1 0 obj\n<< /Title (My \\(Doc\\)) /Author (Jane) /CreationDate (D:20240131103000Z) >>\nendobj',
      ));
      final raw = PdfService.parseRawMetadata(bytes);
      expect(raw.version, '1.7');
      expect(raw.fields['Title'], 'My (Doc)');
      expect(raw.fields['Author'], 'Jane');
      final date = PdfService.parsePdfDate(raw.fields['CreationDate']!);
      expect(date, DateTime(2024, 1, 31, 10, 30));
    });
  });

  group('RC4', () {
    test('matches the published test vector', () {
      final out = rc4(Uint8List.fromList(utf8.encode('Key')), Uint8List.fromList(utf8.encode('Plaintext')));
      final hex = out.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
      expect(hex, 'bbf316e8d940af0ad3');
    });

    test('owner and user entries are 32 bytes', () {
      final o = StandardRc4Encryption.computeOwnerEntry('user', 'owner');
      expect(o.length, 32);
      final key = StandardRc4Encryption.computeFileKey('user', o, -4, Uint8List(16));
      expect(key.length, 16);
      expect(StandardRc4Encryption.computeUserEntry(key, Uint8List(16)).length, 32);
    });
  });
}
