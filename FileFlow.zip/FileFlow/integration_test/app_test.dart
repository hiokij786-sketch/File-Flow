// Run on a device or emulator:  flutter test integration_test
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:fileflow/main.dart' as app;
import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('launch, navigate every tab and open a tool', (tester) async {
    SharedPreferences.setMockInitialValues({'onboarding_done': true});
    await app.main();
    await tester.pumpAndSettle(const Duration(seconds: 2));

    expect(find.text('Quick actions'), findsOneWidget);

    for (final label in ['PDF Tools', 'Files', 'Image Tools', 'Settings', 'Home']) {
      await tester.tap(find.descendant(of: find.byType(NavigationBar), matching: find.text(label)));
      await tester.pumpAndSettle();
    }

    await tester.tap(find.text('Merge PDF').first);
    await tester.pumpAndSettle();
    expect(find.text('Select PDFs'), findsOneWidget);
  });
}
