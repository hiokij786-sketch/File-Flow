package com.fileflow.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.StatFs
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Native bridge used for the few things Flutter plugins do not cover:
 *  - opening a file with an external app (ACTION_VIEW through a FileProvider),
 *  - encoding WEBP images with the Android bitmap codec,
 *  - reading free/total space of a storage location.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.fileflow.app/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result -> handle(call, result) }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "openFile" -> openFile(call, result)
            "encodeWebp" -> encodeWebp(call, result)
            "storageInfo" -> storageInfo(call, result)
            else -> result.notImplemented()
        }
    }

    private fun openFile(call: MethodCall, result: MethodChannel.Result) {
        val path = call.argument<String>("path")
        if (path == null) {
            result.error("bad_args", "Missing path", null)
            return
        }
        val file = File(path)
        if (!file.exists()) {
            result.error("missing", "File no longer exists", null)
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val ext = MimeTypeMap.getFileExtensionFromUrl(file.name.replace(" ", "_"))
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, file.name))
            result.success(true)
        } catch (e: ActivityNotFoundException) {
            result.error("no_app", "No app can open this file type", null)
        } catch (e: Exception) {
            result.error("open_failed", e.message, null)
        }
    }

    private fun encodeWebp(call: MethodCall, result: MethodChannel.Result) {
        val bytes = call.argument<ByteArray>("bytes")
        val quality = (call.argument<Int>("quality") ?: 80).coerceIn(1, 100)
        val lossless = call.argument<Boolean>("lossless") ?: false
        if (bytes == null) {
            result.error("bad_args", "Missing bytes", null)
            return
        }
        Thread {
            try {
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap == null) {
                    runOnUiThread { result.error("decode_failed", "Image could not be decoded", null) }
                    return@Thread
                }
                val out = ByteArrayOutputStream()
                val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (lossless) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
                bitmap.compress(format, if (lossless) 100 else quality, out)
                bitmap.recycle()
                val data = out.toByteArray()
                runOnUiThread { result.success(data) }
            } catch (e: Throwable) {
                runOnUiThread { result.error("encode_failed", e.message, null) }
            }
        }.start()
    }

    private fun storageInfo(call: MethodCall, result: MethodChannel.Result) {
        val path = call.argument<String>("path")
        if (path == null) {
            result.error("bad_args", "Missing path", null)
            return
        }
        try {
            val stat = StatFs(path)
            result.success(
                mapOf(
                    "total" to stat.totalBytes,
                    "free" to stat.availableBytes,
                ),
            )
        } catch (e: Exception) {
            result.error("stat_failed", e.message, null)
        }
    }
}
