# FILEFLOW ProGuard / R8 rules.
# Flutter's Gradle plugin already ships the rules needed by the engine.
-keep class com.fileflow.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-dontwarn com.google.android.play.core.**
